﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Runtime.DesignerServices;

namespace forgalom
{
    public partial class frmForgalom : Form
    {
        static string query;
        public frmForgalom()
        {
            InitializeComponent();

            this.lblConnState.Text = SQLhandler.tryConnect(this.tbDb.Text) ? "Successful connection" : "Connection failed";
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            this.lblConnState.Text = SQLhandler.tryConnect(this.tbDb.Text) ? "Successful connection" : "Connection failed";
        }


        //3) Készítsen lekérdezést, amelynek segítségével kiírathatja az 1000 Ft-nál drágább áruk nevét és árát!
        private void btne3_Click(object sender, EventArgs e)
        {
            query = "SELECT nev, ar FROM aru WHERE ar>1000;";
            SQLhandler.FillData(query, dgvResult);
            tbQuery.Text = query;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            query = tbQuery.Text;
            SQLhandler.FillData(query, dgvResult);
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnUploadQuery_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Válasszon ki egy SQL parancso(ka)t tartalmazó szövegfájlt";
            dialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                tbQuery.Text = File.ReadAllText(dialog.FileName);
            }
        }


        //eredmény mentése még csak
        private void btnSave_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Válassza ki a fájlt ahová a lekérdezést menteni szeretné";
            dialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                TextWriter writer = new StreamWriter(dialog.FileName);
               
                    for (int i = 0; i < dgvResult.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j < dgvResult.Columns.Count; j++)
                        {
                           writer.Write(dgvResult.Rows[i].Cells[j].Value.ToString());

                            if (j != dgvResult.Columns.Count - 1)
                            {
                                writer.Write("; ");
                            }
                        }
                        writer.WriteLine();
                    }
            }
        }
    }
}
