<h2>Karrier</h2>

Egyre több weboldalon létezik e menüpontot, melyre akkor érdemes rákattintani, ha 
munka- vagy álláskeresőben vagyunk. Egyebek mellett ugyanis itt szokták a cégek 
kiposztolni az éppen aktuálisan betöltetlen pozícióikat, vagyis az állásajánlataikat. 