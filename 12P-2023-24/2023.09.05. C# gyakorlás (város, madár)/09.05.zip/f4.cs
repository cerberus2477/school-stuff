﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics.Tracing;
using System.CodeDom.Compiler;

namespace feladat04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //kérje be egy szöveges állomány nevét, olvassa be
            //írja ki egy oszlopban a szavakat másikban hogy hányszor szerepel

            Console.Write("Adja meg egy szöveges állomány nevét kiterjesztéssel együtt (a Debug mappából): ");
            string fname = Console.ReadLine();
            string txt;
            List<string> distinctWords = new List<string>(); //minden szó egyszer szerepel
            List<string> words = new List<string>();
            using (StreamReader sr = new StreamReader(fname)) { txt = sr.ReadToEnd(); }
            
            foreach (string str in txt.Split(' ')) //ha a '\n'-nél is spőlitelek akkor elromlik
            {
                string word = str.Trim('.', ',', '!', '?', ' ').ToLower(); //nem működik a trim úgy ahogy szeretném
                words.Add(word);
                if (!distinctWords.Contains(word)) { distinctWords.Add(word); }
            }

            foreach (var dword in distinctWords) 
            {
                Console.WriteLine($"{dword}: {words.Count(x => x == dword)}");
            }

            //debug
            /*foreach(var dword in distinctWords)
            {
                Console.WriteLine(dword);
                Console.ReadKey();
            }*/

         
            

        }
    }
}
