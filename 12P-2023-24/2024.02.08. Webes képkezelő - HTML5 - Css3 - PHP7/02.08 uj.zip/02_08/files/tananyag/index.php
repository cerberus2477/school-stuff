<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP menü minta</title>
    <link rel="stylesheet" href="pelda1.css">
</head>
<body>
    

    <div class="keret">
        <div class="belso felso">PHP menü mintapélda</div>
        <div class="belso bal">
            <a href="?p=">Aktualitások</a>
            <a href="?p=rolunk">Rólunk</a>
            <a href="?p=szolg">Szolgáltatás</a>
            <a href="?p=ref">Referenciák</a>
            <a href="?p=terkep">Elérhetőség</a>
            <a href="?p=kapcs">Kapcsolat</a>
            <a href="?p=allas">Karrier</a>
        </div>
        <div class="belso jobb">
            <?php
            $p = isset($GET["p"]) ? $GET["p"] : "";
            // $p = $GET["p"];
                
                switch ($p) {
                    case "":
                        include("1.php");
                        break;
                    case "rolunk":
                        include("2.php");
                        break;
                    case "szolg":
                        include("3.php");
                        break;
                    case "ref":
                        include("4.php");
                        break;
                    case "terkep":
                        include("5.php");
                        break;
                    case "kapcs":
                        include("6.php");
                        break;
                    case "allas":
                        include("7.php");
                        break;
                    default:
                        include("404.php");
                        break;

                        
                }
            ?>
        </div>
        
    </div>  
</body>
</html>