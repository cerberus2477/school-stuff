﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;


namespace mikulasgyar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        struct Gyerek
        {
            public string nev;
            public List<string> mitker;

            public Gyerek(string sor)
            {
                List<string> temp = sor.Split(';').Select(t => t.Replace("\r", "")).ToList();
                nev = temp[0];
                temp.RemoveAt(0);
                mitker = temp;
            }
        }


        static List<Gyerek> gyerekek = new List<Gyerek>();
        static List<string> ajandekok = new List<string>(); 
        static Dictionary<string, string> eredmeny = new Dictionary<string, string>();


        static bool ajandekozas(int gyerekIndex)
        {
            //ha minden gyerek volt
            if (gyerekIndex == gyerekek.Count)
            {
                return true;
            }

            Gyerek aktualisGyerek = gyerekek[gyerekIndex];

            foreach (var aji in aktualisGyerek.mitker)
            {
                if (ajandekok.Contains(aji)) // ha van még ilyen ajándék
                {
                    eredmeny[aktualisGyerek.nev] = aji;
                    ajandekok.Remove(aji);

                    if (ajandekozas(gyerekIndex + 1)) // következő gyerek
                        return true;

                    // Backtrack ha nem sikeres
                    ajandekok.Add(eredmeny[aktualisGyerek.nev]);
                    eredmeny.Remove(aktualisGyerek.nev);
                    
                }
            }

            return false; // erre a gyerekre nincs jó megoldás így
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            Beolvasas();
            tbEredmeny.Text = ajandekozas(0) ? tbEredmeny.Text =  string.Join("", eredmeny.Select(kvp => $"{kvp.Key};{kvp.Value}{Environment.NewLine}")) : tbEredmeny.Text = "Nincs megoldás.";

            //ugyanez olvashatóan :)
            /*if (ajandekozas(0))
            {
                tbEredmeny.Text = string.Join("\n", eredmeny.Select(kvp => $"{kvp.Key};{kvp.Value}"));
            }
            else
            {
                tbEredmeny.Text = "Nincs megoldás.";
            }*/
        }

        




        private void Beolvasas()
        {
            string[] sorok;
            try
            {
                sorok = tbKimitszeretne.Text.Trim().Split('\n');
                if (sorok.Length < 2) throw new Exception();
                foreach (var sor in sorok)
                {
                    gyerekek.Add(new Gyerek(sor));
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nem megfelelő bemenet a 'ki mit szeretne' szövegdobozban", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                sorok = tbMivanlegyartva.Text.Trim().Split('\n');
                foreach (var sor in sorok)
                {
                    string[] temp = sor.Split(';').Select(t => t.Replace("\r", "")).ToArray();
                    for (int i = 0; i < int.Parse(temp[1].Replace("\r", "")); i++) ajandekok.Add(temp[0]);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nem megfelelő bemenet a 'mi van legyártva' szövegdobozban", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        //Fájlból olvasás, fájlba írás--------------------------------------------------------------------------------------------------------------------------------------------------
        private void btnKimitszeretneBe_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Válassza ki a fájlt!";
            openFileDialog1.Filter = "TXT files|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                {
                    tbKimitszeretne.Text = sr.ReadToEnd();
                }
            }
        }

        private void btnMivanlegyartvaBe_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Válassza ki a fájlt!";
            openFileDialog1.Filter = "TXT files|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                {
                    tbMivanlegyartva.Text = sr.ReadToEnd();
                }
            }
        }

        private void btnEredmenyKi_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Válassza ki a fájlt!";
            openFileDialog1.Filter = "TXT files|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                DialogResult res = DialogResult.Yes;
                if (File.ReadAllText(openFileDialog1.FileName) != "")
                {
                    res = MessageBox.Show("Figyelem! A fájl jelenlegi adatai felülírásra kerülnek. Kívánja folytatni?", "Figyelem!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                }

                if (res == DialogResult.Yes)
                {
                    File.WriteAllText(openFileDialog1.FileName, tbEredmeny.Text);
                    MessageBox.Show("Az adatok mentése megtörtént.", "Sikeres művelet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }
    }
}
