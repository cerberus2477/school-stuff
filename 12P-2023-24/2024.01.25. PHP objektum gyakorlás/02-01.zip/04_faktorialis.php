<?php
    class Number{
        protected $value;

        function __construct($value){
            $this->value = $value;
        }

        function factorial() {
            if ($this->value < 0) return "Negatív számnak nincs faktoriálisa";
            if ($this->value == 0 || $this->value == 1) return 1;
            $factorial = 1;
            for ($i = 2; $i <= $this->value; $i++) {
                $factorial *= $i;
            }
            return $factorial;
        }
    }

    if(!(isset($_POST['num']))){
        $uzenet = "Adja meg a számot!";
    }else{
        $num = new Number($_POST["num"]);
        $uzenet = "A szám faktoriálisa: " . $num->factorial();
        var_dump($num);
    }

    ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4) Faktoriális</title>
</head>
<body>
<div>
        <h2>4) Faktoriális</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <p>
                <label for="num">A szám:</label>
                <input required type="number" id="num" name="num">
                <input type="submit" value="OK">
            </p>
        </form>
        <h1><?php echo $uzenet ?></h1>
    </div>  

</body>
</html>