﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Futóverseny
{
    class Jegyzőkönyv
    {
        private Versenyző[] futók = new Versenyző[10000];
        private int db = 0;

        public bool hozzáad(string név, string egyesület, int rajtszám) //ha már szerepel hamisat adok vissza
        {
            bool ok = true;
            if (db > 0)
            {
                int index = keres(név, rajtszám); //ha már van versenyző megnézem, nincs-e már a nyílvántartásban
                if (index == -1) //ha nincs benne hozzáadom
                {
                    futók[db] = new Versenyző(név, egyesület, rajtszám);
                    db++;
                }
                else ok = false; //ha már szerepel hamisat adok vissza
            }
            else  //ha még nincs versenyző hozzáadom
            {
                futók[db] = new Versenyző(név, egyesület, rajtszám);
                db++;
            }
            return ok;
        }

        public bool üres()
        {
            return db == 0;
        }

        private int keres(string név, int rajtszám)
        {
            int index = -1, i = 0;
            while (i < db && (!futók[i].névhasonlít(név) || !futók[i].számhasonlít(rajtszám))) i++;
            if (i < db) index = i;
            return index;
        }

        private void rendez()
        {
            for (int i = 0; i < db; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < db; j++)
                {
                    if (futók[j].CompareTo(futók[minIndex]) > 0) minIndex = j;
                }
                if (minIndex != i)
                {
                    Versenyző segéd = futók[i];
                    futók[i] = futók[minIndex];
                    futók[minIndex] = segéd;
                }
            }
        }

        public bool indidőbe(string név, int rajtszám, int ó, int p, int mp)
        {
            int index = keres(név, rajtszám);
            if (index != -1) futók[index].indulásibe(ó, p, mp);
            return index != -1;
        }

        public bool érkidőbe(string név, int rajtszám, int ó, int p, int mp)
        {
            int index = keres(név, rajtszám);
            if (index != -1) futók[index].érkezésibe(ó, p, mp);
            return index != -1;
        }

        public void listáz()
        {
            rendez();
            string szoveg = ""; //Environment.NewLine
            int volt = 0;
            for (int i = 0; i < db && futók[i].résztvett(); i++)
            {
                szoveg += Convert.ToString(i + 1) + ". helyezett {1}" + futók[i].ToString() + Environment.NewLine;
                //Console.WriteLine("{0}. helyezett {1}", i + 1, futók[i].ToString());
                volt++;
            }
            szoveg += "A versenyre nevezettek száma " + Convert.ToString(db) + " fő." + Environment.NewLine;
            //Console.WriteLine("A versenyre nevezettek száma {0} fő.", db);
            szoveg += "A versenyen résztvett " + Convert.ToString(volt) + " fő.";
            Console.WriteLine("A versenyen résztvett {0} fő.", volt);
        }
    }
}
