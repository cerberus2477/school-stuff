﻿
namespace Málnaátvevő
{
    partial class frmMalna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMalna));
			this.btnEladoFelv = new System.Windows.Forms.Button();
			this.btnMalnaVetel = new System.Windows.Forms.Button();
			this.btnListazas = new System.Windows.Forms.Button();
			this.btnKilepes = new System.Windows.Forms.Button();
			this.tbNev = new System.Windows.Forms.TextBox();
			this.tbAzon = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.tbMalnamenny = new System.Windows.Forms.TextBox();
			this.tbListazas = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnEladoFelv
			// 
			this.btnEladoFelv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEladoFelv.Location = new System.Drawing.Point(25, 407);
			this.btnEladoFelv.Name = "btnEladoFelv";
			this.btnEladoFelv.Size = new System.Drawing.Size(263, 69);
			this.btnEladoFelv.TabIndex = 0;
			this.btnEladoFelv.Text = "&Eladó felvétel";
			this.btnEladoFelv.UseVisualStyleBackColor = true;
			this.btnEladoFelv.Click += new System.EventHandler(this.btnEladoFelv_Click);
			// 
			// btnMalnaVetel
			// 
			this.btnMalnaVetel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnMalnaVetel.Location = new System.Drawing.Point(25, 328);
			this.btnMalnaVetel.Name = "btnMalnaVetel";
			this.btnMalnaVetel.Size = new System.Drawing.Size(263, 73);
			this.btnMalnaVetel.TabIndex = 1;
			this.btnMalnaVetel.Text = "&Málna vétel";
			this.btnMalnaVetel.UseVisualStyleBackColor = true;
			this.btnMalnaVetel.Click += new System.EventHandler(this.btnMalnaVetel_Click);
			// 
			// btnListazas
			// 
			this.btnListazas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnListazas.Location = new System.Drawing.Point(25, 482);
			this.btnListazas.Name = "btnListazas";
			this.btnListazas.Size = new System.Drawing.Size(263, 69);
			this.btnListazas.TabIndex = 2;
			this.btnListazas.Text = "&Listázás";
			this.btnListazas.UseVisualStyleBackColor = true;
			this.btnListazas.Click += new System.EventHandler(this.btnListazas_Click);
			// 
			// btnKilepes
			// 
			this.btnKilepes.FlatAppearance.BorderSize = 0;
			this.btnKilepes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnKilepes.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnKilepes.Location = new System.Drawing.Point(871, 37);
			this.btnKilepes.Name = "btnKilepes";
			this.btnKilepes.Size = new System.Drawing.Size(60, 60);
			this.btnKilepes.TabIndex = 3;
			this.btnKilepes.Text = "&X";
			this.btnKilepes.UseVisualStyleBackColor = true;
			this.btnKilepes.Click += new System.EventHandler(this.btnKilepes_Click);
			// 
			// tbNev
			// 
			this.tbNev.Location = new System.Drawing.Point(125, 163);
			this.tbNev.Name = "tbNev";
			this.tbNev.Size = new System.Drawing.Size(163, 27);
			this.tbNev.TabIndex = 4;
			this.tbNev.TextChanged += new System.EventHandler(this.tbNev_TextChanged);
			// 
			// tbAzon
			// 
			this.tbAzon.Location = new System.Drawing.Point(170, 209);
			this.tbAzon.Name = "tbAzon";
			this.tbAzon.Size = new System.Drawing.Size(118, 27);
			this.tbAzon.TabIndex = 5;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(21, 166);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(98, 21);
			this.label1.TabIndex = 6;
			this.label1.Text = "Eladó neve";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(18, 212);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(146, 21);
			this.label2.TabIndex = 7;
			this.label2.Text = "Eladó azonosítója";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.label3.Location = new System.Drawing.Point(331, 527);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(0, 25);
			this.label3.TabIndex = 8;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(21, 261);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(147, 21);
			this.label4.TabIndex = 9;
			this.label4.Text = "Málna mennyiség";
			// 
			// tbMalnamenny
			// 
			this.tbMalnamenny.Location = new System.Drawing.Point(174, 258);
			this.tbMalnamenny.Name = "tbMalnamenny";
			this.tbMalnamenny.Size = new System.Drawing.Size(114, 27);
			this.tbMalnamenny.TabIndex = 10;
			// 
			// tbListazas
			// 
			this.tbListazas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(17)))), ((int)(((byte)(27)))));
			this.tbListazas.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.tbListazas.Enabled = false;
			this.tbListazas.ForeColor = System.Drawing.Color.White;
			this.tbListazas.Location = new System.Drawing.Point(316, 163);
			this.tbListazas.Multiline = true;
			this.tbListazas.Name = "tbListazas";
			this.tbListazas.ReadOnly = true;
			this.tbListazas.Size = new System.Drawing.Size(627, 412);
			this.tbListazas.TabIndex = 11;
			this.tbListazas.TextChanged += new System.EventHandler(this.tbListazas_TextChanged);
			// 
			// panel1
			// 
			this.panel1.BackgroundImage = global::Málnaátvevő.Properties.Resources.raspberry;
			this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Location = new System.Drawing.Point(22, 37);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(266, 97);
			this.panel1.TabIndex = 12;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label5.Location = new System.Drawing.Point(329, 44);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(374, 39);
			this.label5.TabIndex = 13;
			this.label5.Text = "Málnaátvevő program";
			// 
			// frmMalna
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(20)))), ((int)(((byte)(34)))));
			this.ClientSize = new System.Drawing.Size(966, 606);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.tbListazas);
			this.Controls.Add(this.tbMalnamenny);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbAzon);
			this.Controls.Add(this.tbNev);
			this.Controls.Add(this.btnKilepes);
			this.Controls.Add(this.btnListazas);
			this.Controls.Add(this.btnMalnaVetel);
			this.Controls.Add(this.btnEladoFelv);
			this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.ForeColor = System.Drawing.Color.White;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmMalna";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEladoFelv;
        private System.Windows.Forms.Button btnMalnaVetel;
        private System.Windows.Forms.Button btnListazas;
        private System.Windows.Forms.Button btnKilepes;
        private System.Windows.Forms.TextBox tbNev;
        private System.Windows.Forms.TextBox tbAzon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbMalnamenny;
		private System.Windows.Forms.TextBox tbListazas;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label5;
	}
}

