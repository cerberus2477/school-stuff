﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace f1._1_husvet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int currentYear = 2023;
            int A = currentYear % 19;
            int B = currentYear % 4;
            int C = currentYear % 7;
            int D = (19 * A + 24) % 30;
            int E = (2 * B + 4 * C + 6 * D + 5) % 7;

            //hús vét
            int meatbuy = 22 + D + E;
            //hó nap
            string snowday = meatbuy <= 31 ? "Március" : "Április";
            if (snowday == "Április") meatbuy -= 31;

            if (E == 6 &&  D == 29)
            {

            }
        }
    }
}
