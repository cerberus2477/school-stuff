﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _09._26_kullancs
{
    internal class Kullancsok
    {
        static Kullancs[] kullancsok = new Kullancs[10];

        public Kullancsok(string fname)
        {
            foreach (var s in File.ReadLines(fname))
            {
                
            }
        }

        public string KiirMaxFerto()
        {
            var sorok = kullancsok.Where(a => a.FertozesCount() == kullancsok.Max(x => x.FertozesCount())).Select(y => y.ToString());

 
            string fejlec = String.Format("{0:10}{1:-20}{2:-20}\n{3}\n", "Sorszám", "Lelőhely", "Fertőzések", 65 * '-');
            return String.Format("{0}{1}", fejlec, String.Join("\n", sorok));
        }
    }
}
