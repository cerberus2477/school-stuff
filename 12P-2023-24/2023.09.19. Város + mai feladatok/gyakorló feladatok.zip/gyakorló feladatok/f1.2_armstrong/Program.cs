﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace f1._2_armstrong
{
    internal class Program
    {
        //(:
        static List<int> armstrong = new List<int>();

        static void Main(string[] args)
        {
            for (int n = 100; n < 1000; n++)
            {
                if (isArmstrong(n))
                {
                    armstrong.Add(n);
                }
            }

            Console.WriteLine($"Az Armstrong számok {String.Join(", ", armstrong)}.");
        }

        static bool isArmstrong(int num)
        {
            return (int.Parse(num.ToString()[0].ToString()) * int.Parse(num.ToString()[0].ToString()) * int.Parse(num.ToString()[0].ToString()) + int.Parse(num.ToString()[1].ToString()) * int.Parse(num.ToString()[1].ToString()) * int.Parse(num.ToString()[1].ToString()) + int.Parse(num.ToString()[2].ToString()) * int.Parse(num.ToString()[2].ToString()) * int.Parse(num.ToString()[2].ToString())) == num;
        }
        //Bocsánat.


        //:)
    }
}
