﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static System.Net.WebRequestMethods;

namespace _05._21_Útvonaltervezés
{
	internal class Szakasz
	{
		public int[] pontok;
		public int tav, utdij;
		public double szakasz_fogy, hasznalt_uzemanyag;

		public Szakasz(int pont1, int pont2, int tav, int utdij, double szakasz_fogy, double auto_fogy, int uzemanyagar)
		{
			this.pontok = new int[]{ pont1, pont2};
			this.tav = tav;
			this.utdij = utdij;
			this.szakasz_fogy = szakasz_fogy;
			this.hasznalt_uzemanyag = tav * auto_fogy / 100 * szakasz_fogy; //(l)
		}

		
	}

	
}
