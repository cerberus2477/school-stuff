﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace varos_nyilvantartas
{
    internal class Program
    {

        static Cities db = new Cities();


        class City
        {
            private string name;
            private int area, population;

            public City(string _name, int _area, int _population)
            {
                name = _name;
                population = _population;
                area = _area;

            }


            public int getPopulation() { return this.population; }
  
            public int popDensity()
            {
                return population / area;
            }
            /*public bool equals(City city)
            {
                return (this.name.Equals(city.getName()));  
            }*/

            public int compareTo(City other)
            {
                if (this.popDensity() == other.popDensity()) return 0;
                else if (this.popDensity() > other.popDensity()) return 1;
                return -1;
            }

            public override string ToString()
            {
                return string.Format("{0, -25}|{1, 15}|{2, 15}|{3, 15}", name, area, population, popDensity());
            }
        }






        public class Cities
        {
            private City[] cities = new City[100];
            private int cityCount = 0;

            public void addRecord(string _name, int _area, int _population)
            {
                cities[cityCount] = new City(_name, _area, _population);
                cityCount++;
                orderRecords();
            }

            public void orderRecords()
            {
                for (int i = 0; i < cityCount; i++)
                {
                    for(int j = i + 1; j < cityCount; j++)
                    {
                        if (cities[i].compareTo(cities[j]) == -1)
                        {
                            var temp = cities[i];
                            cities[i] = cities[j];
                            cities[j] = temp;
                        }
                    }
                }
            }

            public void displayRecords()
            {
                Console.WriteLine("{0, -25}|{1, 15}|{2, 15}|{3, 15}", "Város neve", "Terület (km2)", "Lakosság", "Népsűrűség (fő/km2)");
                for (int i = 0; i < cityCount; i++)
                {
                    Console.WriteLine(cities[i].ToString());
                }
            }

            public void displayStatistics()
            {
                Console.WriteLine("{0, -25}|{1, 15}", "Lakosok száma", "Városok száma");
                Console.WriteLine("{0, -25}|{1, 15}", "0 - 99.999", cities.Where(c => Array.IndexOf(cities, c) < cityCount).Count(c => c.getPopulation() < 99_999));
                Console.WriteLine("{0, -25}|{1, 15}", "100.000 - 999.999", cities.Where(c => Array.IndexOf(cities, c) < cityCount).Count(c => c.getPopulation() < 999_999 && c.getPopulation() > 99_999));
                Console.WriteLine("{0, -25}|{1, 15}", "1.000.000 - 9.999.999", cities.Where(c => Array.IndexOf(cities, c) < cityCount).Count(c => c.getPopulation() < 9_999_999 && c.getPopulation() > 999_999));
                Console.WriteLine("{0, -25}|{1, 15}", "10.000.000 -", cities.Where(c => Array.IndexOf(cities, c) < cityCount).Count(c =>c.getPopulation() > 9_999_999));

            }
        }




        static void menu()
        {
            int userInput = -1;
            do
            {
                Console.Clear();
                Console.WriteLine("VÁROSOK NYILVÁNTARTÁSA\nA továbblépéshez gépeljen be egyet az alábbi számok közül\n");
                Console.WriteLine("[1] Új városok felvitele");
                Console.WriteLine("[2] Városok listája népsűrűség szerint csökkenő sorrendben");
                Console.WriteLine("[3] Városok lakosság szerinti eloszlása");
                Console.WriteLine("[4] Kilépés\n");
                userInput = int.Parse(Console.ReadLine());
                switch (userInput)
                {
                    case 1:
                        AddRecords();
                        break;
                    case 2:
                        DisplayRecords();
                        break;
                    case 3:
                        DisplayStatistics();
                        break;
                }
                Console.WriteLine("\n\nNyomjon le egy billentyűt a továbblépéshez...");
                Console.ReadKey();
                
            } while (userInput != 4);

            Environment.Exit(0);
        }

       

        static void AddRecords()
        {
            Console.Clear();
            Console.WriteLine("Adja meg az új város adatait ;-vel elválasztva!\nVárt formátum: Város neve;Terület km2-ben egészre kerekítve;Lakosok száma\nPélda: Purmerend;25;80000\nAz adatok bekérése * megadásáig ismétlődik!\n");
            string userInput = "";
            do
            {
                userInput = Console.ReadLine();
                var ui = userInput.Split(';');
                if (userInput != "*")
                {
                    db.addRecord(ui[0], int.Parse(ui[1]), int.Parse(ui[2]));
                }
            } while (userInput != "*");
            Console.WriteLine("Az adatok hozzáadása megtörtént!");
        }

        static void DisplayRecords()
        {
            Console.Clear();
            db.displayRecords();
        }

        static void DisplayStatistics()
        {
            Console.Clear();
            db.displayStatistics();
        }

        static void Main(string[] args)
        {
            menu();
        }
    }
}