﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //kérjen be egy term számot, s adja meg a különböző prímosztóinak számát
            int db = 0;
            Console.WriteLine("Adjon meg egy természetes számot!");
            int n = int.Parse(Console.ReadLine());

            for (int i = 2; i < n/2; i++)
            {
                if (isPrime(i) && n%i == 0)
                {
                    db++;
                }
            }

            Console.WriteLine($"A számnak {db} db prímosztója van.");

        }

        static bool isPrime(int num)
        {
            for (int i = 2; i < Math.Sqrt(num); i++)
            {
                if ((num % i) == 0) { return false; }
            }
            return true;
        }
    }
}
