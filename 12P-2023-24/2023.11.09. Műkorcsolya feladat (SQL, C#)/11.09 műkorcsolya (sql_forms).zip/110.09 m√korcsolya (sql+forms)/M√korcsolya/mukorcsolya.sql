-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Nov 09. 08:43
-- Kiszolgáló verziója: 10.4.6-MariaDB
-- PHP verzió: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `mukorcsolya`
--
CREATE DATABASE IF NOT EXISTS `mukorcsolya` DEFAULT CHARACTER SET latin2 COLLATE latin2_hungarian_ci;
USE `mukorcsolya`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `donto`
--

CREATE TABLE `donto` (
  `Név` varchar(20) NOT NULL,
  `Ország` varchar(3) NOT NULL,
  `Technikai` decimal(10,2) DEFAULT NULL,
  `Komponens` decimal(10,2) DEFAULT NULL,
  `Levonás` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `donto`
--

INSERT INTO `donto` (`Név`, `Ország`, `Technikai`, `Komponens`, `Levonás`) VALUES
('Anastasia GALUSTYAN', 'ARM', '49.82', '48.45', 0),
('Angelina KUCHVALSKA', 'LAT', '49.08', '50.02', 0),
('Anna POGORILAYA', 'RUS', '53.00', '62.85', 4),
('Ashley WAGNER', 'USA', '56.33', '68.17', 0),
('Carolina KOSTNER', 'ITA', '59.47', '71.03', 0),
('Dabin CHOI', 'KOR', '69.72', '58.73', 0),
('Elizabet TURSYNBAEVA', 'KAZ', '68.36', '58.15', 0),
('Evgenia MEDVEDEVA', 'RUS', '78.27', '76.13', 0),
('Gabrielle DALEMAN', 'CAN', '71.73', '69.60', 0),
('Ivett TOTH', 'HUN', '47.10', '53.67', 1),
('Kaetlyn OSMOND', 'CAN', '70.21', '71.94', 0),
('Kailani CRAINE', 'AUS', '47.93', '49.04', 1),
('Karen CHEN', 'USA', '65.98', '64.33', 1),
('Laurine LECAVELIER', 'FRA', '55.18', '53.32', 1),
('Loena HENDRICKX', 'BEL', '58.65', '56.63', 0),
('Mai MIHARA', 'JPN', '74.40', '63.89', 0),
('Maria SOTSKOVA', 'RUS', '58.65', '64.79', 1),
('Mariah BELL', 'USA', '65.29', '60.92', 0),
('Nicole RAJICOVA', 'SVK', '55.67', '52.80', 0),
('Nicole SCHOTT', 'GER', '51.66', '54.92', 0),
('Rika HONGO', 'JPN', '50.96', '57.32', 1),
('Wakaba HIGUCHI', 'JPN', '59.47', '63.71', 1),
('Xiangning LI', 'CHN', '62.69', '54.40', 0),
('Zijun LI', 'CHN', '53.96', '49.54', 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orszagok`
--

CREATE TABLE `orszagok` (
  `OrszagID` varchar(3) NOT NULL,
  `OrszagNev` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `orszagok`
--

INSERT INTO `orszagok` (`OrszagID`, `OrszagNev`) VALUES
('ARM', 'Örményország'),
('AUS', 'Ausztrália'),
('AUT', 'Ausztria'),
('BEL', 'Belgium'),
('BRA', 'Brazília'),
('CAN', 'Kanada'),
('CHN', 'Kína'),
('CZE', 'Csehország'),
('EST', 'Észtország'),
('FIN', 'Finnország'),
('FRA', 'Franciaország'),
('GBR', 'Egyesült Királyság'),
('GER', 'Németország'),
('HUN', 'Magyaqrország'),
('ITA', 'Olaszország'),
('JPN', 'Japán'),
('KAZ', 'Kazahsztán'),
('KOR', 'Dél-Korea'),
('LAT', 'Lettország'),
('NOR', 'Norvégia'),
('Ors', 'OrszagNev'),
('RUS', 'Oroszország'),
('SGP', 'Szingapúr'),
('SLO', 'Szlovénia'),
('SUI', 'Svájc'),
('SVK', 'Szlovákia'),
('SWE', 'Svédország'),
('TPE', 'Tajvan'),
('UKR', 'Ukrajna'),
('USA', 'Amerikai Egyesült Államok');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `rovidprogram`
--

CREATE TABLE `rovidprogram` (
  `Név` varchar(25) NOT NULL,
  `Ország` varchar(3) NOT NULL,
  `Technikai` decimal(10,2) DEFAULT NULL,
  `Komponens` decimal(10,2) DEFAULT NULL,
  `Levonás` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `rovidprogram`
--

INSERT INTO `rovidprogram` (`Név`, `Ország`, `Technikai`, `Komponens`, `Levonás`) VALUES
('Amy LIN', 'TPE', '28.03', '23.83', 0),
('Anastasia GALUSTYAN', 'ARM', '30.63', '24.57', 0),
('Angelina KUCHVALSKA', 'LAT', '28.24', '27.68', 0),
('Anna KHNYCHENKOVA', 'UKR', '26.30', '21.68', 1),
('Anna POGORILAYA', 'RUS', '37.21', '34.31', 0),
('Anne Line GJERSEM', 'NOR', '25.30', '21.69', 0),
('Ashley WAGNER', 'USA', '35.27', '33.77', 0),
('Carolina KOSTNER', 'ITA', '32.44', '33.89', 0),
('Dabin CHOI', 'KOR', '35.46', '27.20', 0),
('Dasa GRM', 'SLO', '25.03', '22.60', 1),
('Elizabet TURSYNBAEVA', 'KAZ', '36.65', '28.83', 0),
('Emmi PELTONEN', 'FIN', '25.18', '25.56', 0),
('Evgenia MEDVEDEVA', 'RUS', '42.10', '36.91', 0),
('Gabrielle DALEMAN', 'CAN', '39.19', '33.00', 0),
('Helery HÄLVIN', 'EST', '28.21', '23.73', 0),
('Isadora WILLIAMS', 'BRA', '27.79', '22.86', 0),
('Ivett TOTH', 'HUN', '33.60', '27.40', 0),
('Joshi HELGESSON', 'SWE', '27.85', '25.22', 1),
('Kaetlyn OSMOND', 'CAN', '41.23', '34.75', 0),
('Kailani CRAINE', 'AUS', '31.54', '25.43', 0),
('Karen CHEN', 'USA', '38.35', '31.63', 0),
('Kerstin FRANK', 'AUT', '27.83', '22.71', 0),
('Laurine LECAVELIER', 'FRA', '29.77', '26.72', 1),
('Loena HENDRICKX', 'BEL', '30.71', '26.83', 0),
('Mai MIHARA', 'JPN', '30.88', '29.71', 1),
('Maria SOTSKOVA', 'RUS', '38.14', '31.62', 0),
('Mariah BELL', 'USA', '32.16', '28.86', 0),
('Michaela-Lucie HANZLIKOVA', 'CZE', '16.55', '19.66', 4),
('Natasha MCKAY', 'GBR', '25.58', '24.52', 0),
('Nicole RAJICOVA', 'SVK', '29.93', '27.15', 0),
('Nicole SCHOTT', 'GER', '29.64', '26.19', 1),
('Rika HONGO', 'JPN', '31.45', '31.10', 0),
('Shuran YU', 'SGP', '30.31', '22.56', 0),
('Wakaba HIGUCHI', 'JPN', '36.84', '29.03', 0),
('Xiangning LI', 'CHN', '33.49', '24.79', 0),
('Yasmine Kimiko YAMADA', 'SUI', '26.57', '21.29', 0),
('Zijun LI', 'CHN', '29.73', '26.57', 0);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `donto`
--
ALTER TABLE `donto`
  ADD PRIMARY KEY (`Név`,`Ország`),
  ADD KEY `Ország` (`Ország`);

--
-- A tábla indexei `orszagok`
--
ALTER TABLE `orszagok`
  ADD PRIMARY KEY (`OrszagID`);

--
-- A tábla indexei `rovidprogram`
--
ALTER TABLE `rovidprogram`
  ADD PRIMARY KEY (`Név`,`Ország`),
  ADD KEY `Ország` (`Ország`);

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `donto`
--
ALTER TABLE `donto`
  ADD CONSTRAINT `donto_ibfk_1` FOREIGN KEY (`Ország`) REFERENCES `orszagok` (`OrszagID`) ON UPDATE CASCADE;

--
-- Megkötések a táblához `rovidprogram`
--
ALTER TABLE `rovidprogram`
  ADD CONSTRAINT `rovidprogram_ibfk_1` FOREIGN KEY (`Ország`) REFERENCES `orszagok` (`OrszagID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
