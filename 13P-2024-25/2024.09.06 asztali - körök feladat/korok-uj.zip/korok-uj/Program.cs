﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace korok_uj
{
    internal class Program
    {

        
        static void Main()
        {
            korok k= new korok();
            bool exitProgram = false;
            do
            {
                Console.Clear();
                Console.WriteLine("==== Menu ====");
                Console.WriteLine("1. Új kör hozzáadása");
                Console.WriteLine("2. Új pont ellenőrzése");
                Console.WriteLine("3. Kilépés");
                // Console.Write("Select an option: ");

                char choice = Console.ReadKey(true).KeyChar;
                Console.Clear();

                switch (choice)
                {
                    case '1':
                        Console.WriteLine("==== Új kör hozzáadása ====");
                        Console.Write("Add meg a színt (egy karakter): ");
                        char color = Convert.ToChar(Console.ReadLine());
                        Console.Write("Add meg a sugarat: ");
                        int radius = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Add meg az X koordinátát: ");
                        int newx = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Add meg az Y koordinátát: ");
                        int newy = Convert.ToInt32(Console.ReadLine());

                        k.addKor(color, radius, newx, newy);
                        Console.WriteLine("\nÚj kör hozzáadva.");
                        Console.ReadLine();
                        break;
                    case '2':
                        Console.WriteLine("==== Új pont ellenőrzése ====");
                        Console.Write("Add meg a pont x koordinátáját: ");
                        int pointx = Convert.ToInt16(Console.ReadLine());
                        Console.Write("Add meg a pont y koordinátáját: ");
                        int pointy = Convert.ToInt16(Console.ReadLine());
                        k.checkPointInKorok(pointx, pointy);

                        Console.ReadLine();
                        break;
                    case '3':
                        exitProgram = true;
                        break;
                    default:
                        break;
                }
            } while (!exitProgram);
            Console.WriteLine("Viszlát uram/hölgyem!!! Byeee!!! Ciaoo!!! Hola!!! Knee-how!!!");
            Console.WriteLine("Kilépés...");
            Thread.Sleep(1000);  
            Environment.Exit(0); 
        }
    }
}
