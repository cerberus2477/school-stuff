﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace versenyzok {
    class Program {

        static string connStr = "server=localhost; user=root; database=tdhongrie; password='';";
        static MySqlConnection _conn = new MySqlConnection(connStr);
        static MySqlCommand cmd;

        static int taskNum = 11;
        static int colLen = 25;

        static void line(int colNum) {

            for(int i = 0; i < colNum; i++) {
                for(int j = 0; j < colLen; j++) {
                    Console.Write("-");
                }
            }
            Console.WriteLine();
        }
        static void taskTitle() {
            Console.WriteLine($"\n\n{taskNum}. feladat:");
            taskNum++;
        }

        static void execCommand(string cmdStr) {
            cmd = new MySqlCommand(cmdStr, _conn);
            cmd.ExecuteNonQuery();
            Console.WriteLine("A törlés megtörtént.");
        }

        static void execQuery(string cmdStr) {
            cmd = new MySqlCommand(cmdStr, _conn);
            MySqlDataReader reader = cmd.ExecuteReader();
            string[] colNames = Enumerable.Range(0, reader.FieldCount).Select(reader.GetName).ToArray(); //0-tól oszlopszámig generálunk számokat, majd ezeket kicseréjük a nulladik, első stb oszlopnévre
           
            //Oszopnevek
            line(colNames.Length);
            for(int i = 0; i < colNames.Length; i++) {
                Console.Write($"{{0, {colLen}}}", colNames[i]);
            }
            Console.Write("\n");
            line(colNames.Length);

            //Adatok soronként
            int recordNum = 0;
            while(reader.Read()) {

                recordNum++;
                for(int i = 0; i < colNames.Length; i++) {
                    Console.Write($"{{0, {colLen}}}", reader[i]);
                }
                Console.Write("\n");
            }
            if(recordNum == 0) {
                Console.WriteLine("Nincs ilyen rekord.");
            }
            reader.Close();
            line(colNames.Length);
        }

 

        static void Main(string[] args) {
            _conn.Open();

            //9-10
            Console.WriteLine("A tdhongrie adatbázis adatokkal együtt elkészült.");

            //11
            taskTitle();
            execCommand("DELETE FROM csapat WHERE id = 21;");

            //12
            taskTitle();
            execQuery("SELECT nev FROM versenyzo WHERE nemzetiseg LIKE 'HUN' ORDER BY nev;");

            //13
            taskTitle();
            execQuery("SELECT nemzetiseg, COUNT(nemzetiseg) as indulokSzama FROM versenyzo GROUP BY nemzetiseg ORDER BY indulokSzama DESC;");

            //14
            taskTitle();
            execQuery("SELECT szakasz, ido FROM versenyzo INNER JOIN eredmeny ON versenyzo.id = eredmeny.versenyzoId WHERE nev LIKE 'Valter Attila' ORDER BY szakasz;");

            //15
            taskTitle();
            execQuery("SELECT csapatNev, COUNT(*) as magyarokSzama FROM versenyzo INNER JOIN csapat ON versenyzo.csapatId = csapat.id WHERE nemzetiseg LIKE 'HUN' GROUP BY csapatNev HAVING COUNT(nemzetiseg) > 1 ;");

            Console.WriteLine("\n\nViszont látásra!:)");
            Console.ReadKey();
        }
    }
}
