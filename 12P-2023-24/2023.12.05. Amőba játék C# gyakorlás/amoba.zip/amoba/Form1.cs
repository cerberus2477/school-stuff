﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace amoba
{
    public partial class frmAmoba : Form
    {

        Button[,] cells = new Button[40, 40];
        Player[] players = new Player[2];
        int steps = 0; //egyelore csak azert kell hogy ki jon de idek

        struct Player
        {
            public string icon, name;
            //score somehow

            public Player(string _name, string _icon)
            {
                icon = _icon;
                name = _name;
            }
        }

        public frmAmoba()
        {
            InitializeComponent();

            createCells(22, 22);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            players[0] = new Player(tbPlayer1.Text, tbPlayer1Icon.Text);
            players[1] = new Player(tbPlayer2.Text, tbPlayer2Icon.Text);

            foreach (var cell in cells)
            {
                cell.Text = "";
            }
        }


        public void createCells(int cwidth, int cheight)
        {
            for (int j = 0; j < 40; j++)
            {
                for (int i = 0; i < 40; i++)
                {
                    cells[i, j] = new Button();
                    cells[i, j].Name = $"{i},{j}";

                    cells[i, j].Size = new Size(cwidth, cheight);
                    cells[i, j].Location = new Point(i * cwidth, j * cheight);
                    cells[i, j].ForeColor = Color.PaleTurquoise;
                    cells[i, j].Font = new Font(pnlGameArea.Font.Name, 7F);
                    cells[i, j].FlatAppearance.BorderColor = Color.PaleTurquoise;
                    cells[i, j].FlatStyle = FlatStyle.Flat;
                    cells[i, j].Margin = new Padding(0);
                    
                    cells[i, j].Click += fillCell;
                    pnlGameArea.Controls.Add(cells[i, j]);
                }
            }
            pnlGameArea.AutoSize = true;
        }

        public void fillCell(object sender, EventArgs e)
        {
            var cell = sender as Button;
            if (cell.Text == "")
            {

                bool paros = steps % 2 == 0;
                Player player = paros ? players[0] : players[1];
                cell.Text = player.icon;

                Player nextPlayer = paros ? players[1] : players[0];
                lblNextTurn.Text = $"{nextPlayer.name} jön ({nextPlayer.icon})";
                steps++;

                //pl 0,1

                int[] xy = Array.ConvertAll( cell.Name.Split(','), int.Parse);

                //nyeres
                if (areYouWinningSon(player.icon, xy[0], xy[1], 0, 1) ||
                    areYouWinningSon(player.icon, x, y, 1, 1) ||
                    areYouWinningSon(player.icon, x, y, 1, 0) ||
                    areYouWinningSon(player.icon, x, y, -1, 1))
                {
                    iam(); 
                }
            }
        }

        public void iam()
        {
            foreach (Button b in cells)
            {
                b.Enabled = false;
            }

            MessageBox.Show("Nyertél! GGGGG", "Nyertél!", MessageBoxButtons.OK, MessageBoxIcon.Information);




        }

        //irányonként (függőleges, vízszintes, két átló) vizsgálja hogy nyert e
        // a és b a lerakott pozicio, hor és vert hogy milyen irányba kell lépni (pl függőleges vizsgálatnál 1 és 0 -- az előjel mindegy)


        /*
         nyerő = (starty + i * dy,
                  startx + i * dx,
                  dy,
                  dx);
         nyertes = figura;
         */
        int winStartX;
        int winStartY;
        int winHor;
        int winVert;


        //out a nyerő 5ös adatai mennek, hogy később formázni lehessen
        //public bool areYouWinningSon(string icon, int startX, int startY, int hor, int vert, out int winStartX, out int winStartY, out int winHor, out int winVert) 
        public bool areYouWinningSon(string icon, int startX, int startY, int hor, int vert)
        {
            int i = 0;
            bool isSolution = false;
            while (i<=4 && !isSolution) //egy irányban 5 nyerési eshetőség van 
            {

                isSolution = true; //feltételezzük hogy a megoldás jó lesz amíg nem cáfoljuk meg
                int j = 0;
                while (j <= 4 && isSolution)
                {
                    try
                    {
                        int X = startX + (i + j) * hor;
                        int Y = startY + (i + j) * vert;
                        isSolution = cells[Y, X].Text == icon;
                    }
                    catch (Exception) //nincs ilyen mező (lelóg a pályáról)
                    {
                        isSolution=false;
                    }

                    if (isSolution) j++;
                }
                if (!isSolution) i++;
            }
            //return i <= 4;
            return isSolution;
        }

        
    }
}
