<h2>Aktualitások</h2>

Ez egy példaprogram, ami azt mutatja be, hogy miként működik egy olyan weboldal, ami
PHP segíségével kapott menüt.<br><br>

A megvalósítás lényege, hogy bármely menüpontra is kattintunk, az mindig a 
kezőoldalhoz tartozó fájlt (esetünkben az index.php-t) fogja meghívni - viszont 
különböző paraméterekkel.<br><br>

Mint megfigyelhető, ennek az oldalnak, mint kezdőlapnak nincsen paramétere, ám az 
összes többi menüpontra kattintva úgy fog végződni a böngészőben az URL-cím, hogy
<ul>
  <li>?p=rolunk
  <li>?p=szolg
  <li>?p=ref
  <li>...  
</ul>

Az egyenlőségjel utáni szótöredékek a paraméterek értékei, a "p" pedig maga a paraméter.<br><br>

A PHP éppen ennek a "p" paraméternek az értékét dolgozza fel, vagyis ennek függvényében tölt be
tartalmat ebbe a keretbe. Mindez az index.php forráskódjában érhető tetten.

