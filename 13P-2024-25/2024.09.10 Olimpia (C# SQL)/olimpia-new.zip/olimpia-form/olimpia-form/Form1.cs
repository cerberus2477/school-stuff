﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Runtime.DesignerServices;
using MySqlX.XDevAPI.CRUD;
using System.Collections;

namespace olimpia_form
{
    public partial class frmOlimpia : Form
    {
		//static string query;
		public frmOlimpia()
		{
			InitializeComponent();

			this.lblConnState.Text = SQLhandler.tryConnect(this.tbDBname.Text) ? "Sikeres csatlakozás" : "Sikertelen csatlakozás";
		}

		private void btnConnect_Click(object sender, EventArgs e)
		{
			this.lblConnState.Text = SQLhandler.tryConnect(this.tbDBname.Text) ? "Sikeres csatlakozás" : "Sikertelen csatlakozás";
		}

		private void executeSQL(string query)
		{
			tbQuery.Text = query;
			SQLhandler.FillData(query, dgvResult);
		}


		/*private void btn1_Click(object sender, EventArgs e)
		{
			executeSQL("Select * From medals;");
		}

		private void btn2_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}

		private void btn3_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}

		private void btn4_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}

		private void btn5_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}

		private void btn6_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}

		private void btn7_Click(object sender, EventArgs e)
		{
			executeSQL("");
		}*/



		private void btnRun_Click(object sender, EventArgs e)
		{
			executeSQL(tbQuery.Text);
		}

		private void btnCountries_Click(object sender, EventArgs e)
		{
			executeSQL("Select * From countries;");
		}

		private void btnMedals_Click(object sender, EventArgs e)
		{
			executeSQL("Select * From medals;");
		}

		private void btnMedals_won_Click(object sender, EventArgs e)
		{
			executeSQL("Select * From medals_won;");
		}

	}
}
