﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Málnaátvevő
{
    public partial class frmMalna : Form
    {
        static konténer átvevőhely = new konténer();
        

        public frmMalna()
        {
            InitializeComponent();
        }

        private void btnKilepes_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEladoFelv_Click(object sender, EventArgs e)
        {
            try
            {
                label3.Text = "";
                string név = tbNev.Text;
                int szám = int.Parse(tbAzon.Text);
                átvevőhely.Hozzáad(név, szám);
            }
            catch
            {
                label3.Text = "Hibás adatok!";
            }
        }

        private void btnMalnaVetel_Click(object sender, EventArgs e)
        {
            string név;
            int szám;
            double menny;
            try
            {
                label3.Text = "";

                név = tbNev.Text;
                szám = int.Parse(tbAzon.Text);
                menny = double.Parse(tbMalnamenny.Text);
                if (!átvevőhely.Üres())
                {
                    if (!átvevőhely.Málnabe(név, szám, menny))
                    {
                        label3.Text = "Nem találom, kérek új adatokat!";
                        label3.BringToFront();
                    }
                }
                else
                {
                    
                    label3.Text = "Még nem vitt fel eladót";
                    label3.BringToFront();
                }
                
            }
            catch
            {
                label3.Text = "Hibás adatok!";
                label3.BringToFront();
            }
        }

		private void btnListazas_Click(object sender, EventArgs e) {
            tbListazas.Text = átvevőhely.Listáz();
		}

		private void tbNev_TextChanged(object sender, EventArgs e) {

		}

		private void tbListazas_TextChanged(object sender, EventArgs e) {

		}

        //form mozgatasa egerhuzassal
        
           
            protected override void WndProc(ref Message m) {
                base.WndProc(ref m);
                if(m.Msg == WM_NCHITTEST)
                    m.Result = (IntPtr)(HT_CAPTION);
            }

            private const int WM_NCHITTEST = 0x84;
            private const int HT_CLIENT = 0x1;
            private const int HT_CAPTION = 0x2;
        
    }
}
