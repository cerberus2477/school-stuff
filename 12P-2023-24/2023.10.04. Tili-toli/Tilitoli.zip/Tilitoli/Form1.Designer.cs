﻿
namespace Tilitoli {
	partial class Tilitoli {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if(disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.components = new System.ComponentModel.Container();
			this.pnlGombok = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lblOszlop = new System.Windows.Forms.Label();
			this.lblSor = new System.Windows.Forms.Label();
			this.nmOszlop = new System.Windows.Forms.NumericUpDown();
			this.nmSor = new System.Windows.Forms.NumericUpDown();
			this.btnUj = new System.Windows.Forms.Button();
			this.lblCsere = new System.Windows.Forms.Label();
			this.lblMp = new System.Windows.Forms.Label();
			this.lblCim = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nmOszlop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nmSor)).BeginInit();
			this.SuspendLayout();
			// 
			// pnlGombok
			// 
			this.pnlGombok.Location = new System.Drawing.Point(20, 241);
			this.pnlGombok.Margin = new System.Windows.Forms.Padding(5);
			this.pnlGombok.Name = "pnlGombok";
			this.pnlGombok.Size = new System.Drawing.Size(400, 400);
			this.pnlGombok.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.lblOszlop);
			this.panel2.Controls.Add(this.lblSor);
			this.panel2.Controls.Add(this.nmOszlop);
			this.panel2.Controls.Add(this.nmSor);
			this.panel2.Controls.Add(this.btnUj);
			this.panel2.Controls.Add(this.lblCsere);
			this.panel2.Controls.Add(this.lblMp);
			this.panel2.Controls.Add(this.lblCim);
			this.panel2.Location = new System.Drawing.Point(20, 19);
			this.panel2.Margin = new System.Windows.Forms.Padding(5);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(400, 200);
			this.panel2.TabIndex = 1;
			// 
			// lblOszlop
			// 
			this.lblOszlop.AutoSize = true;
			this.lblOszlop.Location = new System.Drawing.Point(29, 140);
			this.lblOszlop.Name = "lblOszlop";
			this.lblOszlop.Size = new System.Drawing.Size(133, 21);
			this.lblOszlop.TabIndex = 6;
			this.lblOszlop.Text = "Oszlopok száma";
			// 
			// lblSor
			// 
			this.lblSor.AutoSize = true;
			this.lblSor.Location = new System.Drawing.Point(29, 104);
			this.lblSor.Name = "lblSor";
			this.lblSor.Size = new System.Drawing.Size(109, 21);
			this.lblSor.TabIndex = 5;
			this.lblSor.Text = "Sorok száma:";
			// 
			// nmOszlop
			// 
			this.nmOszlop.Location = new System.Drawing.Point(168, 135);
			this.nmOszlop.Name = "nmOszlop";
			this.nmOszlop.Size = new System.Drawing.Size(120, 27);
			this.nmOszlop.TabIndex = 4;
			this.nmOszlop.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
			// 
			// nmSor
			// 
			this.nmSor.Location = new System.Drawing.Point(155, 102);
			this.nmSor.Name = "nmSor";
			this.nmSor.Size = new System.Drawing.Size(120, 27);
			this.nmSor.TabIndex = 3;
			this.nmSor.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
			// 
			// btnUj
			// 
			this.btnUj.Location = new System.Drawing.Point(299, 121);
			this.btnUj.Name = "btnUj";
			this.btnUj.Size = new System.Drawing.Size(98, 59);
			this.btnUj.TabIndex = 2;
			this.btnUj.Text = "Új játék";
			this.btnUj.UseVisualStyleBackColor = true;
			this.btnUj.Click += new System.EventHandler(this.btnUj_Click);
			// 
			// lblCsere
			// 
			this.lblCsere.AutoSize = true;
			this.lblCsere.Location = new System.Drawing.Point(295, 53);
			this.lblCsere.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblCsere.Name = "lblCsere";
			this.lblCsere.Size = new System.Drawing.Size(58, 21);
			this.lblCsere.TabIndex = 2;
			this.lblCsere.Text = "Csere:";
			// 
			// lblMp
			// 
			this.lblMp.AutoSize = true;
			this.lblMp.Location = new System.Drawing.Point(295, 87);
			this.lblMp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblMp.Name = "lblMp";
			this.lblMp.Size = new System.Drawing.Size(40, 21);
			this.lblMp.TabIndex = 1;
			this.lblMp.Text = "Mp:";
			// 
			// lblCim
			// 
			this.lblCim.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
			this.lblCim.AutoSize = true;
			this.lblCim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblCim.Location = new System.Drawing.Point(57, 44);
			this.lblCim.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblCim.Name = "lblCim";
			this.lblCim.Size = new System.Drawing.Size(50, 21);
			this.lblCim.TabIndex = 0;
			this.lblCim.Text = "Tilitoli";
			this.lblCim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Tilitoli
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::Tilitoli.Properties.Resources.bg;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(442, 656);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.pnlGombok);
			this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.Margin = new System.Windows.Forms.Padding(5);
			this.MaximizeBox = false;
			this.Name = "Tilitoli";
			this.Text = "Tilitoli";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nmOszlop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nmSor)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel pnlGombok;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label lblCim;
		private System.Windows.Forms.Label lblMp;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label lblCsere;
		private System.Windows.Forms.Label lblOszlop;
		private System.Windows.Forms.Label lblSor;
		private System.Windows.Forms.NumericUpDown nmOszlop;
		private System.Windows.Forms.NumericUpDown nmSor;
		private System.Windows.Forms.Button btnUj;
	}
}

