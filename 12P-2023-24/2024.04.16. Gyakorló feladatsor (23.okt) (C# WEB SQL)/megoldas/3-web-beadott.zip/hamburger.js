const div_form = document.getElementById("asztalfoglalas");
const apiurl = "/api/foglalas";

function foglalas ()  {
    const nname = div_form.querySelector("input[id='name']");
    const phone = div_form.querySelector("input[id='phone']");
    const email = div_form.querySelector("input[id='email']");
    const seats = div_form.querySelector("select[id='seats']");
    const datetime = div_form.querySelector("input[id='datetime']");
    if (!nname.value || !phone.value || !email.value || !seats.value || !datetime.value) {
        alert("Kérlek, minden mezőt tölts ki az űrlapon!");
        return;
    }

    fetch(apiurl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({
            name: nname.value,
            phone: phone.value,
            email: email.value,
            seats: parseInt(seats.value), 
            datetime: datetime.value
        })
    })
    //a szerver válasza Response objektumként a .then-ben megadott anonim függvény paramétere lesz. A paramétert itt responsenak hívtuk. 
    //a Responseból kiolvassuk a status értékét, ha 200 (minden jó), a következő .then-ben megadott anonim függvény paramétere a visszaadott érték, tehát a response.json lesz.
    .then(response => {if (response.status === 200) return response.json();}) 
    //data = response.json
    .then(data => {
        if (data.feldolgozva) {
            alert("Foglalását regisztráltuk!");
            nname.value = "";
            phone.value = "";
            email.value = "";
        }
    })
    .catch(e => console.log(e))
}

document.getElementById("btn").onclick=(e)=>{
    foglalas();
    e.preventDefault();
}
