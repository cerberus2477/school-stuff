﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat11_ugyanaz_a_betu {
	class Program {
		static void Main(string[] args) {
			Console.WriteLine("Adjon meg egy szavakból álló szöveget!");
			string[] words = Console.ReadLine().Split(' ');

			Console.WriteLine($"{countMaxSzolanc(words)}db a legtöbb egymást követő szó melyben a befejező karakter megegyezik a következő szó első karaterével.");
		}

		static int countMaxSzolanc(string[] words) {
			int max = 0;
			string first;
			string last;
			int currentCount = 0;

			for(int i = 1; i < words.Length; i++) {
				if(words[i].StartsWith(words))) {

				}
			}

			return max;
		}
	}
}
