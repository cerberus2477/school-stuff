<!-- 
1. display()


törlés 
-> adott elem törlése arr-bol
-> save()
-> display()

edit (text)
-> új dátum, régi törlése comment törlése, új arr elejére
->save()
-> display()

új hozzászólás
-> array elejére
-> save()
-> display()

fájlba írás func = save -->
<!-- beolvassuk megjelenítjük = display (törlés edit) -->

<!-- fájladatok -->

<?php
    $path = isset($_GET['path']) ? $_GET['path'] : "./files";
    $filename = basename($path);
    include("Comment.php");
?>

<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $filename ?></title>
    <link rel="stylesheet" href="style.css">
    <script>
    const toggleForm = () => {
        document.getElementById("formContainer").classList.toggle("hiddend");
        document.getElementById("callToAction").classList.toggle("hiddend");
    }
    </script>
</head>

<body>
    <!-- Fájl megjelenítése -->
    <?php
        if ( ! file_exists($path)) {
            echo "<p>404 A keresett fájl ($path) nem található.</p>";
            exit;
        }
        
        echo "<h1>$filename</h1>";
        echo "<iframe src='$path'></iframe>";
        //FÁJLADATOK KIÍRÁSA
    ?>



    <button id="callToAction" onclick="toggleForm()">Új komment</button>
    <div id="formContainer" class="hiddend">
        <h2>Új komment hozzáadása</h2>
        <p>Ossza meg velünk mit gondol a képről. (fájlról)</p>
        <form method="post" action="">
            <p>
                <label for="nev">Név* </label>
                <input type="text" name="nev" id="nev" maxlength="50" placeholder="ilcsicica420" required>
            </p>
            <p>
                <label for="comment">Vélemény* </label><br>
                <textarea name="comment" id="comment" cols="30" rows="10" placeholder="Ez a legszebb kép valaha!"
                    required></textarea>
            </p>
            <input type="submit" value="Közzététel" onsubmit="toggleForm()">
        </form>
    </div>

    <hr>
    <h2>Korábbi kommentek</h2>
    <div id="kommentek">
        <?php echo $display ?>;
        <!-- <?php 
      
        //     $comments = [];
        //     foreach (file($path_comments) as $row) {
        //         $r = explode(";", $row);
        //         $c = new Comment($r[0], $r[1], $r[2]);
        //         $comments[] = $c;
        //     }
        
    
        // $fw = fopen($path_comments, "w");
        // foreach ($comments as $c) {
        //     fwrite($fw, $c->__toString());
            
        ?> -->
    </div>

    <!-- kommentek -->
    <?php
        //pl. path = "./file/meow.txt" => $path_comments = "./file/.comments-meow.csv
        $path_comments = dirname($path)."/.comments-".pathinfo($path, PATHINFO_FILENAME)."csv";
        $comments = [];
        
        if ( ! file_exists($path_comments)) {
            $display = "<p><i>Még nincsenek hozzászólások. Legyen Ön az első!</i></p>";
            exit;
        }
      
        //adatok beolvasása és megjelenítése fájlból
       
        
        function display(){
            $comments = [];
            $display = "";
            foreach (file($path_comments) as $row) {
                $r = explode(";", $row);
                $c = new Comment($r[0], $r[1], $r[2]);
                $comments[] = $c;
                $display .= $c.display();
            }
        }

        function save(){
            $fw = fopen($path_comments, "w");
            foreach ($comments as $c) {
                fwrite($fw, $c->__toString());
            }
        }


        
    ?>

    <a class="btn" href="oldal.php?path=<?= urlencode(dirname($path)) ?>">Vissza</a>

</body>

</html>