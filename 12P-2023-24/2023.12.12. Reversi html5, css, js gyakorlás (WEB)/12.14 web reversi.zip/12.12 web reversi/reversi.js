var nrow = 8;
var ncell = 8;
var tt = new Array(nrow);
var newrow;
//a reset() is állít értéket de így hogy itt is a kódban látni milyen típusú a változó
let playerX = true;
let scoreX = 0;
let scoreO = 0;
//ha nem üres a cella, beillesztjük ezt a html kódot. Ez egyben az érme mindkét oldala, a cellára rakott o vagy x osztály alapján jelenítjük meg a megfelelő oldalt
let tdHTML = 
"<div class='td-inner'>" +
"<div class='coin-x'>" +
    "X" +
"</div>" +
"<div class='coin-o'>" +
    "O" +
"</div>" +
"</div>";


function init() {
    for (var i = 0; i < nrow; i++) {
        newrow = document.getElementById("palya").insertRow(i);
        tt[i] = new Array(ncell);
        for (var j = 0; j < ncell; j++) {
            tt[i][j] = newrow.insertCell(j);
           }
    }
    reset();
}

function reset() {
    playerX = true;
    scoreX = 0;
    scoreO = 0;

    for (var i = 0; i < nrow; i++) {
        for (var j = 0; j < ncell; j++) {
            tt[i][j].id = i * ncell + j;
            //következő három parancs => üres cella
            tt[i][j].innerHTML = "";
            tt[i][j].classList.remove("x");
            tt[i][j].classList.remove("y");
            tt[i][j].onclick = function ()
                { 
                    cell_click(this); 
                }
        }
    }

    //középső négy cella beállítása
    tt[nrow / 2 - 1][ncell / 2 - 1].innerHTML = tdHTML;
    tt[nrow / 2 - 1][ncell / 2 - 1].classList.add("x");
    tt[nrow / 2][ncell / 2].innerHTML = tdHTML;
    tt[nrow / 2][ncell / 2].classList.add("x")
    tt[nrow / 2 - 1][ncell / 2].innerHTML = tdHTML;
    tt[nrow / 2 - 1][ncell / 2].classList.add("o")
    tt[nrow / 2][ncell / 2 - 1].innerHTML = tdHTML;
    tt[nrow / 2][ncell / 2 - 1].classList.add("o")

    whose_turn();
}

//kijelőli a lehetséges mezőket, eldönti ki jön vagy vége van-e
function whose_turn(){
    Array.from(document.querySelectorAll('.valid')).forEach(
        (cell) => cell.classList.remove('valid')
    );

    let valid_count = 0;

    //következő játékossal ellenőrzés
    for (let x = 0; x < nrow; x++) {
        for (let y = 0; y < ncell; y++) {
            if (check_step(x, y, playerX)) {
                valid_count++;
            }
        }
    }

    //ha nem talált megoldást, megnézi hogy az előző játékos tud e lépni (ilyenkor kimaradna a soron levő)
    if (valid_count == 0) {
        playerX = !playerX;

        for (let x = 0; x < nrow; x++) {
            for (let y = 0; y < ncell; y++) {
                if (check_step(x, y, playerX)) {
                    valid_count++;
                }
            }
        }
    }

    //ha egyik játékos sem tud lépni, vége a játéknak
    if (valid_count == 0) {
        let res = window.confirm("A játék véget ért");
        if (res) {
            reset();
        }
    }

    document.getElementById("next-turn").innerText = `${playerX ? "X" : "O"} jön`;   
}

function cell_click(obj) {
    if(obj.classList.contains("valid")){
        let row0 = parseInt(obj.id / ncell);
        let column0 = obj.id % nrow;

        check_step(row0, column0, playerX, true);
        playerX = !playerX;
 
        scoreX= document.querySelectorAll('.x').length;
        scoreO = document.querySelectorAll('.o').length;
        document.getElementById("score").innerHTML = `X pontszáma: ${scoreX}<br>O pontszáma: ${scoreO}`;
    }
    whose_turn();
}

//leellenőrzi hogy lehetséges-e a lépés, ha do_flip akkor lép is
function check_step(row0, column0, isX, do_flip=false) {

    //nem üres mező esetén kilépés
    if (tt[row0][column0].classList.contains("x") || tt[row0][column0].classList.contains("o") ) {
        return false;
    }

    //a nyolc irányban megnézi valid-e a lépés (ha do_flip lép is)
    return (
        check_dir(row0, column0, 0, 1, isX, do_flip) ||
        check_dir(row0, column0, 0, -1, isX, do_flip) ||
        check_dir(row0, column0, 1, 0, isX, do_flip) ||
        check_dir(row0, column0, -1, 0, isX, do_flip) ||
        check_dir(row0, column0, -1, 1, isX, do_flip) || //bal fel
        check_dir(row0, column0, 1, -1, isX, do_flip) || //jobb le
        check_dir(row0, column0, -1, -1, isX, do_flip)||  //bal le
        check_dir(row0, column0, 1, 1, isX, do_flip)  //jobb fel
    ) 

}


//hor, vert -1től +1ig értékek (pl. -1;1 a bal fel)
function check_dir(row0, column0, hor, vert, isX, do_flip=false){
    steps = 1;

    let row = row0+steps*vert;
    let column = column0+steps*hor;

    console.log(`row0: ${row0} column0: ${column0}\nhor: ${hor} vert: ${vert}\nrow: ${row} column: ${column}`)
    //amíg táblán belül vagyunk és a cella ellenkező oldalú mint amit rakunk lépünk egyet a megfelelő irányba
    while (row < nrow && row >= 0 && column < ncell && column >= 0
        && tt[row][column].classList.contains("x") != isX
        && tt[row][column].classList.contains("o") == isX) 
        {
            steps++;
            row = row0+steps*vert;
            column = column0+steps*hor;
        }

    //ha beléptünk egyáltalán a while loopba még és táblán belül vagyunk és az aktuális cella ugyanolyan mint amit rakunk 
    //visszaadjuk hogy lehet ilyen lépés vagy lépünk, egyébként 
    if (steps>1 
        && row < nrow && row >= 0 && column < ncell && column >= 0
        && tt[row][column].classList.contains("x") == isX
        && tt[row][column].classList.contains("o") != isX) 
        {

        if (!do_flip) tt[row][column].classList.add("valid")
        else{
            for (let a = steps; a > 0; a--) {
                //tt[row0+a][column0+a].innerText = symbol;  
                row = row0+steps*vert;
                column = column0+steps*hor;
    
                tt[row][column].innerHTML = tdHTML;
                tt[row][column].classList.toggle("o");
                tt[row][column].classList.toggle("x");
            }
        }
         
        return true;
    }
    
    return false;
}