﻿namespace sudokuGame
{
    partial class frmSudokuGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.nehézségToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.knnyűToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normálToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nehézToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extrémToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.táblaméretToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eredményekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlGame = new System.Windows.Forms.Panel();
            this.pnlSudoku = new System.Windows.Forms.Panel();
            this.menuStrip.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            this.pnlGame.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nehézségToolStripMenuItem,
            this.táblaméretToolStripMenuItem,
            this.eredményekToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip.Size = new System.Drawing.Size(532, 25);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip2";
            // 
            // nehézségToolStripMenuItem
            // 
            this.nehézségToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.knnyűToolStripMenuItem,
            this.normálToolStripMenuItem,
            this.nehézToolStripMenuItem,
            this.extrémToolStripMenuItem});
            this.nehézségToolStripMenuItem.Name = "nehézségToolStripMenuItem";
            this.nehézségToolStripMenuItem.Size = new System.Drawing.Size(70, 19);
            this.nehézségToolStripMenuItem.Text = "Nehézség";
            // 
            // knnyűToolStripMenuItem
            // 
            this.knnyűToolStripMenuItem.Name = "knnyűToolStripMenuItem";
            this.knnyűToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.knnyűToolStripMenuItem.Text = "Könnyű";
            // 
            // normálToolStripMenuItem
            // 
            this.normálToolStripMenuItem.Name = "normálToolStripMenuItem";
            this.normálToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.normálToolStripMenuItem.Text = "Normál";
            // 
            // nehézToolStripMenuItem
            // 
            this.nehézToolStripMenuItem.Name = "nehézToolStripMenuItem";
            this.nehézToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nehézToolStripMenuItem.Text = "Nehéz";
            // 
            // extrémToolStripMenuItem
            // 
            this.extrémToolStripMenuItem.Name = "extrémToolStripMenuItem";
            this.extrémToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.extrémToolStripMenuItem.Text = "Extrém";
            // 
            // táblaméretToolStripMenuItem
            // 
            this.táblaméretToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x2ToolStripMenuItem,
            this.x3ToolStripMenuItem});
            this.táblaméretToolStripMenuItem.Name = "táblaméretToolStripMenuItem";
            this.táblaméretToolStripMenuItem.Size = new System.Drawing.Size(77, 19);
            this.táblaméretToolStripMenuItem.Text = "Táblaméret";
            // 
            // x2ToolStripMenuItem
            // 
            this.x2ToolStripMenuItem.Name = "x2ToolStripMenuItem";
            this.x2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.x2ToolStripMenuItem.Text = "2X2";
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.x3ToolStripMenuItem.Text = "3X3";
            // 
            // eredményekToolStripMenuItem
            // 
            this.eredményekToolStripMenuItem.Name = "eredményekToolStripMenuItem";
            this.eredményekToolStripMenuItem.Size = new System.Drawing.Size(84, 19);
            this.eredményekToolStripMenuItem.Text = "Eredmények";
            // 
            // pnlTitle
            // 
            this.pnlTitle.Controls.Add(this.lblTitle);
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitle.Location = new System.Drawing.Point(0, 25);
            this.pnlTitle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(532, 104);
            this.pnlTitle.TabIndex = 2;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.Location = new System.Drawing.Point(32, 32);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(151, 44);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Sudoku";
            // 
            // pnlGame
            // 
            this.pnlGame.Controls.Add(this.pnlSudoku);
            this.pnlGame.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGame.Location = new System.Drawing.Point(0, 129);
            this.pnlGame.Name = "pnlGame";
            this.pnlGame.Size = new System.Drawing.Size(532, 507);
            this.pnlGame.TabIndex = 3;
            // 
            // pnlSudoku
            // 
            this.pnlSudoku.Location = new System.Drawing.Point(40, 44);
            this.pnlSudoku.Name = "pnlSudoku";
            this.pnlSudoku.Size = new System.Drawing.Size(400, 400);
            this.pnlSudoku.TabIndex = 0;
            // 
            // frmSudokuGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 636);
            this.Controls.Add(this.pnlGame);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmSudokuGame";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.pnlGame.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem nehézségToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem knnyűToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normálToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nehézToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extrémToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem táblaméretToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eredményekToolStripMenuItem;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlGame;
        private System.Windows.Forms.Panel pnlSudoku;
    }
}

