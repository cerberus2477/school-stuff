﻿
namespace labirintus
{
    partial class frmLabirintus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fájlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forrásfájlKiválasztásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labirintustxtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labi2txtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlSide = new System.Windows.Forms.Panel();
            this.pnlLabirintus = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fájlToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(732, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fájlToolStripMenuItem
            // 
            this.fájlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.forrásfájlKiválasztásaToolStripMenuItem});
            this.fájlToolStripMenuItem.Name = "fájlToolStripMenuItem";
            this.fájlToolStripMenuItem.Size = new System.Drawing.Size(37, 19);
            this.fájlToolStripMenuItem.Text = "Fájl";
            // 
            // forrásfájlKiválasztásaToolStripMenuItem
            // 
            this.forrásfájlKiválasztásaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labirintustxtToolStripMenuItem,
            this.labi2txtToolStripMenuItem});
            this.forrásfájlKiválasztásaToolStripMenuItem.Name = "forrásfájlKiválasztásaToolStripMenuItem";
            this.forrásfájlKiválasztásaToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.forrásfájlKiválasztásaToolStripMenuItem.Text = "Forrásfájl kiválasztása";
            // 
            // labirintustxtToolStripMenuItem
            // 
            this.labirintustxtToolStripMenuItem.Name = "labirintustxtToolStripMenuItem";
            this.labirintustxtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.labirintustxtToolStripMenuItem.Text = "labirintus.txt";
            this.labirintustxtToolStripMenuItem.Click += new System.EventHandler(this.labirintustxtToolStripMenuItem_Click);
            // 
            // labi2txtToolStripMenuItem
            // 
            this.labi2txtToolStripMenuItem.Name = "labi2txtToolStripMenuItem";
            this.labi2txtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.labi2txtToolStripMenuItem.Text = "labi2.txt";
            this.labi2txtToolStripMenuItem.Click += new System.EventHandler(this.labi2txtToolStripMenuItem_Click);
            // 
            // pnlTitle
            // 
            this.pnlTitle.Controls.Add(this.lblTitle);
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitle.Location = new System.Drawing.Point(0, 25);
            this.pnlTitle.Margin = new System.Windows.Forms.Padding(5);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(732, 136);
            this.pnlTitle.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.Location = new System.Drawing.Point(163, 51);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(389, 42);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "LABIRINTUS MEGOLDÓ";
            // 
            // pnlSide
            // 
            this.pnlSide.BackColor = System.Drawing.SystemColors.Control;
            this.pnlSide.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSide.Location = new System.Drawing.Point(532, 161);
            this.pnlSide.Name = "pnlSide";
            this.pnlSide.Size = new System.Drawing.Size(200, 511);
            this.pnlSide.TabIndex = 2;
            // 
            // pnlLabirintus
            // 
            this.pnlLabirintus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLabirintus.Location = new System.Drawing.Point(0, 161);
            this.pnlLabirintus.Name = "pnlLabirintus";
            this.pnlLabirintus.Size = new System.Drawing.Size(532, 511);
            this.pnlLabirintus.TabIndex = 3;
            // 
            // frmLabirintus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 672);
            this.Controls.Add(this.pnlLabirintus);
            this.Controls.Add(this.pnlSide);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmLabirintus";
            this.Text = "Labirintus";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fájlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forrásfájlKiválasztásaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem labirintustxtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem labi2txtToolStripMenuItem;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlSide;
        private System.Windows.Forms.Panel pnlLabirintus;
    }
}

