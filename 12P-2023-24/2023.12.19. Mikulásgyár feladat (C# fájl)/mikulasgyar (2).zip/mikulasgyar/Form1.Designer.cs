﻿
namespace mikulasgyar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbKimitszeretne = new System.Windows.Forms.TextBox();
            this.tbMivanlegyartva = new System.Windows.Forms.TextBox();
            this.lblKimitszeretne = new System.Windows.Forms.Label();
            this.lblMivanlegyartva = new System.Windows.Forms.Label();
            this.btnKimitszeretneBe = new System.Windows.Forms.Button();
            this.btnMivanlegyartvaBe = new System.Windows.Forms.Button();
            this.tbEredmeny = new System.Windows.Forms.TextBox();
            this.lblEredmeny = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnEredmenyKi = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblKimitszeretneUtasitas = new System.Windows.Forms.Label();
            this.tbSugo = new System.Windows.Forms.TextBox();
            this.lblSugo = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // tbKimitszeretne
            // 
            this.tbKimitszeretne.Location = new System.Drawing.Point(20, 115);
            this.tbKimitszeretne.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbKimitszeretne.Multiline = true;
            this.tbKimitszeretne.Name = "tbKimitszeretne";
            this.tbKimitszeretne.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbKimitszeretne.Size = new System.Drawing.Size(568, 214);
            this.tbKimitszeretne.TabIndex = 0;
            // 
            // tbMivanlegyartva
            // 
            this.tbMivanlegyartva.Location = new System.Drawing.Point(595, 115);
            this.tbMivanlegyartva.Multiline = true;
            this.tbMivanlegyartva.Name = "tbMivanlegyartva";
            this.tbMivanlegyartva.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbMivanlegyartva.Size = new System.Drawing.Size(360, 214);
            this.tbMivanlegyartva.TabIndex = 1;
            // 
            // lblKimitszeretne
            // 
            this.lblKimitszeretne.AutoSize = true;
            this.lblKimitszeretne.Location = new System.Drawing.Point(16, 90);
            this.lblKimitszeretne.Name = "lblKimitszeretne";
            this.lblKimitszeretne.Size = new System.Drawing.Size(120, 20);
            this.lblKimitszeretne.TabIndex = 2;
            this.lblKimitszeretne.Text = "Ki mit szeretne?";
            // 
            // lblMivanlegyartva
            // 
            this.lblMivanlegyartva.AutoSize = true;
            this.lblMivanlegyartva.Location = new System.Drawing.Point(591, 90);
            this.lblMivanlegyartva.Name = "lblMivanlegyartva";
            this.lblMivanlegyartva.Size = new System.Drawing.Size(144, 20);
            this.lblMivanlegyartva.TabIndex = 3;
            this.lblMivanlegyartva.Text = "Mi van legyártva?";
            // 
            // btnKimitszeretneBe
            // 
            this.btnKimitszeretneBe.Location = new System.Drawing.Point(388, 335);
            this.btnKimitszeretneBe.Name = "btnKimitszeretneBe";
            this.btnKimitszeretneBe.Size = new System.Drawing.Size(200, 30);
            this.btnKimitszeretneBe.TabIndex = 4;
            this.btnKimitszeretneBe.Text = "Adatok feltöltése fájlból";
            this.btnKimitszeretneBe.UseVisualStyleBackColor = true;
            this.btnKimitszeretneBe.Click += new System.EventHandler(this.btnKimitszeretneBe_Click);
            // 
            // btnMivanlegyartvaBe
            // 
            this.btnMivanlegyartvaBe.Location = new System.Drawing.Point(755, 335);
            this.btnMivanlegyartvaBe.Name = "btnMivanlegyartvaBe";
            this.btnMivanlegyartvaBe.Size = new System.Drawing.Size(200, 30);
            this.btnMivanlegyartvaBe.TabIndex = 5;
            this.btnMivanlegyartvaBe.Text = "Adatok feltöltése fájlból";
            this.btnMivanlegyartvaBe.UseVisualStyleBackColor = true;
            this.btnMivanlegyartvaBe.Click += new System.EventHandler(this.btnMivanlegyartvaBe_Click);
            // 
            // tbEredmeny
            // 
            this.tbEredmeny.Location = new System.Drawing.Point(595, 411);
            this.tbEredmeny.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbEredmeny.Multiline = true;
            this.tbEredmeny.Name = "tbEredmeny";
            this.tbEredmeny.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbEredmeny.Size = new System.Drawing.Size(238, 185);
            this.tbEredmeny.TabIndex = 6;
            // 
            // lblEredmeny
            // 
            this.lblEredmeny.AutoSize = true;
            this.lblEredmeny.Location = new System.Drawing.Point(591, 386);
            this.lblEredmeny.Name = "lblEredmeny";
            this.lblEredmeny.Size = new System.Drawing.Size(86, 20);
            this.lblEredmeny.TabIndex = 7;
            this.lblEredmeny.Text = "Eredmény:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.Location = new System.Drawing.Point(12, 19);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(230, 44);
            this.lblTitle.TabIndex = 8;
            this.lblTitle.Text = "Mikulásgyár";
            // 
            // btnEredmenyKi
            // 
            this.btnEredmenyKi.Location = new System.Drawing.Point(840, 500);
            this.btnEredmenyKi.Name = "btnEredmenyKi";
            this.btnEredmenyKi.Size = new System.Drawing.Size(115, 96);
            this.btnEredmenyKi.TabIndex = 9;
            this.btnEredmenyKi.Text = "Eredmény mentése fájlba";
            this.btnEredmenyKi.UseVisualStyleBackColor = true;
            this.btnEredmenyKi.Click += new System.EventHandler(this.btnEredmenyKi_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(840, 410);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(115, 84);
            this.btnStart.TabIndex = 10;
            this.btnStart.Text = "Ajándékok elosztása";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblKimitszeretneUtasitas
            // 
            this.lblKimitszeretneUtasitas.AutoSize = true;
            this.lblKimitszeretneUtasitas.Location = new System.Drawing.Point(-1, 414);
            this.lblKimitszeretneUtasitas.Name = "lblKimitszeretneUtasitas";
            this.lblKimitszeretneUtasitas.Size = new System.Drawing.Size(0, 20);
            this.lblKimitszeretneUtasitas.TabIndex = 11;
            // 
            // tbSugo
            // 
            this.tbSugo.BackColor = System.Drawing.SystemColors.Control;
            this.tbSugo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSugo.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.tbSugo.Location = new System.Drawing.Point(20, 411);
            this.tbSugo.Multiline = true;
            this.tbSugo.Name = "tbSugo";
            this.tbSugo.ReadOnly = true;
            this.tbSugo.Size = new System.Drawing.Size(552, 185);
            this.tbSugo.TabIndex = 12;
            this.tbSugo.Text = resources.GetString("tbSugo.Text");
            // 
            // lblSugo
            // 
            this.lblSugo.AutoSize = true;
            this.lblSugo.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblSugo.Location = new System.Drawing.Point(16, 386);
            this.lblSugo.Name = "lblSugo";
            this.lblSugo.Size = new System.Drawing.Size(45, 20);
            this.lblSugo.TabIndex = 13;
            this.lblSugo.Text = "Súgó";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 618);
            this.Controls.Add(this.lblSugo);
            this.Controls.Add(this.tbSugo);
            this.Controls.Add(this.lblKimitszeretneUtasitas);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnEredmenyKi);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblEredmeny);
            this.Controls.Add(this.tbEredmeny);
            this.Controls.Add(this.btnMivanlegyartvaBe);
            this.Controls.Add(this.btnKimitszeretneBe);
            this.Controls.Add(this.lblMivanlegyartva);
            this.Controls.Add(this.lblKimitszeretne);
            this.Controls.Add(this.tbMivanlegyartva);
            this.Controls.Add(this.tbKimitszeretne);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Mikulásgyár";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbKimitszeretne;
        private System.Windows.Forms.TextBox tbMivanlegyartva;
        private System.Windows.Forms.Label lblKimitszeretne;
        private System.Windows.Forms.Label lblMivanlegyartva;
        private System.Windows.Forms.Button btnKimitszeretneBe;
        private System.Windows.Forms.Button btnMivanlegyartvaBe;
        private System.Windows.Forms.TextBox tbEredmeny;
        private System.Windows.Forms.Label lblEredmeny;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnEredmenyKi;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblKimitszeretneUtasitas;
        private System.Windows.Forms.TextBox tbSugo;
        private System.Windows.Forms.Label lblSugo;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

