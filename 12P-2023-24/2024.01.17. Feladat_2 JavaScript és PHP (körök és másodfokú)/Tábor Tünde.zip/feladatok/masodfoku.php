<!-- Kérje be űrlap segítségével egy másodfokú egyenlet együtthatóit (a,b,c)! 
Ez alapján adja meg az egyenlet megoldását/megoldásait/nincs megoldása (x1,x2 vagy x1 vagy nincs megoldás)'
 Amennyiben egy megoldása van az egyenletnek, akkor csak egy szám/eredmény jelenjen meg, 
 amennyiben kettő, akkor értelemszerűen kettőt. Negatív gyök esetén -->

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1) Másodfokú</title>
</head>
<body>
    <?php
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            $uzenet = "Adja meg az adatokat";
        }else{
            megoldas();
            $uzenet = isset($m) ? "Az egyenlet megoldása(i): ".join(", ", $m) : "Az egyenletnek nincs megoldása.";
        }
        $m;
        function megoldas(){
            global $m;
            $a = $_POST['a'];
            $b = $_POST['b']; 
            $c = $_POST['c'];
            $d = $b*$b - 4*$a*$c;
            if ($d<0) return false;
            if($d == 0) $m = array(-$b / 2*$a);
            else $m = array((-$b + sqrt($d)) / (2*$a), (-$b - sqrt($d)) / (2*$a));
        }
    ?>

    <div>
        <h2>1) Másodfokú</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <label for="a">a</label>
            <input required type="number" name="a"><br>
            <label for="b">b</label>
            <input required type="number" name="b"><br>
            <label for="c">c</label>
            <input required type="number" name="c"><br>
            <input type="submit" value="OK">       
        </form>
        <p><?php print $uzenet ?></p>
    </div>  
</body>
</html>