<h2>Kapcsolat</h2>

E cím alatt jellemzően egy webes űrlap szokott megjelenni, mely lehetővé teszi,
hogy közvetlenül az oldalon keresztül írjuk üzenetet vagy kérdést az üzemeltetőnek, 
cégnek, esetleg a cégen belül bármelyik felelős munkatársnak.