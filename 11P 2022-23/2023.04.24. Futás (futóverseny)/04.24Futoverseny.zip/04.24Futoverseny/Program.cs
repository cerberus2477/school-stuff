﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _04._24Futoverseny
{
	class Program
	{
		static Jegyzokonyv jegyzokonyv = new Jegyzokonyv(); 
		static string[] menupontok = { "Új futó", "Indulási és érkezési idő rögzítése", "Listázás időeredmény szerint", "Kilépés" };




		public class Versenyzo
		{
			private string nev, egyesulet;
			private int rajtszam;
			private TimeSpan indulas = new TimeSpan(0, 0, 0);
			private TimeSpan erkezes = new TimeSpan(0, 0, 0);

			public Versenyzo(string nev, string egyesulet, int rajtszam)
			{
				this.nev = nev;
				this.egyesulet = egyesulet;
				this.rajtszam = rajtszam;
			}

			public void indulasiBe(TimeSpan indulas)
			{
				this.indulas = indulas;
			}

			public void ErkezesiBe(TimeSpan erkezes)
			{
				this.erkezes = erkezes;
			}


			public bool RajtszamHasonlit(int rajtszam)
			{
				return this.rajtszam == rajtszam;
			}

			//Névhasonlít nincs, a CompareTo ezek feladatát is ellátja. (csak a CompareTo használná ezeket)
			public int CompareTo(Versenyzo valaki)
			{
				if(IdoMp() < valaki.IdoMp())
				{
					return -1;
				}
				else if(IdoMp() > valaki.IdoMp())
				{
					return 1;
				}
				else
				{
					if(nev.CompareTo(valaki.nev) == -1)
					{
						return -1;
					}
					else if(nev.CompareTo(valaki.nev) == 1)
					{
						return 1;
					}
					else
					{
						return 0;
					}
				}
			}

			public int IdoMp()
			{
				return Convert.ToInt32(erkezes.TotalSeconds - indulas.TotalSeconds);
			}

			public override string ToString()
			{
				//Console.WriteLine();
				//return "{0:-10}{0:-30}{0:10}", this.rajtszam, this.nev, this.IdoMp();
				return $"{rajtszam} - {nev} - {IdoMp()}";

			}
		}




		class Jegyzokonyv
		{
			private Versenyzo[] futok = new Versenyzo[10000];
			private int db = 0;

			public void Hozzaad(string nev, string egyesulet, int rajtszam)
			{
				futok[db] = new Versenyzo(nev, egyesulet, rajtszam);
				db++;
			}

			public int Keres(int rajtszam) //feltételez hogy van ilyen
			{
				int i = 0;
				while(i < db && !futok[i].RajtszamHasonlit(rajtszam))
				{
					i++;
				}
				return i;
			}

			public void IndIdoBe(int rajtszam, TimeSpan indulas)
			{
				int a = Keres(rajtszam);
				futok[a].indulasiBe(indulas);
			}

			public void ErkIdoBe(int rajtszam, TimeSpan erkezes)
			{
				futok[Keres(rajtszam)].ErkezesiBe(erkezes);
			}

			public void Rendez()
			{
				for(int i = 0; i < db; i++)
				{
					int min = i;
					for(int j = i + 1; j < db; j++)
					{
						if(futok[j].CompareTo(futok[min]) == -1)
						{
							min = j;
						}
					}
					var temp = futok[i];
					futok[i] = futok[min];
					futok[min] = temp;
				}
			}

			public void Listaz()
			{
				Rendez();
				//Console.WriteLine("{0:-10}|{1:-10}|{2:-30}{3:-10}", "Helyezés", "Rajtszám", "Név", "Idő");
				Console.WriteLine("Helyezés - Rajtszám - Név - Idő");
				Console.WriteLine("----------------------------------------------------------------------------------");
				for(int i = 0; i < db; i++)
				{
					//Console.WriteLine("{0:-10}|{0:-10}|{0:-30}|{0:-10}", i, futok[i].rajtszam, futok[i].nev, futok[i].IdoMp());
					Console.WriteLine($"{i+1} - {futok[i]}");
				}
			}
		}




		static void Main(string[] args)
		{
			bool run = true;
			while(run)
			{
				Console.Clear();
				Console.Title = "Futóverseny";
				for(int i = 0; i < menupontok.Length; i++)
				{
					Console.WriteLine($"{i + 1}. {menupontok[i]}");
				}

				Console.Write("\nAdja meg a választott menüpont számát: ");
				int valasztott = int.Parse(Console.ReadLine());
				switch(valasztott)
				{
					case 1:
						Console.Title = menupontok[valasztott-1];
						Console.Clear();
						Console.WriteLine("Adja meg a szükséges adatokat!");

						Console.Write("\tNév: ");
						string nev = Console.ReadLine();
						Console.Write("\tEgyesület: ");
						string egyesulet = Console.ReadLine();
						Console.Write("\tRajtszám: ");
						int rajtszam = int.Parse(Console.ReadLine());

						jegyzokonyv.Hozzaad(nev, egyesulet, rajtszam);
						Console.WriteLine("\nA hozzáadás sikeres volt.\nNyomjon le egy billentyűt a visszalépéshez!");
						Console.ReadKey();
						break;

					case 2:
						Console.Title = menupontok[valasztott - 1];
						Console.Clear();
						Console.WriteLine("Adja meg a szükséges adatokat!");

						Console.Write("\tRajtszám: ");
						int rajtsz = int.Parse(Console.ReadLine());
						Console.Write("\tIndulási idő (hh:mm:ss): ");
						int[] ind = Array.ConvertAll(Console.ReadLine().Split(':'), int.Parse);
						Console.Write("\tÉrkezési idő (hh:mm:ss): ");
						int[] erk = Array.ConvertAll(Console.ReadLine().Split(':'), int.Parse);

						jegyzokonyv.IndIdoBe(rajtsz, new TimeSpan(ind[0], ind[1], ind[2]));
						jegyzokonyv.ErkIdoBe(rajtsz, new TimeSpan(erk[0], erk[1], erk[2]));
						Console.WriteLine("\nA hozzáadás sikeres volt.\nNyomjon le egy billentyűt a visszalépéshez!");
						Console.ReadKey();

						break;

					case 3:
						Console.Title = menupontok[valasztott - 1];
						Console.Clear();

						jegyzokonyv.Listaz();
						Console.WriteLine("\nNyomjon le egy billentyűt a visszalépéshez!");
						Console.ReadKey();
						break;

					case 4:
						Console.Title = menupontok[valasztott - 1];
						Console.Clear();

						Console.WriteLine("A program 3 másodperc múlva leáll.\nViszontlátásra!");
						Thread.Sleep(3000);
						Environment.Exit(0);
						break;

					default:
						Console.WriteLine("\nA megadott számok közül válasszon!\nNyomjon le egy billentyűt a visszalépéshez!");
						Console.ReadKey();
						break;
				}
			}
		}
	}
}
