﻿
namespace szamologep {
	partial class szamologep {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if(disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.display = new System.Windows.Forms.TextBox();
			this.btnPlus = new System.Windows.Forms.Button();
			this.btnMinus = new System.Windows.Forms.Button();
			this.btnMultiply = new System.Windows.Forms.Button();
			this.btnDivide = new System.Windows.Forms.Button();
			this.btn1 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn6 = new System.Windows.Forms.Button();
			this.btn7 = new System.Windows.Forms.Button();
			this.btn8 = new System.Windows.Forms.Button();
			this.btn9 = new System.Windows.Forms.Button();
			this.btn0 = new System.Windows.Forms.Button();
			this.btnSquare = new System.Windows.Forms.Button();
			this.btnRoot = new System.Windows.Forms.Button();
			this.btnEquals = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnStartP = new System.Windows.Forms.Button();
			this.btnEndP = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// display
			// 
			this.display.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(238)))), ((int)(((byte)(224)))));
			this.display.Cursor = System.Windows.Forms.Cursors.Default;
			this.display.Location = new System.Drawing.Point(25, 37);
			this.display.Multiline = true;
			this.display.Name = "display";
			this.display.Size = new System.Drawing.Size(400, 80);
			this.display.TabIndex = 1;
			// 
			// btnPlus
			// 
			this.btnPlus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnPlus.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnPlus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPlus.Location = new System.Drawing.Point(301, 139);
			this.btnPlus.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnPlus.Name = "btnPlus";
			this.btnPlus.Size = new System.Drawing.Size(124, 80);
			this.btnPlus.TabIndex = 5;
			this.btnPlus.Text = "+";
			this.btnPlus.UseVisualStyleBackColor = false;
			this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
			// 
			// btnMinus
			// 
			this.btnMinus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnMinus.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnMinus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnMinus.Location = new System.Drawing.Point(301, 229);
			this.btnMinus.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnMinus.Name = "btnMinus";
			this.btnMinus.Size = new System.Drawing.Size(124, 80);
			this.btnMinus.TabIndex = 6;
			this.btnMinus.Text = "-";
			this.btnMinus.UseVisualStyleBackColor = false;
			// 
			// btnMultiply
			// 
			this.btnMultiply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnMultiply.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnMultiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnMultiply.Location = new System.Drawing.Point(301, 319);
			this.btnMultiply.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnMultiply.Name = "btnMultiply";
			this.btnMultiply.Size = new System.Drawing.Size(124, 80);
			this.btnMultiply.TabIndex = 7;
			this.btnMultiply.Text = "×";
			this.btnMultiply.UseVisualStyleBackColor = false;
			// 
			// btnDivide
			// 
			this.btnDivide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnDivide.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnDivide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDivide.Location = new System.Drawing.Point(301, 409);
			this.btnDivide.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnDivide.Name = "btnDivide";
			this.btnDivide.Size = new System.Drawing.Size(124, 80);
			this.btnDivide.TabIndex = 8;
			this.btnDivide.Text = "/";
			this.btnDivide.UseVisualStyleBackColor = false;
			// 
			// btn1
			// 
			this.btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn1.Location = new System.Drawing.Point(25, 139);
			this.btn1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(80, 80);
			this.btn1.TabIndex = 2;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = false;
			this.btn1.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn2
			// 
			this.btn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn2.Location = new System.Drawing.Point(117, 139);
			this.btn2.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(80, 80);
			this.btn2.TabIndex = 3;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = false;
			this.btn2.Click += new System.EventHandler(this.btn2_Click);
			// 
			// btn3
			// 
			this.btn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn3.Location = new System.Drawing.Point(209, 139);
			this.btn3.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(80, 80);
			this.btn3.TabIndex = 4;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = false;
			this.btn3.Click += new System.EventHandler(this.btn3_Click);
			// 
			// btn4
			// 
			this.btn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn4.Location = new System.Drawing.Point(25, 229);
			this.btn4.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(80, 80);
			this.btn4.TabIndex = 5;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = false;
			this.btn4.Click += new System.EventHandler(this.btn4_Click);
			// 
			// btn5
			// 
			this.btn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn5.Location = new System.Drawing.Point(117, 229);
			this.btn5.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(80, 80);
			this.btn5.TabIndex = 6;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = false;
			this.btn5.Click += new System.EventHandler(this.btn5_Click);
			// 
			// btn6
			// 
			this.btn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn6.Location = new System.Drawing.Point(209, 229);
			this.btn6.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn6.Name = "btn6";
			this.btn6.Size = new System.Drawing.Size(80, 80);
			this.btn6.TabIndex = 7;
			this.btn6.Text = "6";
			this.btn6.UseVisualStyleBackColor = false;
			this.btn6.Click += new System.EventHandler(this.btn6_Click);
			// 
			// btn7
			// 
			this.btn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn7.Location = new System.Drawing.Point(25, 319);
			this.btn7.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn7.Name = "btn7";
			this.btn7.Size = new System.Drawing.Size(80, 80);
			this.btn7.TabIndex = 8;
			this.btn7.Text = "7";
			this.btn7.UseVisualStyleBackColor = false;
			this.btn7.Click += new System.EventHandler(this.btn7_Click);
			// 
			// btn8
			// 
			this.btn8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn8.Location = new System.Drawing.Point(117, 319);
			this.btn8.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn8.Name = "btn8";
			this.btn8.Size = new System.Drawing.Size(80, 80);
			this.btn8.TabIndex = 9;
			this.btn8.Text = "8";
			this.btn8.UseVisualStyleBackColor = false;
			this.btn8.Click += new System.EventHandler(this.btn8_Click);
			// 
			// btn9
			// 
			this.btn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btn9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn9.Location = new System.Drawing.Point(209, 319);
			this.btn9.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn9.Name = "btn9";
			this.btn9.Size = new System.Drawing.Size(80, 80);
			this.btn9.TabIndex = 10;
			this.btn9.Text = "9";
			this.btn9.UseVisualStyleBackColor = false;
			this.btn9.Click += new System.EventHandler(this.btn9_Click);
			// 
			// btn0
			// 
			this.btn0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(93)))), ((int)(((byte)(110)))));
			this.btn0.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn0.Location = new System.Drawing.Point(25, 409);
			this.btn0.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btn0.Name = "btn0";
			this.btn0.Size = new System.Drawing.Size(80, 80);
			this.btn0.TabIndex = 18;
			this.btn0.Text = "0";
			this.btn0.UseVisualStyleBackColor = false;
			this.btn0.Click += new System.EventHandler(this.btn0_Click);
			// 
			// btnSquare
			// 
			this.btnSquare.AllowDrop = true;
			this.btnSquare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnSquare.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnSquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSquare.Location = new System.Drawing.Point(209, 499);
			this.btnSquare.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnSquare.Name = "btnSquare";
			this.btnSquare.Size = new System.Drawing.Size(80, 80);
			this.btnSquare.TabIndex = 19;
			this.btnSquare.Text = "x²";
			this.btnSquare.UseVisualStyleBackColor = false;
			// 
			// btnRoot
			// 
			this.btnRoot.AllowDrop = true;
			this.btnRoot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(69)))), ((int)(((byte)(87)))));
			this.btnRoot.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnRoot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnRoot.Location = new System.Drawing.Point(117, 499);
			this.btnRoot.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnRoot.Name = "btnRoot";
			this.btnRoot.Size = new System.Drawing.Size(80, 80);
			this.btnRoot.TabIndex = 20;
			this.btnRoot.Text = "√";
			this.btnRoot.UseVisualStyleBackColor = false;
			// 
			// btnEquals
			// 
			this.btnEquals.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(167)))), ((int)(((byte)(130)))), ((int)(((byte)(159)))));
			this.btnEquals.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnEquals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEquals.Location = new System.Drawing.Point(301, 499);
			this.btnEquals.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnEquals.Name = "btnEquals";
			this.btnEquals.Size = new System.Drawing.Size(124, 80);
			this.btnEquals.TabIndex = 21;
			this.btnEquals.Text = "=";
			this.btnEquals.UseVisualStyleBackColor = false;
			this.btnEquals.Click += new System.EventHandler(this.btnEquals_Click);
			// 
			// btnClear
			// 
			this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(93)))), ((int)(((byte)(110)))));
			this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClear.Location = new System.Drawing.Point(25, 499);
			this.btnClear.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(80, 80);
			this.btnClear.TabIndex = 22;
			this.btnClear.Text = "CLR";
			this.btnClear.UseVisualStyleBackColor = false;
			// 
			// btnStartP
			// 
			this.btnStartP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(93)))), ((int)(((byte)(110)))));
			this.btnStartP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnStartP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnStartP.Location = new System.Drawing.Point(117, 409);
			this.btnStartP.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnStartP.Name = "btnStartP";
			this.btnStartP.Size = new System.Drawing.Size(80, 80);
			this.btnStartP.TabIndex = 23;
			this.btnStartP.Text = "(";
			this.btnStartP.UseVisualStyleBackColor = false;
			// 
			// btnEndP
			// 
			this.btnEndP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(93)))), ((int)(((byte)(110)))));
			this.btnEndP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.btnEndP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEndP.Location = new System.Drawing.Point(209, 409);
			this.btnEndP.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.btnEndP.Name = "btnEndP";
			this.btnEndP.Size = new System.Drawing.Size(80, 80);
			this.btnEndP.TabIndex = 24;
			this.btnEndP.Text = ")";
			this.btnEndP.UseVisualStyleBackColor = false;
			// 
			// szamologep
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(54)))), ((int)(((byte)(70)))));
			this.ClientSize = new System.Drawing.Size(451, 615);
			this.Controls.Add(this.btnEndP);
			this.Controls.Add(this.btnStartP);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnEquals);
			this.Controls.Add(this.btnRoot);
			this.Controls.Add(this.btnSquare);
			this.Controls.Add(this.btn0);
			this.Controls.Add(this.btn9);
			this.Controls.Add(this.btn8);
			this.Controls.Add(this.btn7);
			this.Controls.Add(this.btn6);
			this.Controls.Add(this.btn5);
			this.Controls.Add(this.btn4);
			this.Controls.Add(this.btn3);
			this.Controls.Add(this.btn2);
			this.Controls.Add(this.btn1);
			this.Controls.Add(this.btnDivide);
			this.Controls.Add(this.btnMultiply);
			this.Controls.Add(this.btnMinus);
			this.Controls.Add(this.btnPlus);
			this.Controls.Add(this.display);
			this.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(238)))), ((int)(((byte)(224)))));
			this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.Name = "szamologep";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.szamologep_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox display;
		private System.Windows.Forms.Button btnPlus;
		private System.Windows.Forms.Button btnMinus;
		private System.Windows.Forms.Button btnMultiply;
		private System.Windows.Forms.Button btnDivide;
		private System.Windows.Forms.Button btn1;
		private System.Windows.Forms.Button btn2;
		private System.Windows.Forms.Button btn3;
		private System.Windows.Forms.Button btn4;
		private System.Windows.Forms.Button btn5;
		private System.Windows.Forms.Button btn6;
		private System.Windows.Forms.Button btn7;
		private System.Windows.Forms.Button btn8;
		private System.Windows.Forms.Button btn9;
		private System.Windows.Forms.Button btn0;
		private System.Windows.Forms.Button btnSquare;
		private System.Windows.Forms.Button btnRoot;
		private System.Windows.Forms.Button btnEquals;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnStartP;
		private System.Windows.Forms.Button btnEndP;
	}
}

