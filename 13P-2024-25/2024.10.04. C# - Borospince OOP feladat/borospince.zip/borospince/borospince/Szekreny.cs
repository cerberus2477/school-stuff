﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace borospince
{
    internal class Szekreny
    {
        private List<Bor> borok;

        public Szekreny() {
            borok = new List<Bor>();
        }

        public Bor GetBor(int n)
        {
            if (n < 0 || n >= borok.Count) throw new BorospinceException("Nem letezo index!");
            return borok[n];
        }

        // += operátor nem felüldefiniálható (not overloadable) ezért helyette AddBor metódust írtam.
        public void AddBor(object obj)
        {
            if (!(obj is Bor bor)) throw new BorospinceException("TypeError: Nem bor!");
            borok.Add(bor);
        }

        
        public static Szekreny operator + (Szekreny szekreny1, object obj)
        {
            if (!(obj is Szekreny szekreny2)) throw new BorospinceException("TypeError: Nem szekreny!");
            Szekreny ujSzekreny = new Szekreny();
            ujSzekreny.borok.AddRange(szekreny1.borok); 
            ujSzekreny.borok.AddRange(szekreny2.borok); 
            return ujSzekreny;
        }

        public double AtlagAlkoholtartalom()
        {
            if (!borok.Any()) throw new BorospinceException("Ures a szekreny!");
            return borok.Average(b => b.Alkoholtartalom);
        }

        public Dictionary<string, int> Statisztika()
        {
            Dictionary<string, int> statisztika = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase); //így pl ASZU és aszu egyelőek.

            foreach (Bor bor in borok)
            {
                string fajta = bor.Fajta;

                if (statisztika.ContainsKey(fajta)) statisztika[fajta]++;
                else statisztika[fajta] = 1;
            }

            return statisztika;
        }


        //bor törlése, ha nem sikerül a törlés bor nem található exception
        public void Megisszak(object obj)
        {
            if (!(obj is Bor bor)) throw new BorospinceException("TypeError: Nem bor!");
            if (!borok.Remove(bor)) throw new BorospinceException("Bor nem található!");
        }

        public override string ToString()
        {
            if (borok.Count == 0) return "Ez egy ures szekreny.";
            return  string.Join(", ", Statisztika().Select(kvp => $"{kvp.Value} {kvp.Key}"));
        }

    }
}


   
