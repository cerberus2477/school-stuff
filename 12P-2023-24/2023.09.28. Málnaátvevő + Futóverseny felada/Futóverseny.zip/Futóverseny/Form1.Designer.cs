﻿
namespace Futóverseny
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.bevitel = new System.Windows.Forms.Panel();
			this.btnListaz = new System.Windows.Forms.Button();
			this.btnIdo = new System.Windows.Forms.Button();
			this.btnVersenyzo = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// bevitel
			// 
			this.bevitel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(197)))), ((int)(((byte)(121)))));
			this.bevitel.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bevitel.Location = new System.Drawing.Point(0, 337);
			this.bevitel.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
			this.bevitel.Name = "bevitel";
			this.bevitel.Size = new System.Drawing.Size(366, 268);
			this.bevitel.TabIndex = 0;
			// 
			// btnListaz
			// 
			this.btnListaz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(221)))));
			this.btnListaz.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnListaz.FlatAppearance.BorderSize = 0;
			this.btnListaz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(50)))));
			this.btnListaz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnListaz.Location = new System.Drawing.Point(14, 80);
			this.btnListaz.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
			this.btnListaz.Name = "btnListaz";
			this.btnListaz.Size = new System.Drawing.Size(125, 32);
			this.btnListaz.TabIndex = 0;
			this.btnListaz.Text = "&Listáz";
			this.btnListaz.UseVisualStyleBackColor = false;
			// 
			// btnIdo
			// 
			this.btnIdo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(221)))));
			this.btnIdo.FlatAppearance.BorderSize = 0;
			this.btnIdo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(50)))));
			this.btnIdo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnIdo.Location = new System.Drawing.Point(14, 207);
			this.btnIdo.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
			this.btnIdo.Name = "btnIdo";
			this.btnIdo.Size = new System.Drawing.Size(183, 37);
			this.btnIdo.TabIndex = 1;
			this.btnIdo.Text = "&Idő hozzáadása";
			this.btnIdo.UseVisualStyleBackColor = false;
			// 
			// btnVersenyzo
			// 
			this.btnVersenyzo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(221)))));
			this.btnVersenyzo.FlatAppearance.BorderSize = 0;
			this.btnVersenyzo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(50)))));
			this.btnVersenyzo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnVersenyzo.Location = new System.Drawing.Point(14, 139);
			this.btnVersenyzo.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
			this.btnVersenyzo.Name = "btnVersenyzo";
			this.btnVersenyzo.Size = new System.Drawing.Size(251, 37);
			this.btnVersenyzo.TabIndex = 2;
			this.btnVersenyzo.Text = "Új versenyző rögzítése";
			this.btnVersenyzo.UseVisualStyleBackColor = false;
			// 
			// textBox1
			// 
			this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(106)))), ((int)(((byte)(112)))));
			this.textBox1.Location = new System.Drawing.Point(372, 195);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(500, 398);
			this.textBox1.TabIndex = 3;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(106)))), ((int)(((byte)(112)))));
			this.panel1.Controls.Add(this.btnVersenyzo);
			this.panel1.Controls.Add(this.btnIdo);
			this.panel1.Controls.Add(this.bevitel);
			this.panel1.Controls.Add(this.btnListaz);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(366, 605);
			this.panel1.TabIndex = 4;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(520, 41);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(102, 21);
			this.label1.TabIndex = 5;
			this.label1.Text = "Futóverseny";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(221)))));
			this.ClientSize = new System.Drawing.Size(910, 605);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.textBox1);
			this.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

		#endregion

		private System.Windows.Forms.Panel bevitel;
		private System.Windows.Forms.Button btnListaz;
		private System.Windows.Forms.Button btnIdo;
		private System.Windows.Forms.Button btnVersenyzo;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label1;
	}
}

