<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4) Prímtényezős</title>
    <style>
    table {
        border-collapse: collapse;
        text-align: right;
    }

    /* belső borderek, itt 1db függőleges vonal */
    table td+td {
        border-left: 1px solid black;
    }
    </style>
</head>

<body>
    <h2>4) Prímtényezős</h2>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label for="number">Felbontandó szám: </label>
        <input type="number" id="number" name="number" required>
        <input type="submit" value="Felbontás">
    </form>

    <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $num = (int)$_POST['number'];
            $primosztok = [];

      
            $i = 2;
            echo "<table><tr><td>".$num."</td>";
            while ($num != 1) {
                if($num % $i == 0) {
                    $primosztok[] = $i;
                    $num /= $i;
                    echo "<td>".$i."</td></tr>";
                    echo "<tr><td>".$num."</td>";
                    $i = 2;
                }
                else $i++; 
            }
            echo "<td></td></tr></table>";

  
            // echo "<p>".$_POST['number']." = ".implode(' * ', $primosztok)."</p>";
            echo "<p>".$_POST['number']." = ";
            foreach (array_unique($primosztok) as $index => $p) {
                echo $p;
                $exponent = count(array_keys($primosztok, $p));
                if ($exponent > 1){
                    echo "<sup>$exponent</sup>";
                }
                if ($index < count(array_unique($primosztok))) echo " * ";
            
            }
            echo "</p>";
        }
    ?>

</body>

</html>