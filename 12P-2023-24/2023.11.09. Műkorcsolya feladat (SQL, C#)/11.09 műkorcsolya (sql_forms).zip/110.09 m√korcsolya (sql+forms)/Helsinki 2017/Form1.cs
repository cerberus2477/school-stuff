﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helsinki_2017
{
    public partial class frmHelsinki : Form
    {
        static readonly Statisztika stat = new Statisztika();
        public frmHelsinki()
        {
            InitializeComponent();
        }


        private void frmHelsinki_Load(object sender, EventArgs e)
        {
            pnlNev.Visible = false;
            stat.addEgyiptom();
            //stat.vegeredmeny();
        }

        private void rövidporgram4FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlNev.Visible = false;
            tbMegoldasok.Text = $"A rövidprogramon {stat.countRovidprogram()} versenyző indult el.";
        }


        private void magyarVersenyző5FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlNev.Visible = false;
            //tbMegoldasok.Text = stat.magyar().Count == 0 ? "A magyar versenyző nem jutott be a kűrbe." : $"A magyar versenyző bejutott a kűrbe.\nNeve: {stat.magyar()[0]}, Pontszáma: {stat.magyar()[1]}";
        }

        private void összpontszám68FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlNev.Visible = true;
            tbMegoldasok.Text = "";
        }

        private void btnNev_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.validNev(tbNev.Text) ? $"A versenyző összpontszáma {stat.ÖsszPontszám(tbNev.Text)} pont volt." : "llyen nevű induló nem volt.";
        }

        private void továbbjutókországonként9feldatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.orszagonkent();
        }
    }
}
