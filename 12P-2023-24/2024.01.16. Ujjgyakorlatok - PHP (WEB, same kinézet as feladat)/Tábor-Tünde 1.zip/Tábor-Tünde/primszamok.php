<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3) Prímszámok</title>

    <style>
    table {
        margin: 0 auto 0 auto;
        border-spacing: 0px;
        background-color: white;
        border: 1px solid #8F8FAF;
        border-radius: 7px;
        padding: 2px;
        font-family: Arial, Helvetica, sans-serif;
    }

    td {
        border: 2px solid white;
        border-radius: 9px;
        background: #FFFFDD;
        padding: .4rem .6rem;
        text-align: center;
    }

    .prim {
        color: #140044;
        background-color: #FFFF88;
        font-weight: bold;
        font-size: large;
    }

    .osszetett {
        text-decoration: line-through;
        background-color: #FFFFBB;
        color: grey;
    }
    </style>
</head>

<body>
    <h2>3) Prímszámok</h2>
    <h6>a linkben /?max=ertek -kel változtatható a méret</h6>

    <?php
    // $m =  (int)$_GET["max"] ?? 100;
    $m =  isset($_GET["max"]) ? (int)$_GET["max"] : 100;
    echo "<table>";

    //egy sorban tíz
    for ($i = 1; $i <= ceil($m/10); $i++) {
        echo "<tr>";
        for ($j = 1; $j <= 10; $j++) {
            $value = ($i-1)*10+$j <= $m ? ($i-1)*10+$j : "";
            if ($value == 1 || $value == "") $class = "";
            else $class = isPrime($value) ? "prim" : "osszetett";
            echo "<td class='".$class."'>".$value."</td>";
        }
        echo "</tr>";
    }
    echo "</table>";

    function isPrime($n) {
        if ($n == 1) return false;
        for ($i = 2; $i <= ceil(sqrt($n)); $i++)
        {
            if ($n % $i == 0) return false;
        }
        return 1;
    }

    ?>

</body>

</html>