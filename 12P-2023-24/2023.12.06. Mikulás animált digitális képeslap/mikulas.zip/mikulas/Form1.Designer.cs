﻿
namespace mikulas
{
    partial class frmMikulas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnTogglePlay = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.picbox = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).BeginInit();
            this.SuspendLayout();
            // 
            // btnTogglePlay
            // 
            this.btnTogglePlay.Location = new System.Drawing.Point(733, 51);
            this.btnTogglePlay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTogglePlay.Name = "btnTogglePlay";
            this.btnTogglePlay.Size = new System.Drawing.Size(112, 35);
            this.btnTogglePlay.TabIndex = 0;
            this.btnTogglePlay.Text = "Stop";
            this.btnTogglePlay.UseVisualStyleBackColor = true;
            this.btnTogglePlay.Click += new System.EventHandler(this.btnTogglePlay_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.Location = new System.Drawing.Point(41, 51);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(209, 58);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Mikulás!";
            // 
            // picbox
            // 
            this.picbox.Location = new System.Drawing.Point(93, 167);
            this.picbox.Name = "picbox";
            this.picbox.Size = new System.Drawing.Size(318, 360);
            this.picbox.TabIndex = 2;
            this.picbox.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 40;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmMikulas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 629);
            this.Controls.Add(this.picbox);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnTogglePlay);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMikulas";
            this.Text = "Mikulás";
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTogglePlay;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox picbox;
        private System.Windows.Forms.Timer timer1;
    }
}

