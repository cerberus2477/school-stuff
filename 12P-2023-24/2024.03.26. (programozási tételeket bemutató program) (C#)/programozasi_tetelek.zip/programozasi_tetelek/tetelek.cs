﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programozasi_tetelek
{
	internal class tetelek
	{
		public static int Sorozatszamitas(int[] idok)
		{
			int osszeg = 0;
			int db = 0;
			foreach(int ido in idok)
			{
				osszeg += ido;
				db++;
			}
			return osszeg / db;
		}

		public static string Kivalasztas(string honap)
		{
			string[] honapok = { "január", "február", "" };
			int i = 0;
			while(honap != honapok[i])
			{
				i++;
			}
			return honapok[i];
		}

		public static bool Eldöntés(int N)
		{
			int I = 2;
			while(I <= N && !(N % I == 0))
			{
				I++;
			}
			return I > N - 1;
		}

		//public static int LinearisKereses(int[] bevetel, int[] kiadas)
		//{
		//}

		public static int Megszamolas(int[] idok, int szint)
		{
			int db = 0;
			foreach(int ido in idok)
			{
				if(ido <= szint)
				{
					db++;
				}
			}
			return db;
		}

		public static int MaximumKivalasztas(int[] szamok)
		{
			int max = szamok[0];
			for(int i = 1; i < szamok.Length; i++)
			{
				if(szamok[i] > max)
				{
					max = szamok[i];
				}
			}
			return max;
		}





		
		 static Random más = new Random();
		static int[] X_alap = new int[200000];
		static int N = 20000, Csere = 30000;


		/*static void TömbFeltölt()
		{
			for(int i = 0; i < N; i++)
			{
				X_alap[i] = i + 1;
			}
		}

		static void Kever()
		{
			int i, j;

			for(int x = 0; x < Csere; x++)
			{
				i = más.Next(0, N - 1);
				j = más.Next(0, N - 1);
				int segéd = X_alap[i];
				X_alap[i] = X_alap[j];
				X_alap[j] = segéd;
			}
		}

		static void Kiír(int[] Tömb, int N)
		{
			for(int i = 0; i < N; i++)
			{
				Console.Write("{0}, ", X_alap[i]);
			}
			Console.WriteLine();
		}

		static void MinimumKiválasztásosRendezés()
		{
			for(int i = 0; i < N - 1; i++)
			{
				int MIN = i;
				for(int j = i + 1; j < N; j++)
				{
					if(X_alap[MIN] > X_alap[j]) MIN = j;
				}
				int segéd = X_alap[i];
				X_alap[i] = X_alap[MIN];
				X_alap[MIN] = segéd;
			}
		}

		static DateTime Most()
		{
			return DateTime.Now;
		}

		static void EgyszerűCserésRendezés()
		{
			for(int i = 0; i < N - 1; i++)
			{
				for(int j = i + 1; j < N; j++)
				{
					if(X_alap[i] > X_alap[j])
					{
						int segéd = X_alap[i];
						X_alap[i] = X_alap[j];
						X_alap[j] = segéd;
					}

				}
			}
		}
		static void JavítottBuborékosRendezés()
		{
			int i = N - 1;
			while(i >= 1)
			{
				int cs = 0;
				for(int j = 0; j < i; j++)
				{
					if(X_alap[j] > X_alap[j + 1])
					{
						int segéd = X_alap[j + 1];
						X_alap[j + 1] = X_alap[j];
						X_alap[j] = segéd;
						cs = j;
					}
				}
				i = cs;
			}
		}

		static void JavítottBeillesztésesRendezés()
		{
			for(int i = 1; i < N; i++)
			{
				int j = i - 1;
				int y = X_alap[i];
				while(j >= 0 && X_alap[j] > y)
				{
					X_alap[j + 1] = X_alap[j]; j--;
				}
				X_alap[j + 1] = y;
			}
		}
		 */




	}
}
