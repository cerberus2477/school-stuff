﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hattertarolo
{
    internal class SSD : Storage
    {
        public SSD(int maxcapgb) : base(maxcapgb) 
        {
        }
    }
}
