﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05._21_Útvonaltervezés
{
	internal class Program
	{
		static SzakaszHandler szh;


		static void Main(string[] args)
		{
			Console.Write("Adja meg a gépkocsi átlagfogyasztását (vesszővel elválasztva): ");
			double auto_fogy =  double.Parse(Console.ReadLine());
			Console.Write("Adja meg az aktuális üzemanyagárat: ");
			int uzemanyagar = int.Parse(Console.ReadLine());
			Console.Write("Adja meg a kezdőpontot (1-1000): ");
			int p1 = int.Parse(Console.ReadLine());
			Console.Write("Adja meg a célt (1-1000): ");
			int p2 = int.Parse(Console.ReadLine());

			szh = new SzakaszHandler("utadatok.txt", uzemanyagar, auto_fogy, p1, p2);
			Console.WriteLine("Optimális útvonalak:\n");
			Console.WriteLine("1) Legkevesebb csomópont");
			szh.Dijkstra(1);
			Console.WriteLine("\n2) Legrövidebb útvonal");
			szh.Dijkstra(2);
			Console.WriteLine("\n3) Legolcsóbb útvonal");
			szh.Dijkstra(3);

			Console.ReadKey();
		}
	}
}
