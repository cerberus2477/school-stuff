﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sudokuGame
{
    public partial class frmSudokuGame : Form
    {
        Logika logika = new Logika();
        public frmSudokuGame()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //majd reszponzív cellaméret kéne
            logika.createCells(3, 40, 40, pnlSudoku);
        }



        
    }
}
