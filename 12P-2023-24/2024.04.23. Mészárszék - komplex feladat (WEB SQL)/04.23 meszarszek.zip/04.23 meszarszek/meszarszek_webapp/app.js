const mysql = require('mysql');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'username',
    password: '',
    database: 'meszarszek'
});

const query_to_table = (query, table) => {
    connection.connect((err) => {
        if (err) {
            alert("Hiba lépett fel az adatbázishoz csatlakozás közben: " + err.stack);
            return;
        }

        connection.query(query, (err,rows) => {
            table.innerHTML = "";

            //oszlopnevek
            let header = table.insertRow(0);
            for (colname in rows[0]) {
                let cell = header.insertCell();
                cell.innerHTML = colname;
            }

            //sorok
            rows.forEach((row, rowi) => {
                let tableRow = table.insertRow(rowi + 1);
                let celli = 0;
                for (colval in row) {
                    let cell = tableRow.insertCell(celli);
                    cell.innerHTML = row[colval];
                    celli++;
                }
            });
        });
        connection.end();
        console.log("Elvileg lefutott");
    });

}
