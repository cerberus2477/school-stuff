﻿using System;
using System.Drawing;
using System.Windows.Forms;


//egyelőre csak páratlan sorokkal működik
namespace pontracsos
{
	public partial class frm_pontracsos : Form
	{
		//public static int stageSize = 400;
		public static int xspace = 70;
		public static int yspace = xspace / 2;
		private gamePoint firstPoint = null;

		private PointState currentPlayer;

		public frm_pontracsos()
		{
			InitializeComponent();
			start();
		}

		private void btn_start_Click(object sender, EventArgs e)
		{
			start();
		}

		private void start()
		{
			createPoints((int)num_size.Value);
			lbl_next.Text = "Piros következik";
			lbl_next.BackColor = Color.Red;
			currentPlayer = PointState.Red;
			firstPoint = null;
			Highlight("first");
		}

		private void createPoints(int size)
		{
			pnl_stage.Controls.Clear();

			//sorok
			for(int i = 0; i < size; i++)
			{
				//egy sor, minden második bejjebb kezdődik
				bool oddrow = i % 2 == 0;
				for(int j = 0; j < (oddrow ? (size + 1) / 2 : (size - 1) / 2); j++)
				{
					gamePoint newPoint = new gamePoint();
					pnl_stage.Controls.Add(newPoint);

					int offsetX = oddrow ? 0 : yspace;
					newPoint.Location = new System.Drawing.Point(offsetX + j * xspace, i * yspace);

					newPoint.Click += Point_Clicked; 
				}
			}
		}

	
		//kijelöli a következő lehetséges mezőket és PointState.Highlightedek lesznek, ezzel sárgák is
		private void Highlight(string highlightCase) //hcase lehet first vagy second
		{
			ChangeAllState(PointState.Highlighted, PointState.Neutral);
			switch(highlightCase)
			{
				case ("first"):
					//every PointState.Neutral; To pointstate.highlighted
					break;
				case ("second"):
					ChangeAllState(PointState.Neutral, PointState.Highlighted);
					break;
				default:
					throw new Exception("Nincs ilyen highlightcase");
					
			}
		}
		private void ChangeAllState(PointState from, PointState to)
		{
			foreach(Control control in pnl_stage.Controls)
			{
				if(control is gamePoint point && point.State == from)
				{
					point.State = to;
				}
			}
		}

		private void Point_Clicked(object sender, EventArgs e)
		{
			gamePoint clickedPoint = sender as gamePoint;
			if(clickedPoint.State == PointState.Highlighted)
			{
				if(firstPoint == null) //a vonal első pontja
				{
					clickedPoint.State = currentPlayer;
					firstPoint = clickedPoint;

					Highlight("second");
				}
				else //a vonal második pontja
				{
					clickedPoint.State = currentPlayer;
					drawLine(firstPoint.Location, clickedPoint.Location, currentPlayer);

					// játékoscsere és az első pont nullázása
					lbl_next.Text = $"{(currentPlayer == PointState.Blue ? "Piros" : "Kék")} következik";
					currentPlayer = (currentPlayer == PointState.Red) ? PointState.Blue : PointState.Red;
					lbl_next.BackColor = State.ToColor(currentPlayer);
					firstPoint = null;

					CheckIfWon(currentPlayer);
					Highlight("first");
				}
			}
		}

		//még nincs meg
		private void CheckIfWon(PointState currentPlayer)
		{

		}

		private void drawLine(Point start, Point end, PointState color)
		{
			Graphics g = pnl_stage.CreateGraphics();
			Pen pen = new Pen(State.ToColor(color), 3);
			start.Offset(6, 6); end.Offset(6, 6); //bele van égetve egyelőre, a gomb fele
			g.DrawLine(pen, start, end);
			pen.Dispose();
			g.Dispose();
		}



		
	}
}
