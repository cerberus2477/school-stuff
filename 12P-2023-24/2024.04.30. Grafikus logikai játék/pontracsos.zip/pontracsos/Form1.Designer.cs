﻿namespace pontracsos
{
	partial class frm_pontracsos
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.pnl_stage = new System.Windows.Forms.Panel();
			this.Méret = new System.Windows.Forms.Label();
			this.num_size = new System.Windows.Forms.NumericUpDown();
			this.btn_start = new System.Windows.Forms.Button();
			this.lbl_next = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.num_size)).BeginInit();
			this.SuspendLayout();
			// 
			// pnl_stage
			// 
			this.pnl_stage.Location = new System.Drawing.Point(15, 60);
			this.pnl_stage.Name = "pnl_stage";
			this.pnl_stage.Size = new System.Drawing.Size(870, 870);
			this.pnl_stage.TabIndex = 0;
			// 
			// Méret
			// 
			this.Méret.AutoSize = true;
			this.Méret.Location = new System.Drawing.Point(12, 9);
			this.Méret.Name = "Méret";
			this.Méret.Size = new System.Drawing.Size(34, 13);
			this.Méret.TabIndex = 1;
			this.Méret.Text = "Méret";
			// 
			// num_size
			// 
			this.num_size.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
			this.num_size.Location = new System.Drawing.Point(52, 7);
			this.num_size.Maximum = new decimal(new int[] {
            25,
            0,
            0,
            0});
			this.num_size.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
			this.num_size.Name = "num_size";
			this.num_size.Size = new System.Drawing.Size(120, 20);
			this.num_size.TabIndex = 2;
			this.num_size.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
			// 
			// btn_start
			// 
			this.btn_start.Location = new System.Drawing.Point(178, 4);
			this.btn_start.Name = "btn_start";
			this.btn_start.Size = new System.Drawing.Size(75, 23);
			this.btn_start.TabIndex = 3;
			this.btn_start.Text = "Start";
			this.btn_start.UseVisualStyleBackColor = true;
			this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
			// 
			// lbl_next
			// 
			this.lbl_next.AutoSize = true;
			this.lbl_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.lbl_next.ForeColor = System.Drawing.Color.White;
			this.lbl_next.Location = new System.Drawing.Point(705, 9);
			this.lbl_next.Name = "lbl_next";
			this.lbl_next.Size = new System.Drawing.Size(200, 24);
			this.lbl_next.TabIndex = 4;
			this.lbl_next.Text = "szöveg szöveg szöveg";
			// 
			// frm_pontracsos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(904, 961);
			this.Controls.Add(this.lbl_next);
			this.Controls.Add(this.btn_start);
			this.Controls.Add(this.num_size);
			this.Controls.Add(this.Méret);
			this.Controls.Add(this.pnl_stage);
			this.Name = "frm_pontracsos";
			this.Text = "Pontrácsos játék";
			((System.ComponentModel.ISupportInitialize)(this.num_size)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.Panel pnl_stage;
		private System.Windows.Forms.Label Méret;
		private System.Windows.Forms.NumericUpDown num_size;
		private System.Windows.Forms.Button btn_start;
		private System.Windows.Forms.Label lbl_next;
	}
}

