﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mikulas
{
    public partial class frmMikulas : Form
    {
        static bool run = true;
        static int counter = -1;

        public frmMikulas()
        {
            InitializeComponent();

        }

        public void Animate()
        {
           if (run)
            {
                counter = counter == 73 ? 0 : counter + 1;
                //this.SuspendLayout();
                picbox.Image = Image.FromFile($"picbox/frame_{counter}_delay-0.04s.png");
                //this.ResumeLayout();
            }
        }

        private void btnTogglePlay_Click(object sender, EventArgs e)
        {
            run = !run;
            btnTogglePlay.Text = run ? "Stop" : "Start";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Animate();
        }
    }
}
