﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sudokuGame
{
    internal class Logika
    {
        SudokuCell[,] cells;
        Random rnd = new Random();
        public void createCells(int dim, int cwidth, int cheight, Panel pnl)
        {
            cells = new SudokuCell[dim*dim, dim*dim];

            for (int i = 0; i < dim*dim; i++)
            {
                for (int j = 0; j < dim*dim; j++)
                {
                    cells[i, j] = new SudokuCell();
                    cells[i, j].Size = new Size(cwidth, cheight);
                    cells[i, j].Location = new Point(i * cwidth, j * cheight);

                    cells[i, j].X = i;
                    cells[i, j].Y = j;

                    pnl.Controls.Add(cells[i, j]);
                }
            }
        }


        private void newGame()
        {
            // Clear the values in each cells
            foreach (var cell in cells)
            {
                cell.currentValue = 0;
            }

            // This method will be called recursively 
            // until it finds suitable values for each cells
            findNextValue(0, -1);
        }

        
        //BACKTRACK ÉS REKURZÍV
        //próbálkoztam c:
        private bool findNextValue(int i, int j)
        {
            // i, növelése a sorban a következő cellára, majd a következő sor első cellájára
            if (++j > 8)
            {
                j = 0;

                //kilépés ha vége a sornak
                if (++i > 8)
                    return true;
            }

            int rndNum = 0;
            List<int> possibleNums = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //addig keres random számot amíg jó nem lesz és a következőre cellára lép majd arra is keres megoldást
            do
            {
                //ha már nincs más lehetőség (nincs több a possibleNums listában) visszalép 
                if (possibleNums.Count == 0)
                {
                    cells[i, j].currentValue = 0;
                    return false;
                }

                //random számot választ a maradék értékek (possibleNums) közül
                rndNum = possibleNums[rnd.Next(0, possibleNums.Count)];
                cells[i, j].Solution = rndNum;

                // törlés
                possibleNums.Remove(rndNum);
            }
            while (!isValidCell(rndNum, i, j) || !findNextValue(i, j));

            //cells[i, j].Value = value;

            return true;
        }


        private bool isValidCell(int value, int x, int y)
        {
            for (int i = 0; i < 9; i++)
            {
                // függőleges
                if (i != y && cells[x, i].Value == value)
                    return false;

                // vizszintes
                if (i != x && cells[i, y].Value == value)
                    return false;
            }

            // kockaban
            for (int i = x - (x % 3); i < x - (x % 3) + 3; i++)
            {
                for (int j = y - (y % 3); j < y - (y % 3) + 3; j++)
                {
                    if (i != x && j != y && cells[i, j].Value == value)
                        return false;
                }
            }

            return true;
        }


    }
}
