<!-- suliban működött, itthon már nem. lehet rossz fájlt töltöttem fel. -->
<!-- diagram nincs -->


<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1) Szavazás</title>
</head>

<body>
    <h1>1) Szavazás</h1>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <p><input type="radio" name="nyamm" id="kakaos" value="kakaos" required>Kakaós csiga</p>
        <p><input type="radio" name="nyamm" id="lekvaros" value="lekvaros" required>Lekváros bukta</p>
        <p><input type="radio" name="nyamm" id="makos" value="makos" required>Mákos tészta</p>
        <p><input type="radio" name="nyamm" id="turos" value="turos" required>Túros csusza</p>
        <input type="submit" value="Szavazok">
    </form>

    <?php 
        $save_file = "save.csv";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            //adatok beolvasása fájlból
            if (file_exists($save_file)) {
                $fr = fopen($save_file, "r");
                while (!feof($fr)) {
                    $sor = explode(";", fgets($fr));
                    $adatok[$sor[0]] = (int)$sor[1];
                }
                fclose($fr);
            }
            else{
                $adatok = ["kakaos" => 0, "lekvaros" => 0, "makos" => 0, "turos" => 0];
            }

            $adatok[$_POST["nyamm"]] ++;

            //adatok írása
            $fw = fopen($save_file, "w");
            foreach ($adatok as $nev => $szam) {
                fputcsv($fw, array($nev, $szam), ';');
            }
            fclose($fw);
            //fputcsv minden sor végére tesz /n-t, a legvégéről le kell vágni
            $fw = fopen($save_file, "w");
            fwrite($fw, rtrim(file_get_contents($save_file)));
            fclose($fw);
        } 
    ?>

</body>

</html>