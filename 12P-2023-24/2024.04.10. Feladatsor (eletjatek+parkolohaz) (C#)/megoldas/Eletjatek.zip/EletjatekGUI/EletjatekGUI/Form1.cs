﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//valamiért a checkboxok kicsik maradnak, de jó helyre kerülnek (eloszlanak a rendelkezésre álló térben csak nem nőnek meg (??)) tehát maga a számítás jó
namespace EletjatekGUI
{
    public partial class frm_eletjatekGUI : Form
    {
        int rowCount = 0;
        int columnCount = 0;
        int pnlDim = 350; //350px széles és magas

        public frm_eletjatekGUI()
        {
            InitializeComponent();

            // Legördülő listák feltöltése
            for (int i = 5; i <= 20; i++)
            {
                cb_sorokSzama.Items.Add(i);
                cb_oszlopokSzama.Items.Add(i);
            }

            // Alapértelmezett érték beállítása
            cb_sorokSzama.SelectedItem = 20;
            cb_oszlopokSzama.SelectedItem = 20;

            pnl_matrix.Size = new System.Drawing.Size(pnlDim, pnlDim);

            
        }


        private void btn_createMatrix_Click(object sender, EventArgs e)
        {
            //sor és oszlop lekérése
            rowCount = (int)cb_sorokSzama.SelectedItem;
            columnCount = (int)cb_oszlopokSzama.SelectedItem;

            pnl_matrix.Controls.Clear();

            //egy checkbox mérete a maximális lesz amivel még elfér az összes a panelben
            int chbxDim = (int)(pnlDim / (rowCount > columnCount ? rowCount : columnCount));
            
            // Checkboxok létrehozása
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < columnCount; j++)
                {
                    CheckBox checkBox = new CheckBox();
                    checkBox.Size = new Size(chbxDim, chbxDim);
                    checkBox.Location = new Point(j * chbxDim, i * chbxDim);
                    pnl_matrix.Controls.Add(checkBox);
                }
            }
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            string fname = $"Eletjatek_{rowCount}x{columnCount}.txt";

            string content = "";
            int index = 0;
            foreach (CheckBox checkBox in pnl_matrix.Controls)
            {
                if (index > 0 && index % rowCount == 0) content += Environment.NewLine;
                content += checkBox.Checked ? "1" : "0";
                index++;
            }

            System.IO.File.WriteAllText(fname, content);
            MessageBox.Show($"Állás mentve a {fname} fájlba (bin/debug könyvtárba)!");
        }
    }
}
