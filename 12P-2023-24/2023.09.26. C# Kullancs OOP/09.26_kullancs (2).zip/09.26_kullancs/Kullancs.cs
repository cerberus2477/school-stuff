﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;

namespace _09._26_kullancs
{
    internal class Kullancs
    {
        /*Készítsük el egy kullancs osztályt.
             * Az osztály tartalmazza a kullancs laborbeli sorszámát(egész),
             * a lelőhelyét(szöveg),
             * és egy listát(szövegekből), amely tartalmazza a benne talált fertőzéseket.*/
        

        private int sorszam;
        private string lelohely;
        private List<string> fertozesek;

        /*Készítsen konstruktort, property-ket, + operátort,*/
        public Kullancs(int sorszam, string lelohely, List<string> fertozesek)
        {
            this.sorszam = sorszam;
            this.lelohely = lelohely;
            this.fertozesek = fertozesek;
        }

        public int Sorszam { get; set; }
        public string Lelohely { get; set; }
        public List<string> Fertozesek { get; set; }

        /* + oparátort, amellyel egy újabb fertőzést lehet hozzáadni a listához,*/
        public static Kullancs operator+ (Kullancs kullancs, string lelohely)
        {
            kullancs.fertozesek.Add(lelohely);
            return kullancs;
        }

        /* a <= operátort (a fertőzések számát hasonlítja össze),*/
        public static bool operator <= (Kullancs k1, Kullancs k2)
        {
            return k1.fertozesek.Count() <= k2.fertozesek.Count();
        }

        public static bool operator >= (Kullancs k1, Kullancs k2)
        {
            return k1.fertozesek.Count() >= k2.fertozesek.Count();
        }


        /*egy függvényt ,amely visszaadja a fertőzések számát(lista hossza)*/
        public int FertozesCount()
        {
            return this.fertozesek.Count();
        }


        /* és egy ToString metódust.*/
        public override string ToString()
        {
            string s = "                                                 \n";
            return String.Format("{0:10}{1:-20}{2:-20}", sorszam, lelohely, String.Join(s, fertozesek));
        }
    }
}
