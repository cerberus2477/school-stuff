const nav = document.getElementsByTagName("nav")[0];
const navHeight = nav.getBoundingClientRect().height;
const navLinks = document.querySelectorAll('.navlinks *');
let pxScrolled;

// görgetésre változó dolgok ------------------------------------------------------------------------------------
window.onscroll = function () {
    pxScrolled = window.scrollY;

    // nav szinezése 
    nav.dataset.scrolled = pxScrolled > navHeight;

    //nav linkek aláhúzása

    navLinks.forEach(link => {
        const sectionId = link.getAttribute('href').substring(10); // le kell vágni az elejéről az index.php# -t
        const section = document.getElementById(sectionId);
        console.log(sectionId);

        // ha a megfelelő section tetejénél lejjebb tekertünk de az aljáig meg nem "active" lesz az arra mutató menüpont
        link.dataset.active = section.offsetTop <= pxScrolled && section.offsetTop + section.offsetHeight > pxScrolled;
        // menüpontra kattintásra kicsit feljebb görget mint magától tenné, így a navbar nem takarja ki a rész tetejét
        navLinks.forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                const sectionId = link.getAttribute('href').substring(1);
                const section = document.getElementById(sectionId);

                window.scrollTo({
                    top: section.offsetTop,
                    behavior: 'smooth'
                });
            });
        });
    });
}


// nav kinyitása - becsukása (hamburger menü)
const toggleNav = () => {
    nav.dataset.state = nav.dataset.state == "closed" ? "open" : "closed";
}


// kártyák szinezése (hover és hover nélkül) data-color alapján-------------------------------------------------------------------------------------------------------
// minden nagy kártya ugyanolyan színű mint a megfelelő kis kártya
bigCards.forEach(bigCard => {
    const csomagId = bigCard.dataset.csomagid;
    cards.forEach(card => {
        if (card.dataset.csomagid === csomagId) {
            bigCard.dataset.color = card.dataset.color;
        }
    });
});