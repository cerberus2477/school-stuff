﻿//TODO linearis kereses

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;


namespace programozasi_tetelek
{
	public partial class form_programozasi_tetelek : Form
	{   
        static List<Tetel> tetelek = new List<Tetel>();
		static Tetel currentTetel;
        static Tetel defaultTetel = new Tetel
        {
            Title = "Válasszon tételt a menüből!",
            Leiras = "Tétel leírása",
            Kod = new string[] { "Pszeudo kód" },
            Feladat = "Mintafeladat leírása",
            Megoldas = new string[] { "Mintafeladat megoldására írt kód" },
            AdatBe_blueprint = new string[] { "Felhasználó által bevitt adatok" }
        };
        static string adatbeText;
		string longText = "Az adatokat soron belül vesszővel tagolva adja meg. Új adatfajtánál új sorba kezdje az adatok megadását. Lejjebb az látható, milyen adatokat vár a program.  Az adat megnevezését ne adaja meg (pl. számok: 2, 3, 4 helyett 2, 3, 4)";



		public form_programozasi_tetelek()
		{
            InitializeComponent();
			//FORMÁZÁS
			BackColor = Szinek.hatterSotet;
			Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(238)));
			ForeColor = Szinek.szoveg;
			this.tb_leiras.ForeColor = Szinek.szoveg;
			this.tb_kod.ForeColor = Szinek.szoveg;
			this.tb_feladat.ForeColor = Szinek.szoveg;
			this.tb_megoldas.ForeColor = Szinek.szoveg;
			this.tb_adatbe.ForeColor = Szinek.szoveg;
			this.tb_eredmeny.ForeColor = Szinek.szoveg;
			this.tb_leiras.BackColor = Szinek.hatterVilagos;
			this.tb_kod.BackColor = Szinek.hatterVilagos;
			this.tb_feladat.BackColor = Szinek.hatterVilagos;
			this.tb_megoldas.BackColor = Szinek.hatterVilagos;
			this.tb_adatbe.BackColor = Szinek.hatterVilagos;
			this.tb_eredmeny.BackColor = Szinek.hatterVilagos;

            // minden subitemhez csatoljuk az onclick eventet
            foreach (ToolStripMenuItem mainItem in menu_main.Items)
            {
                foreach (ToolStripMenuItem subItem in mainItem.DropDownItems)
                {
                    subItem.Click += menuItem_Click;
                }                
            }
            LoadTetelek();
        }

		static void LoadTetelek()
		{
			if(File.Exists("tételek.json"))
			{
				//direkt nem olvasható, szeretem a szenvedést c:
				//a tételek.jsont tételenként veszi és tétel objektet csinál belőle, majd hozzáadja őket a tételek listához.
				tetelek.AddRange(JsonConvert.DeserializeObject<List<Tetel>>(File.ReadAllText("tételek.json")));
			}
			currentTetel = defaultTetel;
        }


        private void menuItem_Click(object sender, EventArgs e)
        {
            currentTetel = tetelek.FirstOrDefault(t => t.Title == ((ToolStripMenuItem)sender).Text);
            if (currentTetel == null) currentTetel = defaultTetel;
            lbl_title.Text = currentTetel.Title;
            tb_leiras.Text = currentTetel.Leiras;
            tb_kod.Text = string.Join(Environment.NewLine, currentTetel.Kod);
            tb_feladat.Text = currentTetel.Feladat;
            tb_megoldas.Text = string.Join(Environment.NewLine, currentTetel.Megoldas);

            tb_adatbe.ForeColor = SystemColors.GrayText;
			adatbeText = $"{longText}{Environment.NewLine}{Environment.NewLine}{string.Join(Environment.NewLine, currentTetel.AdatBe_blueprint)}";
			tb_adatbe.Text = adatbeText;
            tb_eredmeny.Text = "";
        }


		private void btn_run_Click(object sender, EventArgs e)
		{
			// Split the input text into lines
			string[] lines = tb_adatbe.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

			// Initialize parameters dictionary
			Dictionary<string, string> parameters = new Dictionary<string, string>();

			// Parse parameters
			foreach(string line in lines)
			{
				string[] parts = line.Split(new[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries);
				if(parts.Length == 2)
				{
					parameters[parts[0].Trim()] = parts[1].Trim();
				}
			}

			// Call the method dynamically
			var method = GetType().GetMethod(currentTetel.Title);
			var result = method.Invoke(null, new object[] { parameters });
			tb_eredmeny.Text = result.ToString();
		}

		






		// PLACEHOLDER AZ ADATBE MEZŐHÖZ -------------------------------------------------------------------------------------
		private void tb_adatbe_GotFocus(object sender, EventArgs e)
        {
            //ha üres a mező vagy a placeholder adatbe_blueprint van ott (még szürkével) üres lesz a mező és szövegszínű hogy írni tudjunk bele
            if (tb_adatbe.Text == adatbeText)
            {
                tb_adatbe.Text = "";
                tb_adatbe.ForeColor = Szinek.szoveg; 
            }
        }

        private void tb_adatbe_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_adatbe.Text))
            {
                tb_adatbe.Text = adatbeText;
                tb_adatbe.ForeColor = SystemColors.GrayText;
            }
        }

		private void btn_mentes_fajlba_Click(object sender, EventArgs e)
		{

		}
	}
}



