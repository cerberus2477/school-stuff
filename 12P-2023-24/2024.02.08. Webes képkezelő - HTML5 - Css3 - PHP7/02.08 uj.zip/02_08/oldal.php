<!-- 2.	lehessen a képekhez megjegyzést fűzni, amit a kiválasztott képpel együtt jelenít meg
3.	lehessen a megjegyzéseket karbantartani (írás, módosítás, törlés)

<!-- FEEDBACK NEM FRISSÜL -->

<?php 
    $feedback = isset($feedback) ? $feedback : "Nincs megjelítendő üzenet.";
    $path = isset($_GET['path']) ? $_GET['path'] : "./files";
?>

<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Képnézegető és fájlnézegető</title>
    <link rel="stylesheet" href="style.css">
    <script src="app.js"></script>
</head>

<body>
    <h1><?=$path?></h1>
    <form action="" method="post" onsubmit="return confirmDelete()">
        <ul class="file-list">
            <?php
                $filenames = scandir($path);
                foreach ($filenames as $name) {
                    // .-tal kezdődő fileok kivételével
                    if (!is_dir($name) && !in_array($name, ['.'])) {
                        $target_path = $path . '/' . $name;

                        if (is_dir($target_path)) {
                            echo "<li><input type='checkbox' class='hidden' name='itemsToDelete[]' value='$target_path'> 
                            <a class='folder' href='oldal.php?path=" . urlencode($target_path) . "'>$name</a></li>"; 
                        } else {
                            echo "<li><input type='checkbox' class='hidden' name='itemsToDelete[]' value='$target_path'> 
                            <a href='file_viewer.php?path=" . urlencode($target_path) . "'>$name</a></li>";   
                        }
                    }
                }
            ?>
        </ul>
        <hr>

        <input id="checkboxBtn" class="btn" value="Elemek kijelölése törléshez" onclick="toggleVisibility();">
        <label for="toggleAllBtn">Összes kijelölése</label>
        <input class="hiddend" id="toggleAllBtn" type="checkbox" value="Összes kijelölése" onclick="toggleAll(this);">
        <input class="btn hiddend" id="deleteBtn" type="submit" value="Kijelölt törlése" name="deleteSelectedBtn">
    </form>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="uploadedFiles[]" id="uploadedFiles" multiple>
        <input class="btn" type="submit" value="Fájlok feltöltése" name="submitFiles">
    </form>
    <form action="" method="post">
        <input class="btn" type="text" name="folderName" placeholder="Mappa neve">
        <input class="btn" type="submit" value="Mappa létrehozása" name="submitFolder">
    </form>

    <p class=" feedback"><?=$feedback?></p>


    <?php
    // fájlok feltöltése
        if (isset($_POST['submitFiles'])) {
            $errors = [];

            foreach ($_FILES['uploadedFiles']['tmp_name'] as $key => $tmp_name) {
                $target_file_name = basename($_FILES["uploadedFiles"]["name"][$key]);
                $target_file_path = "$path/$target_file_name";  

                if (file_exists($target_file_path)) {
                    $errors[] = "A fájl már létezik: " . htmlspecialchars($target_file_name);
                }
                else{
                    if (!move_uploaded_file($_FILES["uploadedFiles"]["tmp_name"][$key],  "$path/$target_file_name")) {
                        $errors[] = "Hiba történt a fájlfeltöltés során: " . htmlspecialchars($target_file_name);
                    }
                }
            }

           
            if (empty($errors)) {
                header("Refresh:0");
                $feedback = "Minden fájl sikeresen feltöltve."; 
            } else {
                $feedback = "Hiba történt a feltöltés során:<br>" . implode("<br>", $errors);
            } 
        }


    // mappa hozzáadása
        if (isset($_POST['submitFolder'])) {
            $folder_name = $_POST['folderName'];
            if (!file_exists($path . "/" . $folder_name)) {
                mkdir($path . "/" . $folder_name, 0777, true);
                header("Refresh:0");
                $feedback = "Sikeresen létrehozva: " . htmlspecialchars($folder_name); 
            } else {
                $feedback = "A mappa már létezik.";
            }
        }
  

    // törlés
        if(isset($_POST['deleteSelectedBtn'])) {
            if(isset($_POST['itemsToDelete']) && !empty($_POST['itemsToDelete'])) {
                foreach($_POST['itemsToDelete'] as $item_path) {
                    if(is_file($item_path)) unlink($item_path);
                    elseif(is_dir($item_path)) rmdir($item_path);
                }
                
                $feedback = "Kijelölt elemek sikeresen törölve."; 
                header("Refresh:0");
            } else {
                $feedback = "Nincs kijelölt elem a törléshez.";
            }
        }



    ?>

    <?php if ($path != "./files"): ?>
    <a class="btn" href="oldal.php?path=<?= urlencode(dirname($path)) ?>">Vissza</a>
    <?php endif; ?>

</body>

</html>