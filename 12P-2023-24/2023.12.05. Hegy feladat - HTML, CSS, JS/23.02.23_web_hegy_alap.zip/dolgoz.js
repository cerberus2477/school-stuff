function szamol(){
    
var s=0; //költség

if(z=="b"){} //busz
else if(z=="a"){} //autó
else if(z=="k"){} //kerékpár
else if(z=="g"){} //gyalog

}