﻿// gamePoint.cs

using System;
using System.Drawing;
using System.Windows.Forms;

namespace pontracsos
{
	public partial class gamePoint : UserControl
	{
		public gamePoint()
		{
			State = PointState.Neutral;
			Width = Height = 12;
			InitializeComponent();
		}

		private PointState _state;

		public PointState State
		{
			get { return _state; }
			set
			{
				_state = value;

				ColorCircle(_state);
			}
		}

		public void ColorCircle(PointState state)
		{
			Graphics g = CreateGraphics();
			Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
			Color color = pontracsos.State.ToColor(state);
			g.FillEllipse(new SolidBrush(color), rect);
		}

		

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			ColorCircle(PointState.Neutral);
		}
	}
}
