<!-- előbb van onclick mint hogy submit lenne tehát akkor is eltűnik a form ha a required nincs kitöltve -->

<!-- feladat: -->
<!-- tesztelni hogy ne htmlt adjanak be -->
<!-- emojik -->
<!-- captcha -->
<!-- email -->


<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2) Vendégkönyv</title>
    <script src="app.js"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>2) Vendégkönyv</h1>

    <div id="callToAction">
        <p>Ossza meg tapasztalatait velünk!</p>
        <button onclick="toggleForm()">Vélemény írása</button>
    </div>

    <div id="formContainer" class="hide">
        <h2>Új vélemény hozzáadása</h2>
        <p>Ossza meg tapasztalatait velünk!</p>
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" enctype="multipart/form-data">
            <p><i>A csillaggal jelölt mezők kitöltése kötelező.</i></p>
            <!-- sorszam? -->
            <p>
                <label for="nev">Név* </label>
                <input type="text" name="nev" id="nev" maxlength="50" placeholder="pl. Példa Géza" required>
            </p>
            <p>
                <label for="ev">Életkor </label>
                <input type="number" name="ev" id="ev">
            </p>
            <p>
                <label for="cim">Bejegyzés címe* </label>
                <input type="text" name="cim" id="cim" maxlength="100" placeholder="pl. Szuper hely!" required>
            </p>
            <p>
                <label for="komment">Vélemény* </label><br>
                <textarea name="komment" id="komment" cols="30" rows="10"
                    placeholder="pl. Nagyon ajánlom mindenkinek! Pistike a kisfiam imádta a medencét. :)"
                    required></textarea>
            </p>
            <p>
                <label for="komment">Fájl csatolása </label><br>
                <input type="file" name="fajlok[]" multiple="multiple" />
            </p>
            <!-- +DÁTUM -->

            <input type="submit" value="Közzététel" onsubmit="toggleForm()">
        </form>
    </div>

    <h2>Korábbi bejegyzések</h2>
    <div id="bejegyzesek">
        <?php echo $display ?>;
        <article>
            <p>példa</p>
            <p class="title">sorszam. nev</p>
            <p class="name">nev, ev</p>
            <blockquote>komment Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laboriosam harum repellat
                accusantium expedita delectus id nostrum tempora culpa maiores cum obcaecati suscipit, quidem tempore
                iste at provident impedit. Doloremque deleniti molestias dolorem laudantium adipisci odio optio
                reiciendis, odit ducimus? Ab voluptatibus maxime deleniti nisi ipsum voluptates omnis suscipit ullam
                quisquam?</blockquote>
            <p class="date">...datum
            <p>
        </article>
    </div>

    <?php 
        
        class Bejegyzes {
            public $sorszam;
            public $nev;
            public $ev;
            public $cim;
            public $komment;
            public $fajl;
            public $datum;
        
            
            private static $elozoSorszam = 0;
      
            public function __construct($nev, $ev, $cim, $komment, $fajl, $datum) {

                //minden új bejegyzéssel nő a sorszam
                self::$elozoSorszam++;
                $this->sorszam = self::$elozoSorszam;

                $this->nev = $nev;
                $this->ev = $ev;
                $this->cim = $cim;
                $this->komment = $komment;
                //feltoltott-e fajlt (máshogy nem kezelem)
                $this->fajl = $fajl;
                $this->datum = $datum;
            }
        
            public function display() {
                $html = '<article>\n';
                $html .= '\t<p class="no">' . $this->sorszam . '. vélemény</p>\n';
                $html .= '\t<p class="title">' . $this->cim . '</p>\n';
                $html .= '\t<p class="author">' . $this->nev . ', ' . $this->ev . ' éves</p>\n';
                $html .= '\t<blockquote>' . $this->komment . '</blockquote>\n';
                $html .= '\t<p>' . ($this->fajl ? "Feltöltött fájlt." : "Nem töltött fel fájlt") . '</p>\n';
                $html .= '\t<p class="date">Közzététel dátuma ' . $this->datum . '</p>\n';
                $html .= '\t</article>\n';
                return $html;
            }

            //fájlba mentéshez, sorszámot nem mentjük
            public function __toString(){
                return "$this->nev\n$this->ev\n$this->cim\n$this->komment\n$this->fajl\n$this->datum\n";
            }
        }
        
 
        $bejegyzesek = [];
        $save_file = "bejegyzesek.txt";
        if ( ! file_exists($save_file)) {
            $display = "<p><i>Még nincsenek vélemények. Legyen Ön az első!</i></p>";
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            //1. adatok normalizálása, nev object
            $vanFajl = isset($_FILES['fajlok']) && !empty($_FILES['fajlok']['name'][0]);
            $bejegyzes = new Bejegyzes($_POST['nev'], $_POST['ev'], $_POST['cim'], $_POST['komment'], $vanFajl, date("Y-m-d H:i:s"));

             //2. adatok beolvasása fájlból
            if (file_exists($save_file)) {
                $fr = fopen($save_file, "r");
                
                //6 soronként
                $f = file($save_file);
                for ($i = 0; $i < count($f)-5; $i+=6) {
                    $adatok[] = new Bejegyzes($f[$i], $f[$i+1], $f[$i+2], $f[$i+3], $f[$i+4], $f[$i+5]);
                }

               
                    $sor = explode(";", fgets($fr));
                    $adatok[$sor[0]] = (int)$sor[1];
                
                fclose($fr);
            }


            //3. adatok írása
            $fw = fopen($save_file, "w");
            foreach ($adatok as $nev => $szam) {
                fputcsv($fw, array($nev, $szam), ';');
            }

            //4 adatok divbe
            
            

        }
      

       
        
    
    ?>

</body>

</html>