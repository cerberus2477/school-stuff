﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace f2._3_fizetes
{
    internal class Program
    {
        static void Main(string[] args)
        {us
        }
    }
}
