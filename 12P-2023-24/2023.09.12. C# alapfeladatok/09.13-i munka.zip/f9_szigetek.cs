﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat09_szigetek
{
	class Program
	{
		static void Main(string[] args)
		{
			int[] heights = {0, 1, 6, 6, 20, 40, 51, 55, 53, 32, 9, 0, 0, 0, 3, 4, 5, 2, 1, 0, 0, 2, 2, 3, 5, 6, 3, 3, 3, 3, 1, 0,  2, 4, 0, 2, 0, 0, 1, 2, 3};
			Console.WriteLine("Hány kilométerenként történtek a mérések?");
			int x = int.Parse(Console.ReadLine());

			Console.WriteLine($"\n{findIslands(heights, x).Count()}db sziget van. Ezek a mérés");

			foreach (var islandStartEnd in findIslands(heights, x))
			{
				Console.WriteLine($"\t {islandStartEnd.Key}. kilométerétől a {islandStartEnd.Value}. kilométeréig");
			}

			Console.WriteLine("tartanak.");
 		}

		static Dictionary<int, int> findIslands(int[] heights, int x)
		{
			Dictionary<int, int> islands = new Dictionary<int, int>();
			int i = 0;
			int start;
			int end = 0;

			while (i < heights.Length-1)
			{
				while(heights[i] == 0)
				{
					i++;
				}

				start = i;

				while (heights[i] > 0  && i != heights.Length - 1)
				{
					end = i;
					if(i != heights.Length -1) {
						i++;
					}
				}

				islands.Add(start*x, end*x+x-1);
			}
		
			return islands;
		}
	}
}
