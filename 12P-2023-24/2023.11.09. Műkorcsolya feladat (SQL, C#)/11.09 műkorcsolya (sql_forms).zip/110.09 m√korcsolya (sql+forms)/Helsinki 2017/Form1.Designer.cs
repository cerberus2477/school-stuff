﻿
namespace Helsinki_2017
{
    partial class frmHelsinki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.megoldásokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rövidporgram4FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.magyarVersenyző5FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbMegoldasok = new System.Windows.Forms.TextBox();
            this.összpontszám68FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbNev = new System.Windows.Forms.TextBox();
            this.lblNev = new System.Windows.Forms.Label();
            this.btnNev = new System.Windows.Forms.Button();
            this.pnlNev = new System.Windows.Forms.Panel();
            this.továbbjutókországonként9feldatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.pnlNev.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.megoldásokToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // megoldásokToolStripMenuItem
            // 
            this.megoldásokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rövidporgram4FeladatToolStripMenuItem,
            this.magyarVersenyző5FeladatToolStripMenuItem,
            this.összpontszám68FeladatToolStripMenuItem,
            this.továbbjutókországonként9feldatToolStripMenuItem});
            this.megoldásokToolStripMenuItem.Name = "megoldásokToolStripMenuItem";
            this.megoldásokToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.megoldásokToolStripMenuItem.Text = "Megoldások";
            // 
            // rövidporgram4FeladatToolStripMenuItem
            // 
            this.rövidporgram4FeladatToolStripMenuItem.Name = "rövidporgram4FeladatToolStripMenuItem";
            this.rövidporgram4FeladatToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.rövidporgram4FeladatToolStripMenuItem.Text = "rövidporgram (4. feladat)";
            this.rövidporgram4FeladatToolStripMenuItem.Click += new System.EventHandler(this.rövidporgram4FeladatToolStripMenuItem_Click);
            // 
            // magyarVersenyző5FeladatToolStripMenuItem
            // 
            this.magyarVersenyző5FeladatToolStripMenuItem.Name = "magyarVersenyző5FeladatToolStripMenuItem";
            this.magyarVersenyző5FeladatToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.magyarVersenyző5FeladatToolStripMenuItem.Text = "magyar versenyző (5. feladat)";
            this.magyarVersenyző5FeladatToolStripMenuItem.Click += new System.EventHandler(this.magyarVersenyző5FeladatToolStripMenuItem_Click);
            // 
            // tbMegoldasok
            // 
            this.tbMegoldasok.Location = new System.Drawing.Point(36, 67);
            this.tbMegoldasok.Multiline = true;
            this.tbMegoldasok.Name = "tbMegoldasok";
            this.tbMegoldasok.ReadOnly = true;
            this.tbMegoldasok.Size = new System.Drawing.Size(486, 205);
            this.tbMegoldasok.TabIndex = 1;
            // 
            // összpontszám68FeladatToolStripMenuItem
            // 
            this.összpontszám68FeladatToolStripMenuItem.Name = "összpontszám68FeladatToolStripMenuItem";
            this.összpontszám68FeladatToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.összpontszám68FeladatToolStripMenuItem.Text = "összpontszám (6-8 feladat)";
            this.összpontszám68FeladatToolStripMenuItem.Click += new System.EventHandler(this.összpontszám68FeladatToolStripMenuItem_Click);
            // 
            // tbNev
            // 
            this.tbNev.Location = new System.Drawing.Point(6, 19);
            this.tbNev.Name = "tbNev";
            this.tbNev.Size = new System.Drawing.Size(214, 20);
            this.tbNev.TabIndex = 2;
            // 
            // lblNev
            // 
            this.lblNev.AutoSize = true;
            this.lblNev.Location = new System.Drawing.Point(3, 3);
            this.lblNev.Name = "lblNev";
            this.lblNev.Size = new System.Drawing.Size(144, 13);
            this.lblNev.TabIndex = 3;
            this.lblNev.Text = "Adja meg a versenyző nevét!";
            // 
            // btnNev
            // 
            this.btnNev.Location = new System.Drawing.Point(6, 45);
            this.btnNev.Name = "btnNev";
            this.btnNev.Size = new System.Drawing.Size(75, 23);
            this.btnNev.TabIndex = 4;
            this.btnNev.Text = "Mutat";
            this.btnNev.UseVisualStyleBackColor = true;
            this.btnNev.Click += new System.EventHandler(this.btnNev_Click);
            // 
            // pnlNev
            // 
            this.pnlNev.Controls.Add(this.lblNev);
            this.pnlNev.Controls.Add(this.btnNev);
            this.pnlNev.Controls.Add(this.tbNev);
            this.pnlNev.Location = new System.Drawing.Point(546, 67);
            this.pnlNev.Name = "pnlNev";
            this.pnlNev.Size = new System.Drawing.Size(231, 100);
            this.pnlNev.TabIndex = 5;
            // 
            // továbbjutókországonként9feldatToolStripMenuItem
            // 
            this.továbbjutókországonként9feldatToolStripMenuItem.Name = "továbbjutókországonként9feldatToolStripMenuItem";
            this.továbbjutókországonként9feldatToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.továbbjutókországonként9feldatToolStripMenuItem.Text = "továbbjutók országonként (9. feladat)";
            this.továbbjutókországonként9feldatToolStripMenuItem.Click += new System.EventHandler(this.továbbjutókországonként9feldatToolStripMenuItem_Click);
            // 
            // frmHelsinki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlNev);
            this.Controls.Add(this.tbMegoldasok);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmHelsinki";
            this.Text = "Helsinki 2017";
            this.Load += new System.EventHandler(this.frmHelsinki_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlNev.ResumeLayout(false);
            this.pnlNev.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem megoldásokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rövidporgram4FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem magyarVersenyző5FeladatToolStripMenuItem;
        private System.Windows.Forms.TextBox tbMegoldasok;
        private System.Windows.Forms.ToolStripMenuItem összpontszám68FeladatToolStripMenuItem;
        private System.Windows.Forms.TextBox tbNev;
        private System.Windows.Forms.Label lblNev;
        private System.Windows.Forms.Button btnNev;
        private System.Windows.Forms.Panel pnlNev;
        private System.Windows.Forms.ToolStripMenuItem továbbjutókországonként9feldatToolStripMenuItem;
    }
}

