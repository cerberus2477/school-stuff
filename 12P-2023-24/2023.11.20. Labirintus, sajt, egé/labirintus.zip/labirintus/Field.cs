﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labirintus
{
    public enum fieldType { Sajt, Eger, Fal, Ures }

    public partial class Field : Button
    {
        private fieldType _Type;

        public fieldType Type
        {
            get => _Type;
            set
            {
                _Type = value;
                switch (value)
                {
                    case fieldType.Sajt:
                        BackColor = Color.Gold;
                        break;
                    case fieldType.Eger:
                        BackColor = Color.BlueViolet;
                        break;
                    case fieldType.Fal:
                        BackColor = Color.Black;
                        break;
                    case fieldType.Ures:
                        BackColor = Color.White;
                        break;
                    default:
                        break;
                }

            }
        }

        public Field()
        {
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderColor = Color.Gainsboro;
        }


    }

}


