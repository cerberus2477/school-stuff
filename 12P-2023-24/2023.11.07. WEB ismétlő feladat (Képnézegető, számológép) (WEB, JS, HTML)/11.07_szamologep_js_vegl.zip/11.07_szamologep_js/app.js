const calc = () => {
    let first_num = document.getElementById("first-num");
    let operator = document.getElementById("operator");
    let second_num = document.getElementById("second-num");
    let result = document.getElementById("result");

    try {
        let calc = first_num.value + operator.value + second_num.value;
        let res = eval(calc);

        if (res != undefined && validOperator(operator.value)) {
            if (res == "Infinity") {
                res = "HIBA! Nullával osztás!";
            }
            result.innerText = res;

            //sor hozzáadása a táblázathoz
            let table = document.getElementById("history");
            let row = table.insertRow(0);
            let cell1 = row.insertCell(0);
            let cell2 = row.insertCell(1);
            cell1.innerText = calc;
            cell2.innerText = res;
        }

    } catch (error) {
        //Ha az operator nem értelmezhető egy kifejetésben és persze minden egyéb hiba esetén
        result.innerText = "Nem megfelelő számítás";
    }
}

const clearHistory = () => {
    let table = document.getElementById("history");
    table.innerHTML = "";
}

const validOperator = (o) => {
    //o nem hiányzik vagy szám, mert ekkor a mezőket kapnánk eredményül összefűzve, és nem hatványjel, ugyanis az eval() ezt valamily okból összeadásként kezeli
    if (o == "" || parseInt(o) || o == "^") {
        return false;
    }
    return true;
}


