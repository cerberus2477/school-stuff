﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace f1._3_fibonacci
{
    internal class Program
    {
        static void Main(string[] args)
        {
           int[] fib = new int[20];
           fib[0] = 0; fib[1] = 1;
           for (int i = 2; i < fib.Length; i++)
           {
                fib[i] = fib[i-1] + fib[i-2];
           }
            Console.WriteLine($"A Fibonacci-sorozat első húsz eleme a {String.Join(", ", fib)}.");
        }
    }
}
