﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sudokuGame
{
    internal class Logika
    {
        SudokuCell[,] cells;
        public void createCells(int dim, int cwidth, int cheight, Panel pnl)
        {
            cells = new SudokuCell[dim*3, dim*3];


            for (int i = 0; i < dim*3; i++)
            {
                for (int j = 0; j < dim*3; j++)
                {
                    // Create 81 cells for with styles and locations based on the index
                    cells[i, j] = new SudokuCell();
                    cells[i, j].Font = new Font(SystemFonts.DefaultFont.FontFamily, 20);
                    cells[i, j].Size = new Size(cwidth, cheight);

                    cells[i, j].Location = new Point(i * cwidth, j * cheight);

                    cells[i, j].FlatStyle = FlatStyle.Flat;
                    cells[i, j].FlatAppearance.BorderColor = Color.Black;
                    cells[i, j].X = i;
                    cells[i, j].Y = j;

                    pnl.Controls.Add(cells[i, j]);
                }
            }
        }


    }
}
