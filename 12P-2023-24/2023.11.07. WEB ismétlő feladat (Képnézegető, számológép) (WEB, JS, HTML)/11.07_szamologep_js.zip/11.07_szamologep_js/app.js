const calc = () => {
    let first_num = document.getElementById("first-num");
    let operator = document.getElementById("operator");
    let second_num = document.getElementById("second-num");
    let result = document.getElementById("result");

    let calc = first_num.value + operator.value + second_num.value;
    let res = eval(calc);

    try {
        //üres bemenete, művelet mezőben számot és nullával való osztást szűr ki
        result.innerText =  res != undefined && res != "Infinity" && parseFloat(operator) != NaN ? res : "Nem megfelelő számítás!"; 
    } catch (error) {
        //nem értelmezhető számítás esetén (pl a művelet nem műveleti jel)
        console.error("Nem megfelelő számítás!"); 
    }

    //táblázat frissítése
    let table = document.getElementById("history");
    let row = table.insertRow(0);
    let cell1 = row.insertCell(0);
    let cell2 = row.insertCell(1);
    cell1.innerText = calc;
    cell2.innerText = res;
}


