﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sudokuGame
{
    class SudokuCell : Button
    {
        private int _currentValue;
        private bool _isLocked;
        private bool _isWrong;


        public int Solution { get; set; }

        public int currentValue
        {
            get => _currentValue;
            set
            {
                _currentValue = value;
                Text = value == 0? String.Empty : _currentValue.ToString();
            }
        }

        //felhasználó átírhatja-e
        public bool isLocked
        {
            get => _isLocked;
            set
            {
                _isLocked = value;
                BackColor = value ? Color.LightSlateGray : Color.White;
            }
        }

        //ha szabálytalan akkor igaz
        public bool isWrong {
            get => _isWrong;
            set
            {
                _isWrong = value;
                ForeColor = value ? Color.MediumVioletRed : Color.Black;
            }
        } 


        public int X { get; set; }
        public int Y { get; set; }


        public SudokuCell()
        {
            Click += nextValue;
            KeyPress += changeCell;

            isLocked = false;
            isWrong = false;
            currentValue = 0;
            Solution = 0;

            Font = new Font(SystemFonts.DefaultFont.FontFamily, 20);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderColor = Color.Black;
        }


        //kattintásra a következő számra lép
        //üresre vagy 1-re ugorjon 9ről?
        public void nextValue(object sender, EventArgs e)
        {
            var cell = sender as SudokuCell;

            if (!isLocked)
            {
                cell.currentValue = currentValue == 9 ? 1 : currentValue + 1;
            }
        }

        // beírt szám lesz a mező értéke
        private void changeCell(object sender, KeyPressEventArgs e)
        {
            var cell = sender as SudokuCell;
            int value;
            if (!isLocked && int.TryParse(e.KeyChar.ToString(), out value))
            {
                cell.currentValue = value;
            }
        }





    }
}
