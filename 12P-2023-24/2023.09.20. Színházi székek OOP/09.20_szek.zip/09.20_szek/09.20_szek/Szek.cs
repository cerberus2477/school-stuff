﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09._20_szek {
	class Szek {
		private List<string> foglaltsag = new List<string>();
		private bool parnazott;
		private bool karfas;
		private bool elotteHely;

		private bool ures = false;

		public Szek(bool _parnazott, bool _karfas, bool _elotteHely) {
			parnazott = _parnazott;
			karfas = _karfas;
			elotteHely = _elotteHely;
		}

		public Szek(string _ures) {
			if(_ures == "ures") {
				ures = true;
			}
		}

		public bool isFoglalt(string datum) {
			return foglaltsag.Contains(datum);
		}

		public bool tryLefoglal(string datum) {
			if(!isFoglalt(datum)) {
				foglaltsag.Add(datum);
				return true;
			}
			return false;
		}

		public bool getParnazott() { return parnazott; }

		public bool getKarfas() { return karfas; }

		public bool getElotteHely() { return elotteHely; }

		public bool isUres() { return ures; }
	}
}
