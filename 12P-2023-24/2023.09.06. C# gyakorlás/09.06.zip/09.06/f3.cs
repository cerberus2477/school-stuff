﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace feladat03 {


	class Program {

		public static List<Kilepo> kilepok = new List<Kilepo>();

		static void Main(string[] args) {

			/*foreach(var line in File.ReadLines("hatar.csv")) {
				kilepok.Add(new Kilepo(line.Split(';')));

			} nem jó mert az első sorban fejléc van */

			string[] lines = File.ReadAllLines("hatar.csv");

			for(int i = 1; i < lines.Length; i++) {
				kilepok.Add(new Kilepo(lines[i].Split(';')));
			}

			//Hány angol, német, stb. állampolgárnő lépte át a határt, s átlagosan hány hetet maradtak?

			foreach(var nemz in kilepok.Select(k => k.allPorg).Distinct()) {
				Console.WriteLine($"{kilepok.Where(k => k.nem == "nő" && k.allPorg == nemz).Count()} {nemz} államporgárnő lépte át a határt, átlagosan {kilepok.Where(k => k.nem == "nő" && k.allPorg == nemz).Select(n => n.tartHet).Average()} hetet maradtak.");
			}
			

			//Adja meg a határt átlépők korcsoport szerinti megoszlását összesen és százalékosan!(Korcsoportok: 0 - 9 év, 10 - 19 év...90 - 99 év)
			//Hány 40 és 49 közötti holland férfi lépte át a határt ?
		}
	}

	struct Kilepo {
		public string allPorg;
		public int kor;
		public string nem;
		public int tartHet;

		public Kilepo(string _allPorg, int _kor, string _nem, int _tartHet) {
			allPorg = _allPorg;
			kor = _kor;
			nem = _nem;
			tartHet = _tartHet;
		}

		public Kilepo(string[] data) {
			allPorg = data[0];
			kor = int.Parse(data[1]);
			nem = data[2];
			tartHet = int.Parse(data[3]);
		}
	}
}
