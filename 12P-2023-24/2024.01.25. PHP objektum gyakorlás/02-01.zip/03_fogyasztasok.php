<!-- 
Kérd be 10 autó fogyasztását! (rendszám, fogyasztás)
 Döntsd el és írd ki, hogy minden autó 8 liter alatt fogyasztott-e? 
 Listázd ki az autókat! Használj autó osztályt! 
  -->

<!-- Bekért adatokat nem tudom kezelni, ha két inputtal kérném be és splitelném működne -->
<?php
    class Auto{
        protected $rendszam;
        protected $fogyasztas;

        function __construct($rendszam, $fogyasztas){
            $this->rendszam = $rendszam;
            $this->fogyasztas = $fogyasztas;
        }

        function nyolcalatt(){
            return $this->fogyasztas < 8;
        }

        function toString(){
            return $this->rendszam.": ".$this->fogyasztas;
        }
    }


    if(!(isset($_POST['r1']))){
        $uzenet = "Adja meg a számokat!";
    }else{  
        $adatok = array_values($_POST);
        
        // $adatok = $_POST['adatok'];
        $mindnyolcalatt = true;
        for ($i=0; $i < count($adatok); $i+=2) { 
            $auto = new Auto($adatok[$i], $adatok[$i+1]);
            //FALSE * TRUE => 0 * 1 => 0    TRUE * TRUE ==> 1
            //$mindnyolcalatt *= $auto->nyolcalatt();
            echo $auto->toString();
        }                                             
        $uzenet = $mindnyolcalatt ? "Minden autó 8 liter alatt fogyasztot." : "Nem minden autó fogyasztot 8 liter alatt.";
        var_dump($adatok);
    }
    

    ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3) Fogyasztások</title>
</head>
<body>
<div>
        <h2>3) Fogyasztások</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <p>
                <label for="r1">Rendszám:</label>
                <input required type="text" id="r1" name="adatok[]">
                <label for="f1">Fogyasztás:</label>
                <input required type="number" id="f1">
                <br>
                <label for="r2">Rendszám:</label>
                <input required type="text" id="r2" name="adatok[]">
                <label for="f2">Fogyasztás:</label>
                <input required type="number" id="f2" name="adatok[]">
                <br>
                <label for="r3">Rendszám:</label>
                <input required type="text" id="r3" name="adatok[]">
                <label for="f3">Fogyasztás:</label>
                <input required type="number" id="f3" name="adatok[]">
                <br>
                <label for="r4">Rendszám:</label>
                <input required type="text" id="r4" name="adatok[]">
                <label for="f4">Fogyasztás:</label>
                <input required type="number" id="f4" name="adatok[]">
                <br>
                <label for="r5">Rendszám:</label>
                <input required type="text" id="r5" name="adatok[]">
                <label for="f5">Fogyasztás:</label>
                <input required type="number" id="f5" name="adatok[]">
                <br>
                <label for="r6">Rendszám:</label>
                <input required type="text" id="r6" name="adatok[]">
                <label for="f6">Fogyasztás:</label> 
                <input required type="number" id="f6" name="adatok[]">
                <br>
                <label for="r7">Rendszám:</label>
                <input required type="text" id="r7" name="adatok[]">
                <label for="f7">Fogyasztás:</label>
                <input required type="number" id="f7" name="adatok[]">
                <br>
                <label for="r8">Rendszám:</label>
                <input required type="text" id="r8" name="adatok[]">
                <label for="f8">Fogyasztás:</label> 
                <input required type="number" id="f8" name="adatok[]">
                <br>
                <label for="r9">Rendszám:</label>
                <input required type="text" id="r9" name="adatok[]">
                <label for="f9">Fogyasztás:</label> 
                <input required type="number" id="f9" name="adatok[]">
                <br>
                <label for="r10">Rendszám:</label>
                <input required type="text" id="r10" name="adatok[]">
                <label for="f10">Fogyasztás:</label>
                <input required type="number" id="f10" name="adatok[]">
                <br>
                <input type="submit" value="OK">
            </p>
        </form>
        <h1><?php echo $uzenet ?></h1>
    </div>  

</body>
</html>