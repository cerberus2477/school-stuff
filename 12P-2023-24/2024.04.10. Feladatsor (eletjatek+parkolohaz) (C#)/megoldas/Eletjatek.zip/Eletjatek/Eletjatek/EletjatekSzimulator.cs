﻿//minden kiírt jel mögött van egy szóköz hogy jobban négyzet alakú legyen a pálya
internal class EletjatekSzimulator
{
    private int[,] Matrix;
    private int OszlopokSzama;
    private int SorokSzama;

    public EletjatekSzimulator(int sor, int oszlop)
    {
        OszlopokSzama = oszlop;
        SorokSzama = sor;
        Matrix = new int[SorokSzama + 2, OszlopokSzama + 2];
        MatrixFeltoltes();
    }

    private void MatrixFeltoltes()
    {
        //szélét nem töltjük fel random értékkel, marad a nulla
        Random rand = new Random();
        for (int i = 1; i < SorokSzama-1; i++)
        {
            for (int j = 1; j < OszlopokSzama-1; j++)
            {
                Matrix[i, j] = rand.Next(0, 2);
            }
        }
    }

    private void KovetkezoAllapot()
    {
        /*
            Egy sejttel vagy üres cellával egy körben a következő három dolog történhet: 
            o A sejt túléli a kört (cella értéke 1 marad), ha két vagy három szomszédja van. 
            o A sejt elpusztul (cella értéke 0 lesz), ha kettőnél kevesebb (elszigetelődés) vagy 
            háromnál több (túlnépesedés) szomszédja van. 
            o Új sejt születik minden olyan üres (0 értékű) cellában, melynek környezetében 
            pontosan három sejt található. 
            • Minden egyes „belső cellára” a sejtszomszédok számának meghatározása után rendre 
            alkalmazza a fenti három szabályt! A sejtszomszédok számának meghatározása az előző 
            állapotú mátrixon történjen, azaz az új állapotot kódoló mátrix értékeit csak a metódus 
            végén töltse vissza a Matrix adattagba*/
    }

    private int CountSzomszedok(int x, int y)
    {
        int szomszedok = 0;
        for (int i = x - 1; i <= x + 1; i++)
        {
            for (int j = y - 1; j <= y + 1; j++)
            {
                // hogy ne számolja önmagát szomszédnak
                if (!(i == x && j == y)) szomszedok += Matrix[i, j];
            }
        }
        return szomszedok;
    }

    private void Megjelenit()
    {
        
        for (int i = 0; i < SorokSzama; i++)
        {
            for (int j = 0; j < OszlopokSzama; j++)
            {
                if (Matrix[i, j] == 1)
                    Console.Write("S ");
                else if (i == 0 || j == 0 || i == SorokSzama-1 || j == OszlopokSzama -1)
                    Console.Write("X ");
                else 
                    Console.Write("  ");
            }
            Console.WriteLine();
        }
    }

    public void Run()
    {
        Console.Clear();
        Megjelenit();
        KovetkezoAllapot();
        System.Threading.Thread.Sleep(500);
    }
}