﻿namespace meszarszek_desktop
{
	partial class form_meszarszek
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.menu = new System.Windows.Forms.MenuStrip();
			this.marhaAdatinakFelviteleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.vágásAdatiainakFelviteleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pnl_marha = new System.Windows.Forms.Panel();
			this.label13 = new System.Windows.Forms.Label();
			this.tb_fajta = new System.Windows.Forms.TextBox();
			this.time_marha = new System.Windows.Forms.DateTimePicker();
			this.date_marha = new System.Windows.Forms.DateTimePicker();
			this.lbl_ido_marha = new System.Windows.Forms.Label();
			this.num_elosuly = new System.Windows.Forms.NumericUpDown();
			this.lbl_elosuly = new System.Windows.Forms.Label();
			this.lbl_datum_marha = new System.Windows.Forms.Label();
			this.lbl_fajta = new System.Windows.Forms.Label();
			this.num_id = new System.Windows.Forms.NumericUpDown();
			this.lbl_id = new System.Windows.Forms.Label();
			this.lbl_marha = new System.Windows.Forms.Label();
			this.pnl_vagas = new System.Windows.Forms.Panel();
			this.label21 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.num_oldalas = new System.Windows.Forms.NumericUpDown();
			this.label9 = new System.Windows.Forms.Label();
			this.num_hatszin = new System.Windows.Forms.NumericUpDown();
			this.label12 = new System.Windows.Forms.Label();
			this.num_hatsocomb = new System.Windows.Forms.NumericUpDown();
			this.label11 = new System.Windows.Forms.Label();
			this.num_szegy = new System.Windows.Forms.NumericUpDown();
			this.label10 = new System.Windows.Forms.Label();
			this.num_labszar = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.num_tarja = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.num_elsocomb = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.time_vagas = new System.Windows.Forms.DateTimePicker();
			this.date_vagas = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.num_nyak = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.num_marhaid = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.lbl_vagas = new System.Windows.Forms.Label();
			this.btn_feltoltes = new System.Windows.Forms.Button();
			this.menu.SuspendLayout();
			this.pnl_marha.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.num_elosuly)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_id)).BeginInit();
			this.pnl_vagas.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.num_oldalas)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_hatszin)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_hatsocomb)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_szegy)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_labszar)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_tarja)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_elsocomb)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_nyak)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.num_marhaid)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.label1.Location = new System.Drawing.Point(13, 47);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(321, 39);
			this.label1.TabIndex = 0;
			this.label1.Text = "Mészárszék desktop";
			// 
			// menu
			// 
			this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.marhaAdatinakFelviteleToolStripMenuItem,
            this.vágásAdatiainakFelviteleToolStripMenuItem});
			this.menu.Location = new System.Drawing.Point(0, 0);
			this.menu.Name = "menu";
			this.menu.Size = new System.Drawing.Size(486, 24);
			this.menu.TabIndex = 1;
			this.menu.Text = "menuStrip1";
			// 
			// marhaAdatinakFelviteleToolStripMenuItem
			// 
			this.marhaAdatinakFelviteleToolStripMenuItem.Name = "marhaAdatinakFelviteleToolStripMenuItem";
			this.marhaAdatinakFelviteleToolStripMenuItem.Size = new System.Drawing.Size(145, 20);
			this.marhaAdatinakFelviteleToolStripMenuItem.Text = "Marha adatinak felvitele";
			this.marhaAdatinakFelviteleToolStripMenuItem.Click += new System.EventHandler(this.marhaAdatinakFelviteleToolStripMenuItem_Click);
			// 
			// vágásAdatiainakFelviteleToolStripMenuItem
			// 
			this.vágásAdatiainakFelviteleToolStripMenuItem.Name = "vágásAdatiainakFelviteleToolStripMenuItem";
			this.vágásAdatiainakFelviteleToolStripMenuItem.Size = new System.Drawing.Size(150, 20);
			this.vágásAdatiainakFelviteleToolStripMenuItem.Text = "Vágás adatiainak felvitele";
			this.vágásAdatiainakFelviteleToolStripMenuItem.Click += new System.EventHandler(this.vágásAdatiainakFelviteleToolStripMenuItem_Click);
			// 
			// pnl_marha
			// 
			this.pnl_marha.Controls.Add(this.label13);
			this.pnl_marha.Controls.Add(this.tb_fajta);
			this.pnl_marha.Controls.Add(this.time_marha);
			this.pnl_marha.Controls.Add(this.date_marha);
			this.pnl_marha.Controls.Add(this.lbl_ido_marha);
			this.pnl_marha.Controls.Add(this.num_elosuly);
			this.pnl_marha.Controls.Add(this.lbl_elosuly);
			this.pnl_marha.Controls.Add(this.lbl_datum_marha);
			this.pnl_marha.Controls.Add(this.lbl_fajta);
			this.pnl_marha.Controls.Add(this.num_id);
			this.pnl_marha.Controls.Add(this.lbl_id);
			this.pnl_marha.Controls.Add(this.lbl_marha);
			this.pnl_marha.Location = new System.Drawing.Point(20, 89);
			this.pnl_marha.Name = "pnl_marha";
			this.pnl_marha.Size = new System.Drawing.Size(447, 377);
			this.pnl_marha.TabIndex = 2;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(404, 201);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(27, 20);
			this.label13.TabIndex = 28;
			this.label13.Text = "kg";
			// 
			// tb_fajta
			// 
			this.tb_fajta.Location = new System.Drawing.Point(29, 133);
			this.tb_fajta.Name = "tb_fajta";
			this.tb_fajta.Size = new System.Drawing.Size(402, 26);
			this.tb_fajta.TabIndex = 13;
			// 
			// time_marha
			// 
			this.time_marha.Location = new System.Drawing.Point(30, 333);
			this.time_marha.Name = "time_marha";
			this.time_marha.Size = new System.Drawing.Size(401, 26);
			this.time_marha.TabIndex = 12;
			// 
			// date_marha
			// 
			this.date_marha.Location = new System.Drawing.Point(29, 264);
			this.date_marha.Name = "date_marha";
			this.date_marha.Size = new System.Drawing.Size(402, 26);
			this.date_marha.TabIndex = 11;
			// 
			// lbl_ido_marha
			// 
			this.lbl_ido_marha.AutoSize = true;
			this.lbl_ido_marha.Location = new System.Drawing.Point(26, 310);
			this.lbl_ido_marha.Name = "lbl_ido_marha";
			this.lbl_ido_marha.Size = new System.Drawing.Size(123, 20);
			this.lbl_ido_marha.TabIndex = 9;
			this.lbl_ido_marha.Text = "Beérkezés ideje";
			// 
			// num_elosuly
			// 
			this.num_elosuly.Location = new System.Drawing.Point(29, 195);
			this.num_elosuly.Name = "num_elosuly";
			this.num_elosuly.Size = new System.Drawing.Size(369, 26);
			this.num_elosuly.TabIndex = 8;
			// 
			// lbl_elosuly
			// 
			this.lbl_elosuly.AutoSize = true;
			this.lbl_elosuly.Location = new System.Drawing.Point(26, 172);
			this.lbl_elosuly.Name = "lbl_elosuly";
			this.lbl_elosuly.Size = new System.Drawing.Size(56, 20);
			this.lbl_elosuly.TabIndex = 7;
			this.lbl_elosuly.Text = "Élősúly";
			// 
			// lbl_datum_marha
			// 
			this.lbl_datum_marha.AutoSize = true;
			this.lbl_datum_marha.Location = new System.Drawing.Point(25, 241);
			this.lbl_datum_marha.Name = "lbl_datum_marha";
			this.lbl_datum_marha.Size = new System.Drawing.Size(144, 20);
			this.lbl_datum_marha.TabIndex = 5;
			this.lbl_datum_marha.Text = "Beérkezés dátuma";
			// 
			// lbl_fajta
			// 
			this.lbl_fajta.AutoSize = true;
			this.lbl_fajta.Location = new System.Drawing.Point(25, 110);
			this.lbl_fajta.Name = "lbl_fajta";
			this.lbl_fajta.Size = new System.Drawing.Size(44, 20);
			this.lbl_fajta.TabIndex = 3;
			this.lbl_fajta.Text = "Fajta";
			// 
			// num_id
			// 
			this.num_id.Location = new System.Drawing.Point(29, 72);
			this.num_id.Name = "num_id";
			this.num_id.Size = new System.Drawing.Size(402, 26);
			this.num_id.TabIndex = 2;
			// 
			// lbl_id
			// 
			this.lbl_id.AutoSize = true;
			this.lbl_id.Location = new System.Drawing.Point(25, 49);
			this.lbl_id.Name = "lbl_id";
			this.lbl_id.Size = new System.Drawing.Size(38, 20);
			this.lbl_id.TabIndex = 1;
			this.lbl_id.Text = "Kód";
			// 
			// lbl_marha
			// 
			this.lbl_marha.AutoSize = true;
			this.lbl_marha.Location = new System.Drawing.Point(0, 0);
			this.lbl_marha.Name = "lbl_marha";
			this.lbl_marha.Size = new System.Drawing.Size(200, 20);
			this.lbl_marha.TabIndex = 0;
			this.lbl_marha.Text = "Marha adatainak felvitele";
			// 
			// pnl_vagas
			// 
			this.pnl_vagas.Controls.Add(this.label21);
			this.pnl_vagas.Controls.Add(this.label20);
			this.pnl_vagas.Controls.Add(this.label19);
			this.pnl_vagas.Controls.Add(this.label18);
			this.pnl_vagas.Controls.Add(this.label17);
			this.pnl_vagas.Controls.Add(this.label16);
			this.pnl_vagas.Controls.Add(this.label15);
			this.pnl_vagas.Controls.Add(this.label14);
			this.pnl_vagas.Controls.Add(this.num_oldalas);
			this.pnl_vagas.Controls.Add(this.label9);
			this.pnl_vagas.Controls.Add(this.num_hatszin);
			this.pnl_vagas.Controls.Add(this.label12);
			this.pnl_vagas.Controls.Add(this.num_hatsocomb);
			this.pnl_vagas.Controls.Add(this.label11);
			this.pnl_vagas.Controls.Add(this.num_szegy);
			this.pnl_vagas.Controls.Add(this.label10);
			this.pnl_vagas.Controls.Add(this.num_labszar);
			this.pnl_vagas.Controls.Add(this.label8);
			this.pnl_vagas.Controls.Add(this.num_tarja);
			this.pnl_vagas.Controls.Add(this.label7);
			this.pnl_vagas.Controls.Add(this.num_elsocomb);
			this.pnl_vagas.Controls.Add(this.label5);
			this.pnl_vagas.Controls.Add(this.time_vagas);
			this.pnl_vagas.Controls.Add(this.date_vagas);
			this.pnl_vagas.Controls.Add(this.label2);
			this.pnl_vagas.Controls.Add(this.num_nyak);
			this.pnl_vagas.Controls.Add(this.label3);
			this.pnl_vagas.Controls.Add(this.label4);
			this.pnl_vagas.Controls.Add(this.num_marhaid);
			this.pnl_vagas.Controls.Add(this.label6);
			this.pnl_vagas.Controls.Add(this.lbl_vagas);
			this.pnl_vagas.Location = new System.Drawing.Point(20, 89);
			this.pnl_vagas.Name = "pnl_vagas";
			this.pnl_vagas.Size = new System.Drawing.Size(447, 377);
			this.pnl_vagas.TabIndex = 14;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(147, 348);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(27, 20);
			this.label21.TabIndex = 37;
			this.label21.Text = "kg";
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(323, 348);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(27, 20);
			this.label20.TabIndex = 36;
			this.label20.Text = "kg";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(323, 287);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(27, 20);
			this.label19.TabIndex = 35;
			this.label19.Text = "kg";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(147, 287);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(27, 20);
			this.label18.TabIndex = 34;
			this.label18.Text = "kg";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(149, 213);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(27, 20);
			this.label17.TabIndex = 33;
			this.label17.Text = "kg";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(323, 213);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(27, 20);
			this.label16.TabIndex = 32;
			this.label16.Text = "kg";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(323, 141);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(27, 20);
			this.label15.TabIndex = 31;
			this.label15.Text = "kg";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(152, 137);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(27, 20);
			this.label14.TabIndex = 29;
			this.label14.Text = "kg";
			// 
			// num_oldalas
			// 
			this.num_oldalas.Location = new System.Drawing.Point(29, 342);
			this.num_oldalas.Name = "num_oldalas";
			this.num_oldalas.Size = new System.Drawing.Size(120, 26);
			this.num_oldalas.TabIndex = 30;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(25, 319);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(64, 20);
			this.label9.TabIndex = 29;
			this.label9.Text = "Oldalas";
			// 
			// num_hatszin
			// 
			this.num_hatszin.Location = new System.Drawing.Point(205, 281);
			this.num_hatszin.Name = "num_hatszin";
			this.num_hatszin.Size = new System.Drawing.Size(120, 26);
			this.num_hatszin.TabIndex = 26;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(201, 258);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(58, 20);
			this.label12.TabIndex = 25;
			this.label12.Text = "Hátszín";
			// 
			// num_hatsocomb
			// 
			this.num_hatsocomb.Location = new System.Drawing.Point(205, 207);
			this.num_hatsocomb.Name = "num_hatsocomb";
			this.num_hatsocomb.Size = new System.Drawing.Size(120, 26);
			this.num_hatsocomb.TabIndex = 24;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(201, 184);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(97, 20);
			this.label11.TabIndex = 23;
			this.label11.Text = "Hátsó comb";
			// 
			// num_szegy
			// 
			this.num_szegy.DecimalPlaces = 2;
			this.num_szegy.Location = new System.Drawing.Point(205, 135);
			this.num_szegy.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
			this.num_szegy.Name = "num_szegy";
			this.num_szegy.Size = new System.Drawing.Size(120, 26);
			this.num_szegy.TabIndex = 22;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(201, 112);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(50, 20);
			this.label10.TabIndex = 21;
			this.label10.Text = "Szegy";
			// 
			// num_labszar
			// 
			this.num_labszar.Location = new System.Drawing.Point(205, 342);
			this.num_labszar.Name = "num_labszar";
			this.num_labszar.Size = new System.Drawing.Size(120, 26);
			this.num_labszar.TabIndex = 18;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(201, 319);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(63, 20);
			this.label8.TabIndex = 17;
			this.label8.Text = "Lábszár";
			// 
			// num_tarja
			// 
			this.num_tarja.Location = new System.Drawing.Point(29, 281);
			this.num_tarja.Name = "num_tarja";
			this.num_tarja.Size = new System.Drawing.Size(120, 26);
			this.num_tarja.TabIndex = 16;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(25, 258);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(42, 20);
			this.label7.TabIndex = 15;
			this.label7.Text = "Tarja";
			// 
			// num_elsocomb
			// 
			this.num_elsocomb.Location = new System.Drawing.Point(29, 207);
			this.num_elsocomb.Name = "num_elsocomb";
			this.num_elsocomb.Size = new System.Drawing.Size(120, 26);
			this.num_elsocomb.TabIndex = 14;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(25, 184);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(83, 20);
			this.label5.TabIndex = 13;
			this.label5.Text = "Első comb";
			// 
			// time_vagas
			// 
			this.time_vagas.Location = new System.Drawing.Point(339, 72);
			this.time_vagas.Name = "time_vagas";
			this.time_vagas.Size = new System.Drawing.Size(92, 26);
			this.time_vagas.TabIndex = 12;
			// 
			// date_vagas
			// 
			this.date_vagas.Location = new System.Drawing.Point(205, 72);
			this.date_vagas.Name = "date_vagas";
			this.date_vagas.Size = new System.Drawing.Size(113, 26);
			this.date_vagas.TabIndex = 11;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(335, 49);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 20);
			this.label2.TabIndex = 9;
			this.label2.Text = "Vágás ideje";
			// 
			// num_nyak
			// 
			this.num_nyak.Location = new System.Drawing.Point(29, 135);
			this.num_nyak.Name = "num_nyak";
			this.num_nyak.Size = new System.Drawing.Size(120, 26);
			this.num_nyak.TabIndex = 8;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(25, 112);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(46, 20);
			this.label3.TabIndex = 7;
			this.label3.Text = "Nyak";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(201, 49);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(117, 20);
			this.label4.TabIndex = 5;
			this.label4.Text = "Vágás dátuma";
			// 
			// num_marhaid
			// 
			this.num_marhaid.Location = new System.Drawing.Point(29, 72);
			this.num_marhaid.Name = "num_marhaid";
			this.num_marhaid.Size = new System.Drawing.Size(120, 26);
			this.num_marhaid.TabIndex = 2;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(25, 49);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(38, 20);
			this.label6.TabIndex = 1;
			this.label6.Text = "Kód";
			// 
			// lbl_vagas
			// 
			this.lbl_vagas.AutoSize = true;
			this.lbl_vagas.BackColor = System.Drawing.SystemColors.Control;
			this.lbl_vagas.Location = new System.Drawing.Point(0, 0);
			this.lbl_vagas.Name = "lbl_vagas";
			this.lbl_vagas.Size = new System.Drawing.Size(198, 20);
			this.lbl_vagas.TabIndex = 0;
			this.lbl_vagas.Text = "Vágás adatainak felvitele";
			// 
			// btn_feltoltes
			// 
			this.btn_feltoltes.Location = new System.Drawing.Point(20, 472);
			this.btn_feltoltes.Name = "btn_feltoltes";
			this.btn_feltoltes.Size = new System.Drawing.Size(447, 41);
			this.btn_feltoltes.TabIndex = 27;
			this.btn_feltoltes.Text = "Feltöltés";
			this.btn_feltoltes.UseVisualStyleBackColor = true;
			this.btn_feltoltes.Click += new System.EventHandler(this.btn_feltoltes_Click);
			// 
			// form_meszarszek
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(486, 557);
			this.Controls.Add(this.btn_feltoltes);
			this.Controls.Add(this.pnl_marha);
			this.Controls.Add(this.pnl_vagas);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.menu);
			this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.MainMenuStrip = this.menu;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "form_meszarszek";
			this.Text = "Mészárszék desktop";
			this.menu.ResumeLayout(false);
			this.menu.PerformLayout();
			this.pnl_marha.ResumeLayout(false);
			this.pnl_marha.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.num_elosuly)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_id)).EndInit();
			this.pnl_vagas.ResumeLayout(false);
			this.pnl_vagas.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.num_oldalas)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_hatszin)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_hatsocomb)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_szegy)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_labszar)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_tarja)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_elsocomb)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_nyak)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.num_marhaid)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MenuStrip menu;
		private System.Windows.Forms.ToolStripMenuItem marhaAdatinakFelviteleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem vágásAdatiainakFelviteleToolStripMenuItem;
		private System.Windows.Forms.Panel pnl_marha;
		private System.Windows.Forms.Label lbl_ido_marha;
		private System.Windows.Forms.NumericUpDown num_elosuly;
		private System.Windows.Forms.Label lbl_elosuly;
		private System.Windows.Forms.Label lbl_datum_marha;
		private System.Windows.Forms.Label lbl_fajta;
		private System.Windows.Forms.NumericUpDown num_id;
		private System.Windows.Forms.Label lbl_id;
		private System.Windows.Forms.Label lbl_marha;
		private System.Windows.Forms.TextBox tb_fajta;
		private System.Windows.Forms.DateTimePicker time_marha;
		private System.Windows.Forms.DateTimePicker date_marha;
		private System.Windows.Forms.Panel pnl_vagas;
		private System.Windows.Forms.DateTimePicker time_vagas;
		private System.Windows.Forms.DateTimePicker date_vagas;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown num_nyak;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.NumericUpDown num_marhaid;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label lbl_vagas;
		private System.Windows.Forms.NumericUpDown num_hatszin;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.NumericUpDown num_hatsocomb;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.NumericUpDown num_szegy;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.NumericUpDown num_labszar;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.NumericUpDown num_tarja;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.NumericUpDown num_elsocomb;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btn_feltoltes;
		private System.Windows.Forms.NumericUpDown num_oldalas;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
	}
}

