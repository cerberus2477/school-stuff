function szamol(){
    
var s=0; //költség
let z = document.getElementById("utaz").value[0];
let k = document.getElementById("kiran").value > 0 ? document.getElementById("kiran").value : 1;

if(z=="b"){ //szemelyenkent 450
    s = 450*k;
} 
else if(z=="a"){ //kocsinként (5 fő) 1000
    s = 1000 * Math.ceil(k/5);
} 
else if(z=="k"){ //ingyen van
    s = 0;
} 
else if(z=="g"){ //szintén ingyen
    s = 0
} 

document.getElementById("felelet").innerText = s;
}