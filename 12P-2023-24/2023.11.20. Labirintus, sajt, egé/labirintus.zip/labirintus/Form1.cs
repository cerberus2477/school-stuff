﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labirintus
{
    public partial class frmLabirintus : Form
    {
        gameLogic logic = new gameLogic();
        public frmLabirintus()
        {
            InitializeComponent();

            
        }

        private void labirintustxtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            logic.createFields("labirintus.txt", pnlLabirintus);
        }

        private void labi2txtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            logic.createFields("labi2.txt", pnlLabirintus);
        }
    }
}
