﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat03
{
    internal class Program
    {
        

        static void Main(string[] args)
        {
            //egyesével beolvas egész számokat, addig amíg váltakozó előjelűek
            //írd ki az átlagot, db, össz, legkisebb poz, legnagyobb neg;
            List<int> nums = new List<int>();


            Console.WriteLine("Adjon meg váltakozó előjelű egész számokat!");
            nums.Add(int.Parse(Console.ReadLine()));

            do
            {
                nums.Add(int.Parse(Console.ReadLine()));
            } while (Math.Sign(nums[nums.Count - 1]) != Math.Sign(nums[nums.Count - 2])); 

            Console.WriteLine($"\n A számok");
            Console.WriteLine($"\t darabja: {nums.Count()}");
            Console.WriteLine($"\t átlaga: {nums.Average()}");
            Console.WriteLine($"\t összege: {nums.Sum()}");
            Console.WriteLine($"\t közül a legkisebb pozitív: {(nums.Where(x => x < 0).Count() == 0 ? Convert.ToString(nums.Where(x => x > 0).Min()) : "nincs"  )}");  //ha van pozitív szám akkor azok minimumát adja vissza stringgé konvertálva, ha nincs akkor azt, hogy "nincs".
            Console.WriteLine($"\t közül a legnagyobb negatív: {(nums.Where(x => x > 0).Count() == 0 ? Convert.ToString(nums.Where(x => x < 0).Max()) : "nincs"  )}");
        }
    }
}
