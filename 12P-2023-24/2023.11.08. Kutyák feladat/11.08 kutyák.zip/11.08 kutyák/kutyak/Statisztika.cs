﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.IO;

namespace kutyak
{
    class Statisztika
    {
        private MySqlCommand cmd;
        private MySqlConnection conn = new MySqlConnection("server=localhost;database=kutyak;user=root;password=''"); //nemjó :c

        private MySqlDataReader tryQuery(string cmdstr)
        {
            try
            {
                conn.Open();
                cmd = new MySqlCommand(cmdstr, conn);
                conn.Close();
                return cmd.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "SQL hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
                return null;
            }
        }

        //5
        //SELECT COUNT(kutyanév) FROM `kutyanevek`;
        public string countKutyanev()
        {
            string cmdstr = "SELECT COUNT(kutyanév) FROM `kutyanevek`";
            var res = tryQuery(cmdstr);
            if (res != null)
            {
                return $"5. feladat: Kutyanevek száma: {res}";
            }
            return "A kérés SQL hibába ütközött.";
        }

        //6
        //SELECT ROUND(AVG(életkor), 2) FROM `kutyak`;
        public string avgEletkor()
        {
            string cmdstr = "SELECT ROUND(AVG(életkor), 2) FROM `kutyak`;";
            var res = tryQuery(cmdstr);
            if (res != null)
            {
                return $"6. feladat: Kutyák átlag életkora: {res}";
            }
            return "A kérés SQL hibába ütközött.";
        }

        //8
        public string jan10()
        {
            string cmdstr = "SELECT kutyafajtak.név, COUNT(*) " +
                "FROM `kutyak` INNER JOIN kutyafajtak ON kutyafajtak.id = kutyak.fajta_id " +
                "WHERE `utolsó orvosi ellenőrzés` = 2018.01.10 " +
                "GROUP BY fajta_id;";
            var res = tryQuery(cmdstr);
            if (res != null)
            {
                return $"8. feladat: Kutyák átlag életkora: {res}";
            }
            return "A kérés SQL hibába ütközött.";
        }


        //7 (kinda)
        /*SELECT kutyanevek.kutyanév, kutyafajtak.név
        FROM `kutyak` INNER JOIN kutyafajtak ON kutyafajtak.id =kutyak.fajta_id INNER JOIN kutyanevek ON kutyanevek.id = kutyak.név_id
        ORDER BY életkor DESC
        LIMIT 1;*/

        //10
        public string mentes()
        {
            string cmdstr = "";
            var res = tryQuery(cmdstr);
            if (res != null)
            {
                // data loop
                /*while (reader.Read())
                {
                    // column loop
                    for (int columnCounter = 0; columnCounter < reader.FieldCount; columnCounter++)
                    {
                        if (columnCounter > 0)
                        {
                            writer.Write(Separator);
                        }
                        writer.Write(Delimiter + reader.GetValue(columnCounter).ToString().Replace('"', '\'') + Delimiter);
                    }   // end of column loop
                    writer.WriteLine(string.Empty);
                }   // data loop

                writer.Flush();*/
                return "10. feladat: névstatisztika.txt";
            }
            return "A kérés SQL hibába ütközött.";
        }



    }
}
