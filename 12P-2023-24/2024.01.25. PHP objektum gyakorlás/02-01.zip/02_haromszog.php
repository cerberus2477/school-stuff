<!-- 
Készíts egy háromszög összterületszámító webes alkalmazást! 
Kérd be, hogy hány háromszög területét szeretnék kiszámolni! 
Kérd be a háromszögek oldalainak hosszát (mm-ben)! Listázd ki a háromszögeket és a területeiket, majd a végén az összterületet! Használj háromszög osztályt!   -->

<?php
    class Haromszog{
        protected $a;
        protected $b;
        protected $c;

        function __construct($a, $b, $c){
            $this->a = $a;
            $this->b = $b;
            $this->c = $c;
        }

        function terulet(){
            if (!($this->a+$this->b>$this->c && $this->a+$this->c>$this->b && $this->b+$this->c>$this->a)){
                return "-";
            }
            else{
                $s = $this->a + $this->b + $this->c;
                return sqrt($s*($s-$this->a)*($s-$this->b)*($s-$this->c));;
            } 
        }
    }




    if(!(isset($_POST['a']) && isset($_POST['b']) && isset($_POST['c']))){
        $uzenet = "Adja meg a számokat!";
    }else{
        $a_arr = array_map('intval', explode(";", $_POST['a']));
        $b_arr = array_map('intval', explode(";", $_POST['b']));
        $c_arr = array_map('intval', explode(";", $_POST['c']));

        $teruletek = array();
        for ($i=0; $i < count($a_arr); $i++) { 
            $haromszog = new Haromszog($a_arr[$i], $b_arr[$i], $c_arr[$i]);
            array_push($teruletek, $haromszog->terulet());
        }                                             
        $uzenet = "A háromszögek területe: ".join(', ', array_map(fn($t): float => round($t, 2) , $teruletek))."<br>ΣT: ".round(array_sum($teruletek), 2);
    }

    ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2) Háromszögek</title>
</head>
<body>
<div>
        <h2>2) Háromszögek</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <p>
                <p>Az adatokat ;-tal elválasztva, (pl 3 háromszög esetén 2;3;16) kell megadni</p>
                <label for="a">a:</label>
                <input required type="text" id="a" name="a"><br>
                <label for="b">b:</label>
                <input required type="text" id="b" name="b"><br>
                <label for="b">c:</label>
                <input required type="text" id="c" name="c"><br>
                <input type="submit" value="OK">
            </p>
        </form>
        <h1><?php echo $uzenet ?></h1>
    </div>  

</body>
</html>