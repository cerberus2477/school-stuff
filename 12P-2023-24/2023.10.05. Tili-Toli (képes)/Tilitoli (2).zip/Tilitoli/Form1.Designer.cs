﻿
namespace Tilitoli {
	partial class Tilitoli {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if(disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.components = new System.ComponentModel.Container();
			this.pnlGombok = new System.Windows.Forms.Panel();
			this.pnlCim = new System.Windows.Forms.Panel();
			this.lblCim = new System.Windows.Forms.Label();
			this.lblOszlop = new System.Windows.Forms.Label();
			this.lblSor = new System.Windows.Forms.Label();
			this.nmOszlop = new System.Windows.Forms.NumericUpDown();
			this.nmSor = new System.Windows.Forms.NumericUpDown();
			this.lblCsere = new System.Windows.Forms.Label();
			this.lblMp = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.btnKepes = new System.Windows.Forms.Button();
			this.btnSzamos = new System.Windows.Forms.Button();
			this.pnlOldal = new System.Windows.Forms.Panel();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.btnUj = new System.Windows.Forms.Button();
			this.pnlCim.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nmOszlop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nmSor)).BeginInit();
			this.pnlOldal.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlGombok
			// 
			this.pnlGombok.Location = new System.Drawing.Point(20, 156);
			this.pnlGombok.Margin = new System.Windows.Forms.Padding(5);
			this.pnlGombok.Name = "pnlGombok";
			this.pnlGombok.Size = new System.Drawing.Size(400, 400);
			this.pnlGombok.TabIndex = 0;
			// 
			// pnlCim
			// 
			this.pnlCim.BackColor = System.Drawing.Color.Transparent;
			this.pnlCim.Controls.Add(this.lblCim);
			this.pnlCim.Location = new System.Drawing.Point(20, 19);
			this.pnlCim.Margin = new System.Windows.Forms.Padding(5);
			this.pnlCim.Name = "pnlCim";
			this.pnlCim.Size = new System.Drawing.Size(624, 117);
			this.pnlCim.TabIndex = 1;
			// 
			// lblCim
			// 
			this.lblCim.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
			this.lblCim.AutoSize = true;
			this.lblCim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblCim.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.lblCim.Location = new System.Drawing.Point(52, 36);
			this.lblCim.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblCim.Name = "lblCim";
			this.lblCim.Size = new System.Drawing.Size(195, 42);
			this.lblCim.TabIndex = 0;
			this.lblCim.Text = "Tilitoli játék";
			this.lblCim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblOszlop
			// 
			this.lblOszlop.AutoSize = true;
			this.lblOszlop.Location = new System.Drawing.Point(16, 260);
			this.lblOszlop.Name = "lblOszlop";
			this.lblOszlop.Size = new System.Drawing.Size(133, 21);
			this.lblOszlop.TabIndex = 6;
			this.lblOszlop.Text = "Oszlopok száma";
			// 
			// lblSor
			// 
			this.lblSor.AutoSize = true;
			this.lblSor.Location = new System.Drawing.Point(16, 298);
			this.lblSor.Name = "lblSor";
			this.lblSor.Size = new System.Drawing.Size(109, 21);
			this.lblSor.TabIndex = 5;
			this.lblSor.Text = "Sorok száma:";
			// 
			// nmOszlop
			// 
			this.nmOszlop.Location = new System.Drawing.Point(155, 258);
			this.nmOszlop.Name = "nmOszlop";
			this.nmOszlop.Size = new System.Drawing.Size(38, 27);
			this.nmOszlop.TabIndex = 4;
			this.nmOszlop.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
			// 
			// nmSor
			// 
			this.nmSor.Location = new System.Drawing.Point(155, 296);
			this.nmSor.Name = "nmSor";
			this.nmSor.Size = new System.Drawing.Size(38, 27);
			this.nmSor.TabIndex = 3;
			this.nmSor.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
			// 
			// lblCsere
			// 
			this.lblCsere.AutoSize = true;
			this.lblCsere.Location = new System.Drawing.Point(16, 137);
			this.lblCsere.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblCsere.Name = "lblCsere";
			this.lblCsere.Size = new System.Drawing.Size(58, 21);
			this.lblCsere.TabIndex = 2;
			this.lblCsere.Text = "Csere:";
			// 
			// lblMp
			// 
			this.lblMp.AutoSize = true;
			this.lblMp.Location = new System.Drawing.Point(16, 173);
			this.lblMp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblMp.Name = "lblMp";
			this.lblMp.Size = new System.Drawing.Size(40, 21);
			this.lblMp.TabIndex = 1;
			this.lblMp.Text = "Mp:";
			// 
			// btnKepes
			// 
			this.btnKepes.Location = new System.Drawing.Point(3, 0);
			this.btnKepes.Name = "btnKepes";
			this.btnKepes.Size = new System.Drawing.Size(107, 55);
			this.btnKepes.TabIndex = 7;
			this.btnKepes.Text = "Kép feltöltése";
			this.btnKepes.UseVisualStyleBackColor = true;
			this.btnKepes.Click += new System.EventHandler(this.btnKepes_Click);
			// 
			// btnSzamos
			// 
			this.btnSzamos.Location = new System.Drawing.Point(110, 0);
			this.btnSzamos.Name = "btnSzamos";
			this.btnSzamos.Size = new System.Drawing.Size(109, 55);
			this.btnSzamos.TabIndex = 8;
			this.btnSzamos.Text = "Játék számokkal";
			this.btnSzamos.UseVisualStyleBackColor = true;
			this.btnSzamos.Click += new System.EventHandler(this.btnSzamos_Click);
			// 
			// pnlOldal
			// 
			this.pnlOldal.BackColor = System.Drawing.Color.Transparent;
			this.pnlOldal.Controls.Add(this.btnUj);
			this.pnlOldal.Controls.Add(this.lblMp);
			this.pnlOldal.Controls.Add(this.lblCsere);
			this.pnlOldal.Controls.Add(this.btnKepes);
			this.pnlOldal.Controls.Add(this.nmSor);
			this.pnlOldal.Controls.Add(this.nmOszlop);
			this.pnlOldal.Controls.Add(this.btnSzamos);
			this.pnlOldal.Controls.Add(this.lblOszlop);
			this.pnlOldal.Controls.Add(this.lblSor);
			this.pnlOldal.Location = new System.Drawing.Point(428, 156);
			this.pnlOldal.Name = "pnlOldal";
			this.pnlOldal.Size = new System.Drawing.Size(219, 400);
			this.pnlOldal.TabIndex = 3;
			// 
			// openFileDialog
			// 
			this.openFileDialog.FileName = "openFileDialog";
			// 
			// btnUj
			// 
			this.btnUj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnUj.Location = new System.Drawing.Point(3, 61);
			this.btnUj.Name = "btnUj";
			this.btnUj.Size = new System.Drawing.Size(213, 55);
			this.btnUj.TabIndex = 9;
			this.btnUj.Text = "Új játék indítása";
			this.btnUj.UseVisualStyleBackColor = true;
			this.btnUj.Click += new System.EventHandler(this.btnUj_Click);
			// 
			// Tilitoli
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::Tilitoli.Properties.Resources.bg;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(663, 567);
			this.Controls.Add(this.pnlOldal);
			this.Controls.Add(this.pnlCim);
			this.Controls.Add(this.pnlGombok);
			this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.Margin = new System.Windows.Forms.Padding(5);
			this.MaximizeBox = false;
			this.Name = "Tilitoli";
			this.Text = "Tilitoli";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.pnlCim.ResumeLayout(false);
			this.pnlCim.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nmOszlop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nmSor)).EndInit();
			this.pnlOldal.ResumeLayout(false);
			this.pnlOldal.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel pnlGombok;
		private System.Windows.Forms.Panel pnlCim;
		private System.Windows.Forms.Label lblCim;
		private System.Windows.Forms.Label lblMp;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label lblCsere;
		private System.Windows.Forms.Label lblOszlop;
		private System.Windows.Forms.Label lblSor;
		private System.Windows.Forms.NumericUpDown nmOszlop;
		private System.Windows.Forms.NumericUpDown nmSor;
		private System.Windows.Forms.Button btnKepes;
		private System.Windows.Forms.Button btnSzamos;
		private System.Windows.Forms.Panel pnlOldal;
		public System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.Button btnUj;
	}
}

