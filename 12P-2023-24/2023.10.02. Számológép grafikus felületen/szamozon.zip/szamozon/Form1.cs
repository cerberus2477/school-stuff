﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace szamozon
{
    public partial class frmSzinozon : Form
    {
        static int rowNum = 12; //sorok száma
        static int colNum = 4; //oszlopok száma
        Color[] colors = { Color.Yellow, Color.Orange, Color.Red, Color.Purple, Color.Blue, Color.Green };
        Random rnd = new Random();
        Button[,] guesses = new Button[colNum, rowNum];
        Button[] solution = new Button[colNum]; 
        Button[] checkBtns = new Button[rowNum]; 
        Label[,] feedback = new Label[rowNum, 2];

        public frmSzinozon()
        {
            InitializeComponent();
        }


        private void Számözön_Load(object sender, EventArgs e)
        {
            int btnWidth = this.panel2.ClientSize.Width / colNum;
            int btnHeight = this.panel2.ClientSize.Height / rowNum;
            int sorszam = 0;
            for (int i = 0; i < colNum; i++)
            {
                for (int j = 0; j < rowNum; j++)
                {
                    sorszam++;

                    guesses[i, j] = new Button();
                    guesses[i, j].Name = sorszam.ToString();
                    guesses[i, j].Size = new Size(btnWidth, btnHeight);
                    guesses[i, j].Location = new Point(i * btnWidth, j * btnHeight);
                    guesses[i, j].Visible = true;

                    this.panel2.Controls.Add(guesses[i, j]);
                    this.guesses[i, j].Click += new EventHandler(this.nextColor);
                }
            }

            for (int i = 0; i < colNum; i++)
            {
                sorszam++;
                solution[i] = new Button();
                solution[i].Name = sorszam.ToString();
                solution[i].Size = new Size(btnWidth, btnHeight);
                solution[i].Location = new Point(i * btnWidth, 0);
                solution[i].Visible = true;
                this.panel1.Controls.Add(solution[i]);
            }


            for (int i = 0; i < rowNum; i++)
            {
                sorszam++;
                checkBtns[i] = new Button();
                checkBtns[i].Name = sorszam.ToString();
                checkBtns[i].Size = new Size(btnWidth, btnHeight);
                checkBtns[i].Location = new Point(0, i * btnHeight);
                checkBtns[i].BackColor = Color.FloralWhite;
                checkBtns[i].Text = "OK";
                checkBtns[i].Visible = true;
                this.panel3.Controls.Add(checkBtns[i]);
                checkBtns[i].Click += new EventHandler(this.checkGuess);
            }

            for (int i = 0; i < rowNum; i++)
            {
                sorszam++;

                feedback[i, 0] = new Label();
                feedback[i, 1] = new Label();

                feedback[i, 0].Location = new Point(20, i * btnHeight + 3);
                feedback[i, 1].Location = new Point(20, i * btnHeight + 23);

                feedback[i, 0].Text = "";
                feedback[i, 1].Text = "";

                feedback[i, 0].ForeColor = Color.Red;
                feedback[i, 1].ForeColor = Color.White;

                feedback[i, 0].Font = new Font("Century Gothic", 13);
                feedback[i, 1].Font = new Font(guesses[1, 1].Font.Name, 13);


                this.panel4.Controls.Add(feedback[i, 0]);
                this.panel4.Controls.Add(feedback[i, 1]);

                feedback[i, 0].Visible = true;
                feedback[i, 1].Visible = true;

                //this.panel4.BackColor = (142; 166; 219; 255)

            }


            Clear();
            Shuffle();
        }


        private void nextColor(object sender, EventArgs e)
        {
            int colorIndex = Array.IndexOf(colors, (sender as Button).BackColor);
            (sender as Button).BackColor = colorIndex == colors.Length - 1 ? colors[0] : colors[colorIndex + 1];
        }


        private int countRed(int sor) //piros pöcök az eredeti játlékban, jó helyen lévők (itt piros kiírás)
        {
            int db = 0;
            for (int i = 0; i < colNum; i++)
            {
                if (solution[i].BackColor == guesses[i, sor].BackColor) db++;
            }
            return db;
        }

        private int countWhite(int sor) //piros pöcök az eredeti játlékban, van ilyen szín de nem jó helyen
        {

            bool van;
            int db = 0;
            List<int> vanmar = new List<int>();
            for (int i = 0; i < colNum; i++)
            {
                van = false;
                int oszlop = 0;
                while (!van && oszlop < colNum)
                {
                    if (solution[oszlop].BackColor == guesses[i, sor].BackColor && !vanmar.Contains(oszlop))
                    {

                        vanmar.Add(oszlop); van = true; db++;
                    }
                    oszlop++;
                }
            }
            return db - countRed(sor);
        }


        private void checkGuess(object sender, EventArgs e)
        {
            int row = Array.IndexOf(checkBtns, sender as Button);

            feedback[row, 0].Text = Convert.ToString(countRed(row));
            feedback[row, 1].Text = Convert.ToString(countWhite(row));

            for (int i = 0; i < colNum; i++)
            {
                for (int j = 0; j < rowNum; j++)
                {
                    if (j != row + 1)
                    {
                        guesses[i, j].Enabled = false;
                        checkBtns[j].Enabled = false;
                    }
                    else
                    {
                        guesses[i, j].Enabled = true;
                        checkBtns[j].Enabled = true;
                    }
                }
            }
 
            

            if (countRed(row) == colNum)
            {
                MessageBox.Show("Sikerült kirakni!", "GG", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else
            {
                if(row + 1 == rowNum)
                {
                    MessageBox.Show("You did the dieing! \n(Nem nyertél)", "BG", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
            }

        }

        
        private void Clear()
        {
            for (int i = 0; i < colNum; i++)
            {
                solution[i].BackColor = Color.FloralWhite;
                for (int j = 0; j < rowNum; j++)
                {
                    guesses[i, j].BackColor = Color.FloralWhite;
                }
            }

            for (int i = 0; i < rowNum; i++)
            {
                feedback[i, 0].Text = "";
                feedback[i, 1].Text = "";
            }
            panel1.Visible = true;
        }

        private void Shuffle()
        {
            for (int i = 0; i < colNum; i++)
            {
                solution[i].BackColor = colors[rnd.Next(0, 6)];
                panel1.Visible = false;
            }
        }
        private void btnUj_Click(object sender, EventArgs e) //nem generál megoldást
        {
            Clear();
        }
 

        private void btnRejt_Click(object sender, EventArgs e) //igazabol toggle
        {
            panel1.Visible = !panel1.Visible;
            this.btnRejt.Text = this.btnRejt.Text == "Elrejt" ? "Mutat" : "Elrejt";
        }

        private void btnKever_Click(object sender, EventArgs e) //kever aztan elrejt
        {
            Shuffle();
        }
    }
}
