<!-- Készíts egy weboldalt mely a következő feltételeknek, céloknak felel meg: 
- síkidomokkal/  testekkel 
- 4 sikidom vagy 4 test közül választás
- bekéri az adatait a  kiszámításához, 
- kerület, terület, térfogat, felület, élek hossza
A számoláshoz, megjelenítéshez használj osztályokat! 
Figyelj az esztétikára! 
A feladatot php segítségével old meg!  -->


<?php

// sikidomok

abstract class Sikidom {
    abstract public function kerulet();
    abstract public function terulet();
} 


class Kor extends Sikidom{
    private $rad;

    public function __construct($rad) {
        $this->rad = $rad;
    }

    public function terulet() {
        return pi() * pow($this->rad, 2);
    }

    public function kerulet() {
        return 2 * pi() * $this->rad;
    }
}

class Teglalap extends Sikidom{
    private $a;
    private $b;

    public function __construct($a, $b) {
        $this->a = $a;
        $this->b = $b;
    }

    public function terulet() {
        return $this->a * $this->a;
    }

    public function kerulet() {
        return 4 * $this->a;
    }
}

//xd ez nem igy van
class Negyzet extends Teglalap{
    private $a;

    public function __construct($a) {
        $this->a = $a;
    }

    public function terulet() {
        return $this->a * $this->a;
    }

    public function kerulet() {
        return 4 * $this->a;
    }
}

class Haromszog extends Sikidom{
    private $a;
    private $b;
    private $c;

    public function __construct($a, $b, $c) {
        $this->a = $a;
        $this->b = $b;
        $this->c = $c;
    }

    public function terulet() {
        $s = $this->kerulet() / 2;
        return $s * ($s - $this->a) * ($s - $this->b) * ($s - $this->c);
    }

    public function kerulet() {
        return $this->a + $this->b + $this->c;
    }
}



//testek
abstract class Test {
    abstract public function felulet();
    abstract public function terfogat();
} 

class Gomb extends Test{
    private $rad;

    public function __construct($rad) {
        $this->rad = $rad;
    }

    public function terfogat() {
        return 4/3 * pi() * pow($this->rad, 3)
    }
 
    public function felulet() {
        return 4 * pi() * $this->rad * $this->rad;
    }
}

class Teglatest{
    private $a;
    private $b;
    private $c;

    public function __construct($a) {
        $this->a = $a;
        $this->b = $b;
        $this->c = $c;
    }

    public function terfogat() {
        return $this->a * $this->b * $this->c;
    }

    public function felulet() {
        return 2 * (new Teglalap($a, $b)->terulet() + new Teglalap($a, $c)->terulet() + new Teglalap($c, $b)->terulet());
    }
}

class Kocka extends Teglatest{
    
}

//haromszog alapu hasab?



// form kezelese
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sikvagytest = $_POST['AlakzatTipus'];
    $valasztottAlakzat = $_POST['valasztottAlakzat'];
    $Alakzat = null; //hmm

   
    switch ($selectedAlakzat){
        case "Kor":
            $rad = $_POST['rad'];
            $Alakzat = new Gomb($rad);
        //...
    }

    if ($Alakzat) {
        if ($sikvagytest == "Síkidom")
            echo "Terület: ".$Alakzat->terulet()."<br>";
            echo "Kerület: ".$Alakzat->kerulet()."<br>";
        }
        else{
            echo "Térfogat: ".$Alakzat->terfogat()."<br>";
            echo "Felület: ".$Alakzat->felulet()."<br>";
        }
}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>6) Testek</title>
</head>
<body>
    <h1>6) Testek</h1>
    <form method="post" action="">
        <label>Síkidom vagy test:</label>
        <select name="AlakzatTipus">
            <option value="Síkidom">Síkidom</option>
            <option value="Test">Test</option>
        </select>

        <label>Válasszon egy <?php echo $AlakzatTipus ?><-t:</label>
        <?php
        $alakzatok = ($sikvagytest == 'Síkidom') ? ['Kör', 'Téglalap', 'Négyzet', 'Szabályos háromszög' ] : ['Gömb', 'Téglatest', 'Kocka', 'Háromszög alapú hasáb'];
        echo '<select name="selectedAlakzat">';
        foreach ($alakzatok as $Alakzat) {
            echo "<option value=\"$Alakzat\">$Alakzat</option>";
        }
        echo '</select>';
        ?>

        <label>Adja meg az adatokat:</label>
        <?php
        //DOLGOKKK
        $dimensionLabel = ($sikvagytest == '2D') ? 'rad' : 'a';
        echo '<input type="text" name="'.$dimensionLabel.'placeholder="'.$dimensionLabel.'">';?>

        <input type="submit" value="OK">
    </form>
</body>
</html>