﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _04._24Futoverseny
{
	class Program
	{
		static Irodavezeto iroda = new Irodavezeto();




		public class Ugynok
		{
			private string nev;
			private int kod, aktKotesek = 0, ber = 0;

			public Ugynok(string nev, int kod)
			{
				this.nev = nev;
				this.kod = kod;
			}

			/*public void indulasiBe(TimeSpan indulas)
			{
				this.indulas = indulas;
			}

			public void ErkezesiBe(TimeSpan erkezes)
			{
				this.erkezes = erkezes;
			}*/


			public bool NevHasonlit(string nev)
			{
				return this.nev == nev;
			}


			public int CompareTo(Ugynok valaki)
			{
				if (aktKotesek < valaki.aktKotesek)
				{
					return -1;
				}
				else if (aktKotesek > valaki.aktKotesek)
				{
					return 1;
				}
				else
				{
					if (nev.CompareTo(valaki.nev) == -1)
					{
						return -1;
					}
					else if (nev.CompareTo(valaki.nev) == 1)
					{
						return 1;
					}
					else
					{
						return 0;
					}
				}

				
			}



			public int GetAktKotesek()
			{
				return aktKotesek;
			}

			public int GetKod()
			{
				return kod;
			}

			public void SetAktKotesek(int db)
			{
				this.aktKotesek = db;
			}

			/*public string GetNev()
			{
				return nev;
			}*/


			public override string ToString()
			{
				return $"{aktKotesek}, {kod}, {nev}, {ber}";
			}

			public void Kifizet()
			{
				ber += iroda.GetNyilv().GetJutalek() * aktKotesek;
			}
		}




		class Nyilvantartas
		{
			private Ugynok[] ugynokok = new Ugynok[10000];
			private int db = 0;
			private int jutalek = 10000;

			public void Hozzaad(string nev, int kod)
			{
				ugynokok[db] = new Ugynok(nev, kod);
				db++;
			}

			public int Keres(string nev) //ha nem talál -1
			{
				Ugynok[] talalat = ugynokok.Where(u => u.NevHasonlit(nev)).ToArray();
				if (talalat.Count() == 1)
				{
					return Array.IndexOf(ugynokok, talalat[0]);
				}
				else if (talalat.Count() == 0)
				{
					return -1;
				}
				else
				{
					Console.Write($"Válasszon a ");

					foreach (var ugynok in talalat)
					{
						Console.Write($"{ugynok.GetKod()} ");
					}
					Console.Write("kódok közül: ");

					return Array.IndexOf(ugynokok, int.Parse(Console.ReadLine()));
				}

			}

			public void UjKotesek(int i, int db)
			{
				Ugynok u = ugynokok[i];
				u.SetAktKotesek(u.GetAktKotesek() + db);
			}

			public void SetJutalek(int jutalek)
			{
				this.jutalek = jutalek;
			}

			public int GetJutalek()
			{
				return jutalek;
			}

			public void Rendez()
			{
				for (int i = 0; i < db; i++)
				{
					int min = i;
					for (int j = i + 1; j < db; j++)
					{
						if (ugynokok[j].CompareTo(ugynokok[min]) == -1)
						{
							min = j;
						}
					}
					var temp = ugynokok[i];
					ugynokok[i] = ugynokok[min];
					ugynokok[min] = temp;
				}
			}

			public void Listaz()
			{

				Console.WriteLine("Aktuális biztosítások, kód, név, bér");
				Console.WriteLine("----------------------------------------------------------------------------------");
				foreach (var u in ugynokok)
				{
					Console.WriteLine(u);
				}
			}

			public void HonapVege()
			{
				List<int> elbocsatando = new List<int>();
				for (int i = 0; i < db; i++)
				{
					Ugynok u = ugynokok[i];
					if (u.GetAktKotesek() > 3)
					{
						u.Kifizet();
						u.SetAktKotesek(0);
					}
					else
					{
						elbocsatando.Add(i);
					}
				}

				foreach (var i in elbocsatando)
				{
					Elbocsát(i);
				}
			}

			public void Elbocsát(int index)
			{

				for (int i = index; i < db - 1; i++)
				{
					ugynokok[i] = ugynokok[i + 1];
				}
			}

		}


		class Irodavezeto
		{
			private Nyilvantartas nyilv = new Nyilvantartas();
			
			public Nyilvantartas GetNyilv()
			{
				return nyilv;
			}

			public void UjUgynok()
			{
				Console.WriteLine("Adja meg a szükséges adatokat!");

				Console.Write("\tNév: ");
				string nev = Console.ReadLine();
				Console.Write("\tKód: ");
				int kod = int.Parse(Console.ReadLine());

				nyilv.Hozzaad(nev, kod);
				Console.WriteLine("\nA hozzáadás sikeres volt.");
			}

			public void UjBiztositasok()
			{
				Console.WriteLine("Adja meg a szükséges adatokat!");

				Console.Write("\tNév: ");
				string nev = Console.ReadLine();
				int index = nyilv.Keres(nev);
				if (index == -1)
				{
					Console.WriteLine("Nincs ilyen nevű ügynök!");
					return;
				}
				else
				{
					Console.Write("\tÚj biztosítások száma ");
					int bizt = int.Parse(Console.ReadLine());
					nyilv.UjKotesek(index, bizt);
					Console.WriteLine("\nA hozzáadás sikeres volt.");
				}

			}

			public void JutalekModositas()
			{
				Console.WriteLine("Adja meg a szükséges adatokat!");
				Console.Write("\tÚj egységes jutalék: ");
				int jut = int.Parse(Console.ReadLine());
				nyilv.SetJutalek(jut);
				Console.WriteLine("\nA módosítás sikeres volt.");
			}

			//TODO
			public void SorrendKiiras()
			{
				nyilv.Rendez();
				nyilv.Listaz();

				Console.WriteLine();
				//nyilv.SzerzBontKiir();
				//Console.WriteLine($"A háromnál több szerződést kötő értékesítési igazgatók száma: {nyilv.HaromnalTobbSzama()}");
			
			}

			//TODO
			public void HonapVege()
			{
				nyilv.HonapVege();
				Console.WriteLine("Vége a hónapnak, a 3-nál kevesebb új biztosítást kötő ügynökök elbocsátásra kerültek, a maradék ügynököt kifizettük.");
			}

			public void Kilepes()
			{
				Console.WriteLine("A program 3 másodperc múlva leáll.\nViszontlátásra!");
				Thread.Sleep(3000);
				Environment.Exit(0);
			}
		}


		static void Main(string[] args)
		{
			string[] menupontok =
			{
				"Új ügynök",
				"Új biztosítások rögzítése",
				"Egységes jutalék módosítása",
				"Listázás megkötött biztosítások szerint",
				"Hónap vége",
				"Kilépés"
			};

			bool run = true;
			while (run)
			{
				Console.Clear();
				Console.Title = "Biztosítótársaság";
				for (int i = 0; i < menupontok.Length; i++)
				{
					Console.WriteLine($"{i + 1}. {menupontok[i]}");
				}

				Console.Write("\nAdja meg a választott menüpont számát: ");

				int valasztott = -1;
				try
				{
					valasztott = int.Parse(Console.ReadLine());
					Console.Title = menupontok[valasztott - 1];
				}
				catch (Exception)
				{
					throw;
				}
				Console.Clear();

				switch (valasztott)
				{
					case 1:
						
						iroda.UjUgynok();
						break;

					case 2:
						iroda.UjBiztositasok();
						break;


					case 3:
						iroda.JutalekModositas();
						break;
					case 4:

						iroda.SorrendKiiras();
						break;

					case 5:
						iroda.HonapVege();
						break;

					case 6:
						iroda.Kilepes();
						break;

					default:
						Console.WriteLine("\nA megadott számok közül válasszon!");
						break;
				}

				Console.WriteLine("\nNyomjon le egy billentyűt a visszalépéshez!");
				Console.ReadKey();
			}
		}
	}
}

