<!-- 
Hozd létre a Szamolo osztályt, amely két egész számot tárol! 
Írj hozzá egy kiir() nevű tagfüggvényt, amely kiírja a két számot a böngészőbe! 
-Hozd létre az Osszead osztályt, mely a Szamolo osztálytól örököl! Írd át ennek a kiir() tagfüggvényét, hogy a két szám összegét írja ki a böngészőbe! 
-Az előző feladathoz hasonlóan készítsd el a Kivon osztályt!  -->

<?php
    class Szamolo{
        protected $a;
        protected $b;

        function __construct($a, $b){
            $this->a = $a;
            $this->b = $b;
        }

        function kiir(){
            return $this->a.", ".$this->b;
        }
    }



    class Osszead extends Szamolo{

        function __construct($a, $b){
            parent::__construct($a, $b);
        }
         function kiir(){
            return $this->a + $this->b;
        }
    }

    class Kivon extends Szamolo{

        function __construct($a, $b){
            parent::__construct($a, $b);
        }
         function kiir(){
            return $this->a - $this->b;
        }
    }


    if(!(isset($_POST['a']) && isset($_POST['b']))){
        $uzenet = "Adja meg a számokat!";
    }else{
        $a = $_POST['a']; $b = $_POST['b'];
        $szamolo = new Szamolo($a, $b);
        $osszead= new Osszead($a, $b);
        $kivon = new Kivon($a, $b);
        $uzenet = "A két szám: ".$szamolo->kiir()."<br>Összegük: ".$osszead->kiir()."<br>Különbségük: ".$kivon->kiir().".";
    }

    ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1) Számoló</title>
</head>
<body>
<div>
        <h2>1) Számoló</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <p>
                <label for="a">Első szám:</label>
                <input required type="number" id="a" name="a"><br>
                <label for="b">Második szám:</label>
                <input required type="number" id="b" name="b"><br>
                <input type="submit" value="OK">
            </p>
        </form>
        <h1><?php echo $uzenet ?></h1>
    </div>  

</body>
</html>