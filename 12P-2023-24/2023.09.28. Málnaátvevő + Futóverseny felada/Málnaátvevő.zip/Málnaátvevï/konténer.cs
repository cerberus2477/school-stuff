﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Málnaátvevő
{
    class konténer
    {
        private málnaeladó[] eladók = new málnaeladó[1000];
        private int fő = 0;

        public bool Üres()
        {
            return fő == 0;
        }

        public void Hozzáad(string név, int sorszám)
        {
            eladók[fő] = new málnaeladó(név, sorszám);
            fő++;
            Rendez();
        }

        private void Rendez()
        {
            for (int i = 0; i < fő; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < fő; j++)
                {
                    if (eladók[j].CompareTo(eladók[minIndex]) < 0)
                        minIndex = j;
                }
                if (minIndex != i)
                {
                    málnaeladó segéd = eladók[i];
                    eladók[i] = eladók[minIndex];
                    eladók[minIndex] = segéd;
                }
            }
        }

        public bool Málnabe(string név, int sorsz, double mennyiség)
        {
            bool vissza = true;
            int index = keres(név, sorsz);
            if (index != -1) eladók[index].Málnabe(mennyiség);
            else vissza = false;
            return vissza;
        }

        private int keres(string név, int sorsz)
        {
            int index = -1, i = 0;
            while (i < fő && (eladók[i].Névhasonlít(név) != 0 || !eladók[i].Számhasonlít(sorsz))) i++;
            if (i < fő) index = i;
            return index;
        }

        public string Listáz() //Environment.NewLine
        {
            int darab = 0;
            string szöveg = "";
            Console.WriteLine("A málnaeladók listája:");
            for (int i = 0; i < fő; i++)
            {
                szöveg += eladók[i].ToString() + Environment.NewLine;
                //Console.WriteLine(eladók[i].ToString());
                if (eladók[i].Mennyiség() > 0) darab++;
            }
            szöveg += Convert.ToString(fő) + "fő málnaeladó van." + Environment.NewLine;
            //Console.WriteLine("{0} fő málnaeladó van.", fő);
            szöveg += "Ebből " + Convert.ToString(darab) + " fő szálított is málnát.";
            Console.WriteLine("Ebből {0} fő szálított is málnát.", darab);
            return szöveg;
        }
    }
}
