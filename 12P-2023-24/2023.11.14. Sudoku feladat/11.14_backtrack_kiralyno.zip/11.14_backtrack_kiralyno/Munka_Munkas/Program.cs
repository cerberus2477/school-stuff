﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Munka_Munkas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int max = 10;
            int na = 0;
            int[] ma = new int[max];
            string[,] sa = new string[max, max];
            int[] xa = new int[max];
            string[] kella = new string[max];
            bool vana = false;

            Beolvasas(ref na, ref ma, ref sa, ref kella);
            Kereses(na, ma, sa, kella, ref vana, ref xa);
            Kiiras(na, sa, vana, xa);

        }

        //kell: a munkák amikre a cégnek szüksége van (pl. ["festő", "mázoló", "asztalos"])
        //s: munkások= pl [["festő", "mázoló", "kőműves"], ["festő"], ...]
        //n: munkások (s) száma
        static void Beolvasas(ref int n, ref int[] m, ref string[,] s, ref string[] kell)
        {
            int i, j;
            Console.Write("Hány munkás van? ");
            n = Convert.ToInt32(Console.ReadLine());

            for (i = 0; i < n; i++)
            {
                Console.Write($"\nHány foglalkozása van a {i+1}. munkásnak? ");
                m[i] = Convert.ToInt32(Console.ReadLine());

                for(j = 0; j < m[i]; j++)
                {
                    Console.Write($"{i+i}. munkás {j+1} foglalkozása: ");
                    s[i, j] = Console.ReadLine();
                }
            }
            for (i = 0; i < n; i++)
            {
                Console.WriteLine($"{i+1}. állásajánlat: ");
                kell[i] = Console.ReadLine();
            }

        }

        static void Kiiras(int n, string[,] s, bool van, int[] x)
        {
            int i;
            if (van)
            {
                Console.WriteLine("Egy megoldás:");
                Console.WriteLine(String.Join(" | ", x.Take(n)));
                //x.Take(n).Select(e => $"{i+1} munkás {s[i]} munkát kap");
                for (int i = 0; i < length; i++)
                {
                    Console.WriteLine($"{i+1} munkás {s[i]} munkát kap");
                }
            }
        }

        static bool Elem_e(string szoveg, int db, string[] tomb)
        {
            int i = 0;
            while (i < db && tomb[i] != szoveg)
            {
                i++;
            }
            return (i < db);
        }

        static bool Rossz_eset(int n, string[,] s, string[] kell, int[] x, int i, int melyik)
        {
            bool rossz;
            int l;
            if (!Elem_e(s[i, melyik], n, kell))
            {
                rossz = true;
            }
            else
            {
                l = 0;
                while ((l<i) && (s[i, melyik] != s[l, x[l]]))
                {
                    l++;
                }
                rossz = l < i;
            }
            return rossz;
        }

        static void Jo_Eset_Kereses(int n, int[] m, string[,] s, string[] kell, int[] x, int i, ref int melyik, ref bool van)
        {
            melyik = x[i] + 1;
            while (melyik < m[i] && Rossz_eset(n, s, kell, x, i, melyik))
            {
                melyik++;
            }
            van = melyik < m[i];
        }

        static void Kereses(int n, int[] m, string[,] s, string[] kell, ref bool van, ref int[] x)
        {
            int i; int melyik = 0;
            for (i = 0; i < n; i++)
            {
                x[i] = -1;
            }
            i = 0;
            while (i>= 0 && i<n)
            {
                Jo_Eset_Kereses(n, m, s, kell, x, i, ref melyik, ref van);
                if (van)
                {
                    x[i] = melyik;
                    i++;
                }
                else
                {
                    x[i] = -1;
                    i--;
                }
            }
            if (i == n)
            {
                van = true;
            }
    }
}
