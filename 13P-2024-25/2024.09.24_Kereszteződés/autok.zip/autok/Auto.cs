﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace autok
{
	internal struct Car
	{
		public string Color { get; set; }
		public int Road { get; set; }
		public int Cycle { get; set; }

		public Car(string color, int road, int cycle)
		{
			Color = color;
			Road = road;
			Cycle = cycle;
		}
	}
}
