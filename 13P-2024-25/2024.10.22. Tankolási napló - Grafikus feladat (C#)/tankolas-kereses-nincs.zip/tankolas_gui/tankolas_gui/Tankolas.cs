﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tankolas_gui
{
    internal class Tankolas
    {
        private DateTime _date;
        private string _licensePlate;
        private int _km;
        private decimal _litres;
        private decimal _avgFuelConsumption;

        public Tankolas(DateTime date, string licensePlate, decimal km, decimal litres)
        {
            _date = date;
            _licensePlate = licensePlate;
            _km = (int)km;
            _litres = litres;
            _avgFuelConsumption = litres / (km / 100);
        }

        public void AddToDgv(DataGridView dgv)
        {
            dgv.Rows.Add(_date.ToShortDateString(), _licensePlate, _km, _litres, _avgFuelConsumption);
        }
    }
}
