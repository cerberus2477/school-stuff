﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace bingo
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//3. ...és tárolja a forrásállományokban kódolt játékosok neveit - nem tárolom most mert nincs szükségem rá, a fájl nevét tárolom
			List<BingoJatekos> jatekosok = new List<BingoJatekos>();
			foreach (string fnev in File.ReadLines("nevek.text").Select(n => n.Trim())) //TODO remove trailing "/n"
			{
				jatekosok.Add(new BingoJatekos(fnev));
			}


            //4
            Console.WriteLine($"4. feladat: Játékosok száma: {jatekosok.Count()}");

			//7
			Console.WriteLine($"7. feladat: A kihúzott számok: {jatekosok.Count()}");
		}
	}
}
