﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat01
{
	class Program
	{

		public static string[] names = new string[1000];
		public static int inputNum = -1;

		static void Main(string[] args) {

			while(inputNum != 5) {
				do {
					Console.Clear();
					Console.WriteLine("Név nyilvántartás\n(figyelem, a program maximum 1000 név nyilvántartására alkalmas)\n");
					Console.WriteLine("Válasszon az alábbi menüpontok közül! (a megfelelő szám beírásával)");
					Console.WriteLine("1) Új név rendezett beszúrása");
					Console.WriteLine("2) Név keresése");
					Console.WriteLine("3) Név törlése");
					Console.WriteLine("4) Összes név mutatása");
					Console.WriteLine("5) Kilépés");
				} while(!int.TryParse(Console.ReadLine(), out int inputNum) || inputNum < 1 || inputNum > 5);


				switch(inputNum) {
					case (1):
						Console.Clear();
						insert();
						break;
					case (2):
						search();
						break;
					case (3):
						delete();
						break;
					case (4):
						Console.Clear();
						Console.Title = "Összes név mutatása";
						showNames();
						break;
				}	
			}

			Environment.Exit(0);

		}

		static void insert() {
			Array.Sort(names);
		}

		static void search() {

		}


		static void delete() {

		}

		static void showNames() {
				foreach(var name in names) {
					Console.WriteLine(name);
				}
		}


	}
}
