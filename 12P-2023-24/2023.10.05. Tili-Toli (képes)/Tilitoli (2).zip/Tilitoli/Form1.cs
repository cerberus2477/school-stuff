﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tilitoli {
	public partial class Tilitoli : Form {
		public Tilitoli() {
			InitializeComponent();
		}

		static int maxSor = 3, maxOszlop = 3;

		static Button[,] gombok = new Button[maxOszlop, maxSor];
		static Random rnd = new Random();

		static int csere = 0;
		static int mp = 0;
		static int uresi = maxOszlop - 1;
		static int uresj = maxSor - 1;

		int btnHeight; int btnWidth;
		

		private void Form1_Load(object sender, EventArgs e) {

			//pnlCim.BackColor = Color.FromArgb(100, 100, 100, 100);
			//pnlGombok.BackColor = Color.FromArgb(100, 0, 0, 0);
			//pnlOldal.BackColor = Color.FromArgb(100, 0, 0, 0);
			int btnHeight = pnlGombok.Height / maxOszlop;
			int btnWidth = pnlGombok.Width / maxSor;

			generateBtns();
			cimkez();
			//Kever();

			Console.WriteLine($"uresi, uresj: {uresi}, {uresj}");
		}

		private void generateBtns() {

			maxOszlop = Convert.ToInt32(nmOszlop.Value);
			maxSor = Convert.ToInt32(nmSor.Value);


			gombok = new Button[maxOszlop, maxSor];
			btnHeight = this.pnlGombok.Height / maxOszlop;
			btnWidth = this.pnlGombok.Width / maxSor;
			for(int i = 0; i < maxSor; i++) {
				for(int j = 0; j < maxOszlop; j++) {
					gombok[i, j] = new Button();
					
					gombok[i, j].Size = new System.Drawing.Size(btnWidth, btnHeight);
					gombok[i, j].Location = new System.Drawing.Point(i * btnWidth, j * btnHeight);
					gombok[i, j].FlatStyle = FlatStyle.Flat;
					gombok[i, j].Enabled = true;
					gombok[i, j].BackgroundImageLayout = ImageLayout.Stretch;

					pnlGombok.Controls.Add(gombok[i, j]);
					gombok[i, j].Click += new EventHandler(this.Kattint);


					if(i == uresi && j == uresj) { //utolsó gomb, ez lesz az üres
						gombok[i, j].Visible = false;
						gombok[i, j].Name = "ures";
					} else {
						gombok[i, j].Visible = true;
						gombok[i, j].Name = Convert.ToString(j * maxOszlop + i + 1); //1től 8ig 3*3as pályán;
					}
				}
			}
		}

		/*private void Kever() {
			Byte szam;
			int k;
			List<Byte> elhasznaltSzamok = new List<Byte>();
			for(int i = 0; i < maxOszlop; i++) {
				for(int j = 0; j < maxSor; j++) {
					do {
						szam = Convert.ToByte(rnd.Next(maxOszlop * maxSor));
						k = elhasznaltSzamok.IndexOf(szam);
					} while(k != -1);
					elhasznaltSzamok.Add(szam);
					gombok[i, j].Text = Convert.ToString(szam);
					if(szam == 0) {
						gombok[i, j].Visible = false;
						lyukx = i;
						lyuky = j;
					} else gombok[i, j].Visible = true;
				}
			}
		}*/


		private bool Lyukszomszed(Button gomb) {
			Button ures = gombok[uresi, uresj];
			return ((gomb.Left == ures.Left) && (Math.Abs(gomb.Bottom - ures.Bottom) == gomb.Height)) || ((gomb.Top == ures.Top) && (Math.Abs(gomb.Left - ures.Left) == gomb.Width));
		}



		private void Kattint(object sender, EventArgs e) {

			bool cs = tryCsere(sender as Button);

			if(cs) {
				csere++;
				lblCsere.Text = $"Csere: {csere}";
				if(Nyerte()) {
					MessageBox.Show($"Gratulálok, nyertél!\nA kirakás {mp} másodperc és {csere} csere alatt sikerült.");
					for(int i = 0; i < maxSor; i++) {
						for(int j = 0; j < maxOszlop; j++) {
							gombok[i, j].Enabled = false;
						}
					}
				}
			}
		}


		private bool tryCsere(Button gomb) { 
			if(Lyukszomszed(gomb)) {
				Button seged = gomb;

				gomb.Left = gombok[uresi, uresj].Left;
				gombok[uresi, uresj].Left = seged.Left;

				gomb.Top = gombok[uresi, uresj].Top;
				gombok[uresi, uresj].Top = seged.Top;

				uresi = 

				Console.WriteLine($"ures: {uresi}, {uresj}");
				return true;
				
			}
			return false;
		}


		private bool Nyerte() {
			int i = 0;
			int j = 0;
			bool jo = true;
			while(jo && i < maxOszlop && j < maxSor) {
				if(gombok[i, j].Left == i * btnWidth && gombok[i, j].Left == j * btnHeight) {
					return false;
				}
			}
			return true;
		}

		

		private void Kever() { //biztosan kirakható, állítható nehézség az alapján hogy hányszor keverünk
			int csereCel = 10;
			var csereCount = 0;

			while(csereCel != csereCount) {
				int i = rnd.Next(maxOszlop);
				int j = rnd.Next(maxSor);

				Console.Write($"i, j: {i}, {j}");
				bool cs = tryCsere(gombok[i, j]);
				Console.WriteLine($"\tsikerült: {cs}");
				if(cs) {
					csereCount++;
				}
			}
		}



		private Image[,] kepDarabolas(Image bigImg) {
			Image[,] smallImgs = new Image[maxOszlop, maxSor];

			int smallWidth = (int)((double)bigImg.Width / maxOszlop);
			int smallHeight = (int)((double)bigImg.Height / maxSor);

			for(int i = 0; i < maxOszlop; i++) {
				for(int j = 0; j < maxSor; j++) {
					smallImgs[i, j] = new Bitmap(104, 104);
					Graphics g = Graphics.FromImage(smallImgs[i, j]);
					g.DrawImage(bigImg, new Rectangle(0, 0, smallWidth, smallHeight), new Rectangle(i * smallWidth, j * smallHeight, smallWidth, smallHeight), GraphicsUnit.Pixel);
					g.Dispose();
				}
			}

			return smallImgs;
		}


		private void btnKepes_Click(object sender, EventArgs e) {

			OpenFileDialog fileOpen = new OpenFileDialog();
			fileOpen.Title = "Válaszd ki a feltöltendő képet!";
			fileOpen.Filter = "JPG Files (*.jpg)| *.jpg";

			if(fileOpen.ShowDialog() == DialogResult.OK) {

				Image[,] smallImgs = kepDarabolas(Image.FromFile(fileOpen.FileName));

				for(int i = 0; i < maxOszlop; i++) {
					for(int j = 0; j < maxSor; j++) {
						gombok[i, j].BackgroundImage = smallImgs[i, j];
						gombok[i, j].Text = null;
					}
				}
			}
			fileOpen.Dispose();

			
		}

		

		private void btnSzamos_Click(object sender, EventArgs e) {

			cimkez();
		}

		private void cimkez() {
			for(int i = 0; i < maxOszlop; i++) {
				for(int j = 0; j < maxSor; j++) {
					gombok[i, j].Text = gombok[i, j].Name;
					gombok[i, j].ForeColor = Color.Black;
					gombok[i, j].Font = new Font(gombok[i, j].Font.Name, 30, FontStyle.Bold);
					gombok[i, j].BackColor = Color.White;
					
				}
			}
		}

		private void btnUj_Click(object sender, EventArgs e) {
			Kever();
			lblCsere.Text = "Csere: ";
			lblMp.Text = "Mp: ";
		}

		public int[] findIndex() {

		}

	}
}
