let leftest_index = 1; //első kis kép indexe (1-65)

const update_pic_small = (steps) => {

    if  (leftest_index + steps > 0 && leftest_index + 4 + steps < 70) { //határon belül
        
        //gombok kinézetének állítása
        if (leftest_index + steps == 1){
            document.getElementById("btn-prev").src = "./pics/prevdis.gif";
        }
        else if (leftest_index + 4 + steps == 69){
            document.getElementById("btn-next").src = "./pics/nextdis.gif";
        }
        else {
            document.getElementById("btn-prev").src = "./pics/prev.gif";
            document.getElementById("btn-next").src = "./pics/next.gif";
        }
    
        let smallpics = document.getElementsByClassName("pic-small");
        for (var i = 0; i < 5; i++){
            let index = leftest_index + i + steps;
            smallpics[i].src = "./pics/kiskepek/k_e_"+ index +".jpg";
            
        }
        leftest_index += steps;
    }
    
}

const update_pic_big = (imgnum, scroll=false) => {
    if (imgnum <= 69 && imgnum >= 1)
    {
        document.getElementById("pic-big").src = "./pics/nagykep/e_" + imgnum +".jpg";
     
        if (scroll){
            //elfáradtam sajnálom ezt a szépséges megoldást
            if (imgnum == 1 || imgnum == 2){
                update_pic_small(-leftest_index+1); //leftest_index 1 lesz
            }
            else if (imgnum == 69 || imgnum == 68){
                update_pic_small(69-leftest_index-4); //legjobboldalibb kép (leftest_index+4) 69 lesz
            }
            else{
                update_pic_small(imgnum-leftest_index);
            }
        }
    }     
}