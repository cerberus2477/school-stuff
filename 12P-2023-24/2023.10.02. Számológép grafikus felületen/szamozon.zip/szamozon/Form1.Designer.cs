﻿namespace szamozon
{
    partial class frmSzinozon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSzinozon));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRejt = new System.Windows.Forms.Button();
            this.btnUj = new System.Windows.Forms.Button();
            this.btnKever = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel2.Location = new System.Drawing.Point(12, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 600);
            this.panel2.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(166)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.panel4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel4.Location = new System.Drawing.Point(275, 68);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(50, 600);
            this.panel4.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel3.Location = new System.Drawing.Point(218, 68);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(50, 600);
            this.panel3.TabIndex = 0;
            // 
            // btnRejt
            // 
            this.btnRejt.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnRejt.Location = new System.Drawing.Point(220, 39);
            this.btnRejt.Name = "btnRejt";
            this.btnRejt.Size = new System.Drawing.Size(66, 23);
            this.btnRejt.TabIndex = 1;
            this.btnRejt.Text = "Mutat";
            this.btnRejt.UseVisualStyleBackColor = true;
            this.btnRejt.Click += new System.EventHandler(this.btnRejt_Click);
            // 
            // btnUj
            // 
            this.btnUj.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUj.Location = new System.Drawing.Point(292, 14);
            this.btnUj.Name = "btnUj";
            this.btnUj.Size = new System.Drawing.Size(34, 48);
            this.btnUj.TabIndex = 2;
            this.btnUj.Text = "Törlés";
            this.btnUj.UseVisualStyleBackColor = true;
            this.btnUj.Click += new System.EventHandler(this.btnUj_Click);
            // 
            // btnKever
            // 
            this.btnKever.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnKever.Location = new System.Drawing.Point(220, 14);
            this.btnKever.Name = "btnKever";
            this.btnKever.Size = new System.Drawing.Size(66, 23);
            this.btnKever.TabIndex = 3;
            this.btnKever.Text = "Kever";
            this.btnKever.UseVisualStyleBackColor = true;
            this.btnKever.Click += new System.EventHandler(this.btnKever_Click);
            // 
            // panel1
            // 
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 50);
            this.panel1.TabIndex = 1;
            // 
            // frmSzinozon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(334, 681);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnKever);
            this.Controls.Add(this.btnUj);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnRejt);
            this.Controls.Add(this.panel3);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "frmSzinozon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Színözön";
            this.Load += new System.EventHandler(this.Számözön_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnRejt;
        private System.Windows.Forms.Button btnUj;
        private System.Windows.Forms.Button btnKever;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
    }
}

