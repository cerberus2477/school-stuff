﻿using System;
using System.Collections.Generic;
using System.IO;
using autok;



class Program
{
	static void Main(string[] args)
	{
        display(orderCars(read("autok.txt")));
        Console.ReadLine();
	}

	static Queue<Car> read(string filename)
	{
		Queue<Car> cars = new Queue<Car>();
		string[] lines = File.ReadAllLines(filename);
		foreach(var line in lines)
		{
			string[] data = line.Split(',');
			string color = data[0];
			int road = int.Parse(data[1]);
			int cycle = int.Parse(data[2]);
			cars.Enqueue(new Car(color, road, cycle));
		}
		return cars;
	}

	static void display(Dictionary<Car, int> orderedCars)
	{
		foreach(var car in orderedCars)
		{
			Console.WriteLine($"{car.Value}. Ciklus : Az {car.Key.Road}. útról {car.Key.Color} autó haladt át.");
		}
	}

	static Dictionary<Car, int> orderCars(Queue<Car> cars)
	{
		Dictionary<Car, int> orderedCars = new Dictionary<Car, int>();

		//A kocsikat négy sorba rakjuk. Egy sor egy út.
		Queue<Car>[] roads = new Queue<Car>[4];
		for(int i = 0; i < 4; i++)
		{
			roads[i] = new Queue<Car>();
		}
		while(cars.Count > 0)
		{
			Car car = cars.Dequeue();
			roads[car.Road - 1].Enqueue(car);
		}

		//a kimeneti ciklus. ha egyszerre két kocsi elmegy nem növeljük, csak ha egymás után
		int currentOutCycle = 1;

		// Ciklusok alapján az autók áthaladási sorrendjének meghatározása
		while(isMoreCar(roads))
		{
			for(int i = 0; i < 4; i++)
			{
				if(roads[i].Count > 0)
				{
					Car currentCar = roads[i].Peek();

					// Ellenőrizzük a jobbkézszabályt
					if(JobbkezSzabaly(roads, i))
					{
						orderedCars.Add(roads[i].Dequeue(), currentOutCycle);
						//leellenőrizzük a szemben lévő utat
						int oppositeI = (i + 2) % 4;
						if (JobbkezSzabaly(roads, oppositeI))
						{
							orderedCars.Add(roads[oppositeI].Dequeue(), currentOutCycle);
						}

						currentOutCycle++;
					}
				}
			}
		}

		return orderedCars;
	}

	// Ellenőrzi a jobbkézszabályt
	static bool JobbkezSzabaly(Queue<Car>[] roads, int currentRoad)
	{
		// Az aktuális úthoz képest a jobb oldali utak ellenőrzése
		for(int i = 1; i <= 3; i++)
		{
			int roadToRight = (currentRoad + i) % 4;
			if(roads[roadToRight].Count > 0 && roads[roadToRight].Peek().Cycle < roads[currentRoad].Peek().Cycle)
			{
				return false;
			}
		}
		return true;
	}

	// Ellenőrzi, hogy van-e még autó valamelyik úton
	static bool isMoreCar(Queue<Car>[] utak)
	{
		foreach(var ut in utak)
		{
			if(ut.Count > 0)
			{
				return true;
			}
		}
		return false;
	}
}
