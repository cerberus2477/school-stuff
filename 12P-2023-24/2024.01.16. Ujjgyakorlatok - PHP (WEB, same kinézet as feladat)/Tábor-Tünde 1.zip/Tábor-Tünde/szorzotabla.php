<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2) Szorzótábla</title>

    <style>
    table {
        margin: 0 auto 0 auto;
        border-spacing: 0px;
        box-shadow: 7px 7px 15px #068506;
        background-color: #088708;
        border: 1px solid darkgreen;
        border-radius: 7px;
        padding: 2px;
    }

    td,
    th {
        border: 2px solid #088708;
        border-radius: 7px;
        background: #CCFFCC;
        padding: .2rem .2rem .2rem 1rem;
        text-align: right;
    }

    th {
        font-weight: bold;
        background: #44CC44;
    }
    </style>
</head>

<body>
    <h2>2) Szorzótábla</h2>
    <h6>a linkben ?m=ertek -kel változtatható a méret</h6>

    <?php
    $m = 10;
    $m =  isset($_GET["m"]) ? (int)$_GET["m"] : 10;
    echo "<table>";

    //elso sor

    echo "<tr><th></th>";
    for ($j = 1; $j <= $m; $j++) {
        echo "<th>$j</th>";
    }
    echo "</tr>";

    for ($i = 1; $i <= $m; $i++) {
        echo "<tr>";
        echo "<th>$i</th>"; //számok
        for ($j = 1; $j <= $m; $j++) {
            echo "<td>" . $i * $j . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";


    ?>

</body>

</html>