﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace _03._22_lotto {
    class Program {

        static List<List<int>> lotto = new List<List<int>>();


        static void readFile() {
            List<string> lstring = File.ReadAllLines("lottosz.dat").ToList(); // {"1 2 3 4 5", "3, 4, 5, 6, 7", ...}
            foreach(var l in lstring) {
                lotto.Add(Array.ConvertAll(l.Split(' '), int.Parse).ToList());
            }
        }

        static string toString(List<int> list1, bool split){
            string str = "";
            if(list1.Count() == 0) return "Nincs ilyen szám";

            for(int i = 0; i < list1.Count; i++) {
                str += $"{list1[i]} ";
                if(split && (i+1) % 15 == 0) {
                    str += "\n";
                }
            }
        
            return str.Substring(0, str.Length - 1);
        }

        static void Main(string[] args) {
            readFile();

            //1
            Console.Write("Adja meg az 52. hét lottószámait: ");
            List<int> l52 = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse).ToList();

            //2
            l52.Sort();
            Console.WriteLine($"Az 52. hét számai emelkedő sorrendben: {toString(l52, false)}");

            //3-4
            Console.Write("Adjon meg egy egész számot 1 és 51 között: ");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine($"A {num}. hét számai: {toString(lotto[num - 1], false)}");

            //5
            int x = 1;
            bool contains = true;
            while(x <= 90 && contains) {
                lotto.ForEach(w => contains = w.Contains(x));
                x++;
            }
            string text;
            text = x < 91 ? "Van" : "Nincs";
            Console.WriteLine($"{text} olyan szám ami nem szerepelt az 51 hét alatt.");


            //6 hány páratlan
            int oddCount = 0; //51 hét alatt kéne!
            lotto.ForEach(w => oddCount += w.Count(y => y % 2 == 1));
            Console.WriteLine($"{oddCount}db páratlan szám van.");

            //7
            lotto.Add(l52);
            using(StreamWriter sw = new StreamWriter("lotto52.ki")) {
                foreach(var week in lotto) {
                    sw.WriteLine(toString(week, false));
                }
            }

            //8
            List<int> countByNum = new List<int>();
            for(int i = 1; i <= 90; i++) {
                int temp = 0;
                lotto.ForEach(w => temp += w.Count(n => n == i));
                countByNum.Add(temp);
            }
            Console.WriteLine(toString(countByNum, true));

            //9
            List<int> primes = new List<int>{2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89};
            List<int> notInLotto = new List<int>();

            foreach(int p in primes) {
                if(lotto.Select(w => w.Contains(p)).Count() == 0) notInLotto.Add(p);

            }

            Console.WriteLine($"Nem kihúzott prímszámok: {toString(notInLotto, false)}");
        }
    }
}
