﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.IO;

namespace Helsinki_2017
{
    class Statisztika
    {
        private static MySqlConnection conn = new MySqlConnection("Server=localhost; Database=mukorcsolya;  user=root; ");


        //3. Vegye fel, a program segítségével, Egyiptomot az orszagok táblába (Egyiptom, EGY)
        public void addEgyiptom()
        {
            try
            {
                conn.Open();
                new MySqlCommand("INSERT INTO orszagok VALUES('EGY', 'Egyiptom'); ", conn).ExecuteNonQuery();
            }
            catch (Exception e) //ha már van ilyen sor
            {
                MessageBox.Show($"{e.Message}\n(Valószínűleg már szerepel a táblában Egyiptom.)", "SQL hiba - Egyiptom hozzáadása az országok táblához", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open) { conn.Close(); }
            }
        }

        //4. Határozza meg és írja ki a képernyőre (formra) a rövidprogramban elindult versenyzők számát!
        public int countRovidprogram()
        {
            conn.Open();
            int r = Convert.ToInt32(new MySqlCommand("SELECT COUNT(*) FROM rovidprogram;", conn).ExecuteScalar());
            conn.Close();
            return r;
        }


        //5. Írja ki a képernyőre, hogy a magyar versenyző bejutott-e a kűrbe, és ha igen hogy hívják, mennyi volt a pontja!
        //magyarország el van írva az adatbázisban
        /*public List<string> magyar()
        {
            List<string> result = new List<string>();

            try
            {
                conn.Open();
                string cmdstr = "SELECT Név, Technikai + Komponens - Levonás AS Pontszám" +
                    "FROM donto INNER JOIN orszagok ON orszagok.OrszagID = donto.Ország" +
                    "WHERE orszagok.OrszagNev = 'Magyaqrország'; ";
                MySqlDataReader r = new MySqlCommand(cmdstr, conn).ExecuteReader();

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "SQL hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            if (conn.State == System.Data.ConnectionState.Open) { conn.Close(); }
            return result;
        }*/


        

        //7
        public bool validNev(string nev)
        {
            conn.Open();
            bool v = new MySqlCommand($"SELECT * FROM rovidprogram WHERE Név = '{nev}'; ", conn).ExecuteScalar() != null;
            conn.Close();
            return v;
        }

        //8
        public double ÖsszPontszám(string nev)
        {

            conn.Open();
            double pontszam = Convert.ToDouble(new MySqlCommand($"SELECT Technikai + Komponens - Levonás AS rovid FROM rovidprogram WHERE Név = '{nev}'; ", conn).ExecuteScalar());
            try
            {
                pontszam += Convert.ToDouble(new MySqlCommand($"SELECT Technikai + Komponens - Levonás AS donto FROM donto WHERE Név = '{nev}'; ", conn).ExecuteScalar());
                conn.Close();
                return pontszam;
            }
            catch (Exception) //ha nemjutott tovább null a második lekédezés ereménye, így errort kapunk, majd visszaküldjük csak az első pontszámot
            {
                conn.Close();
                return pontszam;
            }
        }


        //9.	Készítsen összesítést arról, hogy országonként hány versenyző jutott tovább a rövidprogram bemutatása után! Írja a ki a képernyőre azon országok kódját, nevét és a versenyzők számát, amelyek esetében egynél több versenyző jutott tovább!
        public string orszagonkent()
        {
            throw new NotImplementedException();
        }


        //10
        /* 	vegeredmeny
         * 	Helyezés (int(11))
 	        Versenyző neve (varchar(60))
 	        Ország (varchar(3))
 	        Országnév(varchar(60))
 	        Összpontszám (int(11))
            A táblában (állományban) a versenyzők a helyezésük szerint legyenek sorba rendezve!
        */

        public void vegeredmeny()
        {
            throw new NotImplementedException();
        }

    }
}
