﻿namespace sudoku
{
    partial class frmSudoku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmenu = new System.Windows.Forms.MenuStrip();
            this.újJátékToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.könnyűToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normálToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nehézToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extraNehézToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.táblaMéreteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlGame = new System.Windows.Forms.Panel();
            this.statisztikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSudoku = new System.Windows.Forms.Panel();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.mainmenu.SuspendLayout();
            this.pnlSudoku.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainmenu
            // 
            this.mainmenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újJátékToolStripMenuItem,
            this.táblaMéreteToolStripMenuItem,
            this.statisztikaToolStripMenuItem});
            this.mainmenu.Location = new System.Drawing.Point(0, 0);
            this.mainmenu.Name = "mainmenu";
            this.mainmenu.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.mainmenu.Size = new System.Drawing.Size(532, 25);
            this.mainmenu.TabIndex = 0;
            this.mainmenu.Text = "menuStrip1";
            // 
            // újJátékToolStripMenuItem
            // 
            this.újJátékToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.könnyűToolStripMenuItem,
            this.normálToolStripMenuItem,
            this.nehézToolStripMenuItem,
            this.extraNehézToolStripMenuItem});
            this.újJátékToolStripMenuItem.Enabled = false;
            this.újJátékToolStripMenuItem.Name = "újJátékToolStripMenuItem";
            this.újJátékToolStripMenuItem.Size = new System.Drawing.Size(70, 19);
            this.újJátékToolStripMenuItem.Text = "Nehézség";
            // 
            // könnyűToolStripMenuItem
            // 
            this.könnyűToolStripMenuItem.Name = "könnyűToolStripMenuItem";
            this.könnyűToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.könnyűToolStripMenuItem.Text = "Könnyű";
            this.könnyűToolStripMenuItem.Click += new System.EventHandler(this.könnyűToolStripMenuItem_Click);
            // 
            // normálToolStripMenuItem
            // 
            this.normálToolStripMenuItem.Name = "normálToolStripMenuItem";
            this.normálToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.normálToolStripMenuItem.Text = "Normál";
            // 
            // nehézToolStripMenuItem
            // 
            this.nehézToolStripMenuItem.Name = "nehézToolStripMenuItem";
            this.nehézToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nehézToolStripMenuItem.Text = "Nehéz";
            // 
            // extraNehézToolStripMenuItem
            // 
            this.extraNehézToolStripMenuItem.Name = "extraNehézToolStripMenuItem";
            this.extraNehézToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.extraNehézToolStripMenuItem.Text = "Extrém";
            // 
            // táblaMéreteToolStripMenuItem
            // 
            this.táblaMéreteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.x3ToolStripMenuItem});
            this.táblaMéreteToolStripMenuItem.Name = "táblaMéreteToolStripMenuItem";
            this.táblaMéreteToolStripMenuItem.Size = new System.Drawing.Size(86, 19);
            this.táblaMéreteToolStripMenuItem.Text = "Tábla mérete";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem2.Text = "2X2";
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.x3ToolStripMenuItem.Text = "3X3";
            // 
            // pnlGame
            // 
            this.pnlGame.Location = new System.Drawing.Point(20, 34);
            this.pnlGame.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlGame.Name = "pnlGame";
            this.pnlGame.Size = new System.Drawing.Size(400, 400);
            this.pnlGame.TabIndex = 1;
            // 
            // statisztikaToolStripMenuItem
            // 
            this.statisztikaToolStripMenuItem.Name = "statisztikaToolStripMenuItem";
            this.statisztikaToolStripMenuItem.Size = new System.Drawing.Size(71, 19);
            this.statisztikaToolStripMenuItem.Text = "Statisztika";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(34, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 44);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sudoku";
            // 
            // pnlSudoku
            // 
            this.pnlSudoku.Controls.Add(this.pnlGame);
            this.pnlSudoku.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSudoku.Location = new System.Drawing.Point(0, 140);
            this.pnlSudoku.Name = "pnlSudoku";
            this.pnlSudoku.Size = new System.Drawing.Size(532, 453);
            this.pnlSudoku.TabIndex = 0;
            // 
            // pnlTitle
            // 
            this.pnlTitle.Controls.Add(this.label1);
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitle.Location = new System.Drawing.Point(0, 25);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(532, 99);
            this.pnlTitle.TabIndex = 3;
            // 
            // frmSudoku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 593);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.pnlSudoku);
            this.Controls.Add(this.mainmenu);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainMenuStrip = this.mainmenu;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmSudoku";
            this.Text = "Sudoku";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.mainmenu.ResumeLayout(false);
            this.mainmenu.PerformLayout();
            this.pnlSudoku.ResumeLayout(false);
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainmenu;
        private System.Windows.Forms.ToolStripMenuItem újJátékToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem könnyűToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normálToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nehézToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extraNehézToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem táblaMéreteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.Panel pnlGame;
        private System.Windows.Forms.ToolStripMenuItem statisztikaToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlSudoku;
        private System.Windows.Forms.Panel pnlTitle;
    }
}

