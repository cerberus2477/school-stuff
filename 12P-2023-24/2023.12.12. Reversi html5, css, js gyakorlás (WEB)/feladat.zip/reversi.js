var nrow = 8;
var ncell = 8;
var tt = new Array(nrow);
var newrow;
var player = 0;

function init() {
    for (var i = 0; i < nrow; i++) {
        newrow = document.getElementById("palya").insertRow(i);
        tt[i] = new Array(ncell);
        for (var j = 0; j < ncell; j++) {
            tt[i][j] = newrow.insertCell(j);
            tt[i][j].id = i * ncell + j;
            tt[i][j].onclick = function() {
                newstep(this);
            };
            tt[i][j].style.width = "50px";
            tt[i][j].style.height = "50px";
            tt[i][j].style.color = "#fcfcfc";
            tt[i][j].style.background = "#ff3333";
            tt[i][j].innerHTML = " ";
        }
    }
    reset();
}


function newstep(obj) {
    var row = parseInt(obj.id / ncell);
    var column = obj.id % nrow;
    var symbol = document.getElementById(obj.id).innerHTML;
    if ((symbol == " ") && (player == 1)) {
        document.getElementById(obj.id).innerHTML = "O";
        player = 0;
        flipSymbols(row, column, "O");
    } else if ((symbol == " ") && (player == 0)) {
        document.getElementById(obj.id).innerHTML = "X";
        player = 1;
        flipSymbols(row, column, "X");
    }
    checkend(obj);
}

function reset() {
    nrow = 8;
    ncell = 8;
    player = 0;

    for (var i = 0; i < nrow; i++) {
        for (var j = 0; j < ncell; j++) {
            tt[i][j].innerHTML = " ";
            tt[i][j].onclick = function() {
                newstep(this);
            };
        }
    }
    tt[nrow / 2 - 1][ncell / 2 - 1].innerHTML = "X";
    tt[nrow / 2][ncell / 2].innerHTML = "X";
    tt[nrow / 2 - 1][ncell / 2].innerHTML = "O";
    tt[nrow / 2][ncell / 2 - 1].innerHTML = "O";
}

function flipSymbols(row, column, symbol) {
    var i, j;
    i = row - 1;
    var othersymbol;
    if (symbol == "O") othersymbol = "X";
    else othersymbol = "O";
    // ellenőrzés felfelé
    while (i >= 0 && tt[i][column].innerHTML == othersymbol) i--;
    if (i >= 0 && tt[i][column].innerHTML == symbol) {
        for (j = i + 1; j < row; j++)
            tt[j][column].innerHTML = symbol;
    }
    // ellenőrzés lefelé
    i = row + 1;
    while (i < nrow && tt[i][column].innerHTML == othersymbol) i++;
    if (i < nrow && tt[i][column].innerHTML == symbol) {
        for (j = row; j < i; j++)
            tt[j][column].innerHTML = symbol;
    }
}


function checkend(obj) {
    var cnt_all = 0;
    var i, j;
    for (i = 0; i < nrow; i++) {
        for (j = 0; j < ncell; j++) {
            if (tt[i][j].innerHTML != " ") cnt_all++;
        }
    }
    if (cnt_all == nrow * ncell) {
        var res = window.confirm("A játék véget ért");
        if (res == true) {
            reset();
        } else //megmarad az állás, de sehova nem lehet kattintani
        {
            for (var i = 0; i < nrow; i++) {
                for (var j = 0; j < ncell; j++) {
                    tt[i][j].onclick = false;
                }
            }
        }
    }
}