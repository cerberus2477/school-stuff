﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace programozasi_tetelek
{
	internal struct Szinek
	{
		public static Color narancs = Color.FromArgb(226, 114, 34);

		public static Color piros = Color.FromArgb(227, 69, 23);
		public static Color rozsaszin= Color.FromArgb(225, 71, 112);
		public static Color kek = Color.FromArgb(69, 156, 227);
		public static Color turkiz = Color.FromArgb(57, 227, 146);
		public static Color zold= Color.FromArgb(111, 227, 49);
		public static Color sárga = Color.FromArgb(226, 223, 44);

		public static Color hatterSotet = Color.FromArgb(16, 20, 36);
		public static Color hatterVilagos = Color.FromArgb(23, 27, 46);

		public static Color szoveg = Color.FromArgb(255, 249, 245);
	}
}