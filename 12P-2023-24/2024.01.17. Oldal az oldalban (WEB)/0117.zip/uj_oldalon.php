<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HTML kód futtatása</title>
</head>
<body>
    <h2>HTML kód futtatása</h2>
    <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
        <label for="content">Futtatni kívánt HTML kód:</label><br>
        <textarea name="content" id="content" cols="150" rows="20"></textarea><br>
        <input type="submit" value="OK">
    </form>
    <hr>
    <h2>Eredmény:</h2>

    <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            echo '<iframe width="100%" height="400px" style="border:1px solid black;" srcdoc="' . $_POST['content'] . '"></iframe>';
        }
    ?>
         
</body>
</html>