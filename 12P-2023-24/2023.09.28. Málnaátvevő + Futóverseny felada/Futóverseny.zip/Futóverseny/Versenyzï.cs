﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Futóverseny
{
    class Versenyző
    {
        private string név, egyesület;
        private int rajtszám, időmp, indóra = 0, indperc = 0, indmp = 0, érkóra = 0, érkperc = 0, érkmp = 0;


        public Versenyző(string neve, string egyesülete, int rajtszáma)
        {
            név = neve; egyesület = egyesülete; rajtszám = rajtszáma;
        }

        public void indulásibe(int ó, int p, int mp)
        {
            indóra = ó; indperc = p; indmp = mp;
        }

        public void érkezésibe(int ó, int p, int mp)
        {
            érkóra = ó; érkperc = p; érkmp = mp;
            időmp = (érkóra * 3600 + érkperc * 60 + érkmp) - (indóra * 3600 + indperc * 60 + indmp);
        }

        public bool névhasonlít(string mnév)
        {
            return név.CompareTo(mnév) == 0;
        }

        public bool számhasonlít(int szám)
        {
            return rajtszám == szám;
        }

        public int CompareTo(Versenyző valaki)
        {
            int vissza;

            if (időmp != 0 && időmp < valaki.időmp) vissza = 1;
            else if (időmp > valaki.időmp && valaki.időmp != 0) vissza = -1;
            else if (időmp == 0 && időmp < valaki.időmp) vissza = -1;
            else if (időmp > valaki.időmp && valaki.időmp == 0) vissza = 1;
            else if (név.CompareTo(valaki.név) == 1) vissza = -1;
            else if (név.CompareTo(valaki.név) == -1) vissza = 1;
            else vissza = 0;
            return vissza;
        }

        public override string ToString()
        {
            string eredmény = "";
            int óra = időmp / 3600;
            int perc = időmp % 3600 / 60;
            int mp = időmp % 3600 % 60;
            eredmény = Convert.ToString(óra) + ":" + Convert.ToString(perc) + ":" + Convert.ToString(mp);
            return rajtszám + " " + név + " " + eredmény;
        }

        public bool résztvett()
        {
            return időmp != 0;
        }
    }
}
