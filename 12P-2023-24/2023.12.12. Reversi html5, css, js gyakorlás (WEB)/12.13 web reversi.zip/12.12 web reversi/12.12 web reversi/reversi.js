var nrow = 8;
var ncell = 8;
var tt = new Array(nrow);
var newrow;
let playerX;

let scoreX;
let scoreO;


function init() {
    for (var i = 0; i < nrow; i++) {
        newrow = document.getElementById("palya").insertRow(i);
        tt[i] = new Array(ncell);
        for (var j = 0; j < ncell; j++) {
            tt[i][j] = newrow.insertCell(j);
            tt[i][j].innerHTML = "";
           }
    }
    reset();
}

function reset() {
    playerX = true;
    scoreX = 0;
    scoreO = 0;

    for (var i = 0; i < nrow; i++) {
        for (var j = 0; j < ncell; j++) {
            tt[i][j].id = i * ncell + j;
            //tt[i][j].innerText = " ";
            tt[i][j].onclick = function ()
                { 
                    cell_click(this); 
                }
        }
    }

    tt[nrow / 2 - 1][ncell / 2 - 1].innerText = "X";
    tt[nrow / 2][ncell / 2].innerText = "X";
    tt[nrow / 2 - 1][ncell / 2].innerText = "O";
    tt[nrow / 2][ncell / 2 - 1].innerText = "O";

    whose_turn();
}



//kijelőli a lehetséges mezőket, eldönti ki jön vagy vége van-e
function whose_turn(){
    Array.from(document.querySelectorAll('.valid')).forEach(
        (cell) => cell.classList.remove('valid')
      );

    let valid_count = 0;

    //következő játékossal ellenőrzés
    symbol = playerX ? "X" : "O";
    for (let x = 0; x < nrow; x++) {
        for (let y = 0; y < ncell; y++) {
            if (check_step(x, y, symbol)) {
                valid_count++;
            }
        }
    }

    //ha nem talált megoldást, megnézi hogy az előző játékos tud e lépni (ilyenkor kimaradna a soron levő)
    if (valid_count == 0) {
        playerX = !playerX;
        symbol = playerX ? "X" : "O";

        for (let x = 0; x < nrow; x++) {
            for (let y = 0; y < ncell; y++) {
                if (check_step(x, y, symbol)) {
                    valid_count++;
                }
            }
        }
    }

    //ha egyik játékos sem tud lépni, vége a játéknak
    if (valid_count == 0) {
        let res = window.confirm("A játék véget ért");
        if (res) {
            reset();
        }
    }

    document.getElementById("next-turn").innerText = `${playerX ? "X" : "O"} jön`;
    
}

function cell_click(obj) {
    if(obj.classList.contains("valid")){
        //symbol = playerX ? "X" : "O";
        o = !playerX;
        let row = parseInt(obj.id / ncell);
        let column = obj.id % nrow;
        check_step(row, column, o, true);

        playerX = !playerX;
 
                

        scoreX= document.querySelectorAll('.x').length;
        scoreO = document.querySelectorAll('.o').length;

        document.getElementById("score").innerHTML = `X pontszáma: ${scoreX}<br>O pontszáma: ${scoreO}`;

    }

    whose_turn();
}





//leellenőrzi hogy lehetséges-e a lépés, ha do_flip akkor lép is
function check_step(row, column, isX, do_flip=false) {
    let i, j, k, steps; 
    let isO = !isX;
    //nem üres mező esetén kilépés
    if (tt[row][column].innerHTML != "") {
        return false;
    }

    // ellenőrzés felfelé
    i = row - 1; 
    
    while (i >= 0 && tt[i][column].classList.contains("x") == isO) i--;
    if (i != row-1 && i >= 0 && tt[i][column].classList.contains("x") == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (j = i + 1; j < row; j++)
        {
            tt[j][column].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[j][column].classList.toggle("o");
            tt[j][column].classList.toggle("x");
        }
    }
    // ellenőrzés lefelé
    i = row + 1;
    while (i < nrow && tt[i][column].innerText == isO) i++;
    if (i != row+1 && i < nrow && tt[i][column].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (j = row; j < i; j++)
            //tt[j][column].innerText = symbol;
            tt[j][column].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[j][column].classList.toggle("o");
            tt[j][column].classList.toggle("x");
    }

    // ellenőrzés balra
    j = column - 1;
    while (j >= 0 && tt[row][j].innerText == isO) j--;
    if (j != column-1 &&  j >= 0 && tt[row][j].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (k = j + 1; k < column; k++)
            //tt[row][k].innerText = symbol;
            tt[row][k].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row][k].classList.toggle("o");
            tt[row][k].classList.toggle("x");
    }
    // ellenőrzés jobbra
    j = column + 1;
    while (j < ncell && tt[row][j].innerText == isO) j++;
    if (j != column + 1 &&  j < ncell && tt[row][j].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (k = column; k < j; k++)
            //tt[row][k].innerText = symbol;
            tt[row][k].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row][k].classList.toggle("o");
            tt[row][k].classList.toggle("x");
    }
    



    // ellenőrzés balra fel
    steps = 1;

    while (row-steps >= 0 && column-steps>=0 && tt[row-steps][column-steps].innerText == isO) steps++;
    if (steps>1 && row-steps >= 0 && column-steps >= 0 && tt[row-steps][column-steps].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            //tt[row-a][column-a].innerText = symbol;  
            tt[row-a][column-a].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row-a][column-a].classList.toggle("o");
            tt[row-a][column-a].classList.toggle("x");
    }

    // ellenőrzés balra le
    steps = 1;
    while (row+steps < nrow && column-steps>=0 && tt[row+steps][column-steps].innerText == isO) steps++;
    if (steps>1 && row+steps < nrow && column-steps >= 0 && tt[row+steps][column-steps].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            //tt[row+a][column-a].innerText = symbol;  
            tt[row+a][column-a].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row+a][column-a].classList.toggle("o");
            tt[row+a][column-a].classList.toggle("x");
    }

    // ellenőrzés jobbra fel
    steps = 1;
    //while (row-steps >= nrow && column-steps>=0 && tt[row+steps][column-steps].innerText == othersymbol) steps++;
    while (row-steps >= 0 && column+steps < ncell && tt[row+steps][column-steps].innerText == isO) steps++;
    if (steps>1 && row-steps >= 0 && column+steps < ncell && tt[row+steps][column-steps].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            //tt[row+a][column-a].innerText = symbol;  
            tt[row-a][column+a].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row-a][column+a].classList.toggle("o");
            tt[row-a][column+a].classList.toggle("x");
    }

    // ellenőrzés jobbra le
    steps = 1;
    while (row+steps < nrow && column+steps < ncell && tt[row+steps][column+steps].innerText == isO) steps++;
    if (steps>1 && row+steps < nrow && column+steps < ncell && tt[row+steps][column+steps].innerText == isX) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            //tt[row+a][column+a].innerText = symbol;  
            tt[row+a][column+a].innerHTML = "<div class='td-inner'><div class='coin-x'>X</div><div class='coin-o'>O</div></div>";
            tt[row+a][column+a].classList.toggle("o");
            tt[row+a][column+a].classList.toggle("x");
    }


    //a nyolc irányból egyik sem jó tehát nem valid lépés ez a cella
    if (!do_flip) return false;
}