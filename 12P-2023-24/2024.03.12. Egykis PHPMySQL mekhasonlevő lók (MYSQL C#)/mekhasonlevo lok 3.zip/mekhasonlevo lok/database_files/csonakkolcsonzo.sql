-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Már 13. 09:06
-- Kiszolgáló verziója: 10.4.28-MariaDB-log
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `csonakkolcsonzo`
--
CREATE DATABASE IF NOT EXISTS `csonakkolcsonzo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_hungarian_ci;
USE `csonakkolcsonzo`;



CREATE TABLE IF NOT EXISTS `hajok` (
  `azonosito` int(2) NOT NULL AUTO_INCREMENT,
  `nev` varchar(25) DEFAULT NULL,
  `tipus` varchar(18) DEFAULT NULL,
  `kep` varchar(37) DEFAULT NULL,
  `fo` int(1) DEFAULT NULL,
  `kölcsönzesi_ar` int(5) DEFAULT NULL,
  `leiras` varchar(1533) DEFAULT NULL,
  `kep_neve` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`azonosito`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



INSERT IGNORE INTO `hajok` (`azonosito`, `nev`, `tipus`, `kep`, `fo`, `kölcsönzesi_ar`, `leiras`, `kep_neve`) VALUES
(1, 'Hófehérke', 'krokodil kajak', 'Krokodil-kajak-2-1024x576-1.jpg', 1, 3700, 'Ez a kajak egy végtelenül stabil, szinte fölboríthatatlan eszköz.\nElsősorban a Balaton-parti kölcsönzők közkedvelt kajakja. Formája miatt a gyerekek kedvence, de felnőttek is örömmel használják.\nRövidebb partközeli túrákra alkalmas. Könnyen irányítható, fordulékony.\nA teljesen zárt kiképzésnek köszönhetően akkor sem folyik bele víz, ha a hátára fordítják.', ''),
(2, 'Szende', 'túrakajak', 'turakajak-tk-01.jpg', 1, 3900, 'A kajakok a magányosan, vagy párosan evezők eszközei. Nagyobb sebességgel lehet velük haladni, mint a túrakenukkal, de ennek az az ára, hogy evezés közben kötöttebben ül a kajakozó mint a kenus.\nElsősorban folyókra és tavakra alkalmas vízitúra eszköz.\nNagy beülőnyílása, jó ülése hosszú távú evezés esetén is kényelmes utazást biztosít.\nA lábaknak többfokozatú merev lábtámasz van kiképezve. A kajakban hátul van a légkamra, mely vízmentes deklikarikával van ellátva és ide pakolható némi útipoggyász, de emellett és elől is hatalmas hely van a túrázáshoz szükséges holmik részére.\nA stabilitásuk kezdők számára is kielégítő. Nincs benne kormányszerkezet, de a hajó egyenes futását a héj végén kiképzett szkeg segíti elő.\nA kajak anyaga üvegszálas poliészter, tetszőleges színekben rendelhető.', ''),
(3, 'Szundi', 'túrakajak', 'turakajak-2-szemelyes-01.jpg', 2, 7400, 'A kajakok a magányos, vagy párosan evezők eszközei. Nagyobb sebességgel lehet velük haladni, mint a túrakenukkal, ennek viszont meg van az az ára, hogy evezés közben a kajakozó kötöttebben ül kenus társainál.\nElsősorban folyókra és tavakra alkalmas vízitúra eszköz. Nagy beülőnyílása, jó ülése hosszú távú evezés esetén is kényelmes utazást biztosít.\nA TK-02 kajak egy nagyon jó, stabil és a méreteihez képest igen gyors kajak. A kajakos még föl is állhat a kajakban, nem borul föl. Mindezt persze a vízen, nemcsak a parton.\nEz a kajak kormányszerkezettel készül.\nA hátul ülő kormányoz, az első utas számára fix lábtámasz van kiképezve. A kormány nagy segítséget jelent a pontos iránytartásban még akkor is, ha a két kajakos nincs teljesen összeszokva.\nEbben a kajakban elől és hátul is légkamrát helyeztünk el, ami megakadályozza a kajak elsüllyedését borulás esetén.\nA hátsó légkamra felül vízmentes nyílással van ellátva, így a szárazon tartandó tárgyainkat – telefon, iratok, slusszkulcs stb. – be lehet ide pakolni.\nAnyaga üvegszálas poliészter, tetszőleges színekben rendelhető.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület színezett védőréteggel van ellátva, ami segíti a hajó belsejének tisztán tartását. Érdemes megjegyezni, hogy könnyedén szállítható személygépkocsi tetején is.\nA TC-02 kenu elsősorban fiatal pároknak, vagy egyedül túrázóknak ajánlott.\nJól alkalmazható túravezetőknek is, akik gyorsan kell, hogy megközelítsék a vízen haladó konvoj mindkét végét.', ''),
(4, 'Kuka', 'tengeri kajak', 'tengeri-kajak-vadonatuj-5.jpg', 1, 3500, 'A kajakok a magányos, vagy párosan evezők eszközei. Nagyobb sebességgel lehet velük haladni, mint a túrakenukkal, de ennek az az ára, hogy evezés közben kötöttebben ül a kajakozó mint a kenus.\nA TT-01 kajak folyókra, tavakra és tengerre is alkalmas vízitúra eszköz.\nNagy méretű tároló-rekeszei elől egy, hátul kettő darab vízmentes zárófedéllel vannak ellátva, így hosszabb túrára is elegendő hely van bennük a felszerelésnek.\nHosszú vízvonala és tökéletes kialakítása miatt kis energia-befektetéssel nagy sebességgel haladhatunk.\nAz iránytartása kiváló. Alapkivitelben nincs benne kormányszerkezet, de az éles fenékkialakítás miatt nem is érezzük a hiányát. Igény szerint, el tudjuk látni kormánnyal ezt a kajakot is.\nA felhúzott orr és farkiképzés a nagyobb hullámokon való áthaladásnál nyújt segítséget. Ez a kajak is szállítható gépkocsi tetején.\nA kajak anyaga üvegszálas poliészter, ami UV álló és nagy rugalmasságú alapanyag. A kajak tetszőleges színben rendelhető.', ''),
(5, 'Morgó', 'túrakenu', 'turakenu-tc-02.jpg', 2, 7000, 'A kenuk a legelterjedtebb vízitúra eszközök. Futásuk és belső tágasságuk miatt váltak közkedveltté. A nagyon vad hegyi vizeket kivéve szinte mindenhol használhatóak.\nA jó minőségű gél-coat anyagoknak és a nagy szilárdságú műgyantáknak köszönhetően az ütéseknek is ellenállnak. Légkamrákat helyeztünk el a kenuk mindkét végébe, ami megakadályozza az elsüllyedését borulás esetén.\nAz ülések ívelt kiképzésűek, így hosszabb túra után sem törnek. Minden ülés csavarozva van, így bármikor kiszerelhetőek, a kenu utastere átvariálható.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület színezett védőréteggel van ellátva, ami segíti a hajó belsejének tisztán tartását. Érdemes megjegyezni, hogy könnyedén szállítható személygépkocsi tetején is.\nA TC-02 kenu elsősorban fiatal pároknak, vagy egyedül túrázóknak ajánlott.\nJól alkalmazható túravezetőknek is, akik gyorsan kell, hogy megközelítsék a vízen haladó konvoj mindkét végét.', ''),
(6, 'Vidor', 'túrakenu', 'turakenu-tc-03-kiemelt-1024x381-1.jpg', 3, 10800, 'A TC-03 kenu alkalmas kisebb családok és társaságok túrázására. Nagyon jól fordul, könnyen irányítható. Nagy előnye, hogy hossza mindössze 4,5 m, így viszonylag kisebb helyen is eltárolható.\nA kenuk a legelterjedtebb vízitúra eszközök. Futásuk és belső tágasságuk miatt váltak közkedveltté. A nagyon vad hegyi vizeket kivéve szinte mindenhol használhatóak.\nA jó minőségű gél-coat anyagoknak és a nagy szilárdságú műgyantáknak köszönhetően az ütéseknek is ellenállnak. Légkamrákat helyeztünk el a kenuk mindkét végébe, ami megakadályozza az elsüllyedését borulás esetén.\nAz ülések ívelt kiképzésűek, így hosszabb túra után sem törnek. Minden ülés csavarozva van, így bármikor kiszerelhetőek, a kenu utastere átvariálható.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület színezett védőréteggel van ellátva, ami segíti a hajó belsejének tisztán tartását. Érdemes megjegyezni, hogy könnyedén szállítható személygépkocsi tetején is.\nA TC-03 kenu az egyik legalkalmasabb eszköz kisebb családok és társaságok túráin. Nagyon jól fordul, könnyen irányítható. Nagy előnye, hogy hossza mindössze 4,5 m, így viszonylag kisebb helyen is eltárolható.', ''),
(7, 'Hapci', 'indiánkenu', 'indiankenu-3-szemelyes-1024x360-1.jpg', 3, 9000, 'A hosszított orrkiképzése miatt kapta az indiánkenu elnevezést. Ez az IC-03 kenu egy gyorsabb, jobb iránytartású kenu, mint a rövidebb csapattársa. Túravezetői kenunak is kiválóan megfelel.\nA kenuk a legelterjedtebb vízitúra eszközök. Futásuk és belső tágasságuk miatt váltak közkedveltté. A nagyon vad hegyi vizeket kivéve szinte mindenhol használhatóak.\nA jó minőségű gél-coat anyagoknak és a nagy szilárdságú műgyantáknak köszönhetően az ütéseknek is ellenállnak. Légkamrákat helyeztünk el a kenuk mindkét végébe, ami megakadályozza az elsüllyedését borulás esetén.\nAz ülések ívelt kiképzésűek, így hosszabb túra után sem törnek. Minden ülés csavarozva van, így bármikor kiszerelhetőek, a kenu utastere átvariálható.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület színezett védőréteggel van ellátva, ami segíti a hajó belsejének tisztán tartását. Érdemes megjegyezni, hogy könnyedén szállítható személygépkocsi tetején is.\nAz indiánkenu elnevezés csak fantázia név, igazán hasonló vízitúra eszköz, mint a TC-03 túrakenu. A hosszított orrkiképzése miatt kapta az indiánkenu elnevezést. Az IC-03 azonban egy gyorsabb, jobb iránytartású kenu, mint rövidebb csapattársa. Túravezetői kenunak is kiválóan megfelel.', ''),
(8, 'Tudor', 'indiánkenu', 'indián-ic-04-kenu-001.jpg', 4, 16000, 'Az IC-04 kenu a legnagyobb példányszámban eladott típus. Méltán, hiszen a legjobb futású és iránytartású kenu. A beülő létszám és ár arányát tekintve is a legjobb.\nAz IC-04 kenu a legnagyobb példányszámban eladott típus. Méltán, hiszen a legjobb futású és iránytartású kenu. A beülő létszám és ár arányát tekintve is a legjobb.\nA kölcsönzők számára is ez a leggazdaságosabb. 2014 évében nagyjából 150 darab készült belőle. Egyik felső tiszai túráztató vásárlónk, Dallos Sándor, egymaga 50 db-ot vásárolt belőle. A legnagyobb megelégedéssel használják őket azóta is.\nA kenuk a legelterjedtebb vízitúra eszközök. Futásuk és belső tágasságuk miatt váltak közkedveltté. A nagyon vad hegyi vizeket kivéve szinte mindenhol használhatóak.\nA jó minőségű gél-coat anyagoknak és a nagy szilárdságú műgyantáknak köszönhetően az ütéseknek is ellenállnak. Légkamra a kenuk mindkét végébe van építve, ami megakadályozza az elsüllyedését borulás esetén.\nAz ülések ívelt kiképzésűek, így hosszabb túra után sem törnek. Minden ülés csavarozva van, így bármikor kiszerelhetőek, a kenu utastere átvariálható.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület is el van látva színezett védőréteggel, ami segíti a hajó belsejének tisztán tartását. Fontos: szállítható személygépkocsi tetején.', ''),
(9, 'Okoska', 'indiánkenu IC-04XL', 'indián IC-04-XXL-kenu-1024x488-1.jpg', 4, 16800, 'Az IC-04XL típus a legújabb fejlesztésű kenu. A vízitúrázók hosszú éves tapasztalatai alapján merült föl az igény egy még nagyobb teherbírású, kisebb merülésű 4-es kenu létrehozására. Ebben a kenuban, ha mind a négy fő bőven 100 kg fölötti, akkor is maximális stabilitást és biztonságot ad. Ugyanakkor  jobb siklású, haladósabb hajó a régebbi modellnél.\nA kenuk a legelterjedtebb vízitúra eszközök. Futásuk és belső tágasságuk miatt váltak közkedveltté. A nagyon vad hegyi vizeket kivéve szinte mindenhol használhatóak.\nA jó minőségű gél-coat anyagoknak és a nagy szilárdságú műgyantáknak köszönhetően az ütéseknek is ellenállnak. Légkamra a kenuk mindkét végébe van építve, ami megakadályozza az elsüllyedését borulás esetén.\nAz ülések ívelt kiképzésűek, így hosszabb túra után sem törnek. Minden ülés csavarozva van, így bármikor kiszerelhetőek, a kenu utastere átvariálható.\nBármilyen színösszeállításban rendelhetőek. Lehetőség van akár terepszínű kivitelre is.\nA belső felület is el van látva színezett védőréteggel, ami segíti a hajó belsejének tisztán tartását.', ''),
(10, 'Törpapa', 'versenykajak', 'verseny kajak dsc_0496.png', 1, 3900, '', ''),
(11, 'Tréfi', 'versenykenu', 'verseny kenu c2_evo_d_01_tn.png', 2, 7600, '', '');


CREATE TABLE IF NOT EXISTS `kolcsonzes` (
  `sorszam` int(2) NOT NULL AUTO_INCREMENT,
  `datum` varchar(10) DEFAULT NULL,
  `hajo_azon` int(2) DEFAULT NULL,
  `kolcsonzo_azon` int(2) DEFAULT NULL,
  `lapatok_db` int(1) DEFAULT NULL,
  `mentomelleny_db` int(1) DEFAULT NULL,
  `kolcsonzes_osszeg` int(11) NOT NULL,
  PRIMARY KEY (`sorszam`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


INSERT IGNORE INTO `kolcsonzes` (`sorszam`, `datum`, `hajo_azon`, `kolcsonzo_azon`, `lapatok_db`, `mentomelleny_db`, `kolcsonzes_osszeg`) VALUES
(1, '2023.05.01', 6, 26, 3, 1, 10800),
(2, '2023.05.04', 7, 46, 3, 0, 9000),
(3, '2023.05.05', 9, 47, 4, 1, 16800),
(4, '2023.05.05', 10, 49, 1, 1, 3900),
(5, '2023.05.06', 10, 9, 1, 0, 3900),
(6, '2023.05.06', 8, 26, 4, 0, 16000),
(7, '2023.05.08', 1, 12, 1, 1, 3700),
(8, '2023.05.08', 4, 7, 1, 1, 3500),
(9, '2023.05.09', 9, 14, 4, 1, 16800),
(10, '2023.05.09', 7, 42, 3, 2, 9000),
(11, '2023.05.10', 4, 26, 1, 1, 3500),
(12, '2023.05.13', 2, 12, 1, 1, 3900),
(13, '2023.05.17', 2, 52, 1, 1, 3900),
(14, '2023.05.17', 7, 45, 3, 1, 9000),
(15, '2023.05.22', 11, 2, 2, 1, 7600),
(16, '2023.05.23', 9, 20, 4, 2, 16800),
(17, '2023.05.26', 8, 19, 4, 1, 16000),
(18, '2023.05.28', 3, 30, 2, 0, 7400),
(19, '2023.06.01', 9, 25, 4, 3, 16800),
(20, '2023.06.02', 8, 7, 4, 4, 16000),
(21, '2023.06.02', 6, 41, 3, 1, 10800),
(22, '2023.06.06', 9, 34, 4, 3, 16800),
(23, '2023.06.07', 3, 5, 2, 1, 7400),
(24, '2023.06.08', 7, 35, 3, 0, 9000),
(25, '2023.06.21', 11, 21, 2, 0, 7600),
(26, '2023.06.22', 6, 25, 3, 3, 10800),
(27, '2023.06.22', 6, 15, 3, 0, 10800),
(28, '2023.06.23', 4, 52, 1, 0, 3500),
(29, '2023.06.23', 11, 46, 2, 2, 7600),
(30, '2023.06.23', 9, 27, 4, 2, 16800),
(31, '2023.06.25', 7, 3, 3, 0, 9000),
(32, '2023.06.25', 8, 32, 4, 3, 16000),
(33, '2023.06.26', 1, 23, 1, 0, 3700),
(34, '2023.06.26', 7, 2, 3, 2, 9000),
(35, '2023.06.28', 5, 25, 2, 2, 7000),
(36, '2023.06.28', 7, 19, 3, 2, 9000),
(37, '2023.07.04', 6, 49, 3, 2, 10800),
(38, '2023.07.06', 1, 29, 1, 1, 3700),
(39, '2023.07.07', 4, 42, 1, 1, 3500),
(40, '2023.07.09', 2, 5, 1, 0, 3900),
(41, '2023.07.10', 5, 31, 2, 1, 7000),
(42, '2023.07.12', 11, 34, 2, 2, 7600),
(43, '2023.07.13', 9, 35, 4, 1, 16800),
(44, '2023.07.13', 4, 44, 1, 1, 3500),
(45, '2023.07.14', 2, 7, 1, 1, 3900),
(46, '2023.07.15', 11, 6, 2, 2, 7600),
(47, '2023.07.16', 5, 41, 2, 2, 7000),
(48, '2023.07.17', 7, 11, 3, 0, 9000),
(49, '2023.07.17', 2, 37, 1, 1, 3900),
(50, '2023.07.20', 4, 13, 1, 0, 3500),
(51, '2023.07.20', 3, 50, 2, 2, 7400),
(52, '2023.07.20', 4, 23, 1, 1, 3500),
(53, '2023.07.24', 8, 14, 4, 1, 16000),
(54, '2023.07.24', 11, 43, 2, 1, 7600),
(55, '2023.07.24', 1, 37, 1, 1, 3700),
(56, '2023.07.24', 7, 46, 3, 0, 9000),
(57, '2023.07.29', 6, 29, 3, 1, 10800),
(58, '2023.07.31', 8, 3, 4, 2, 16000),
(59, '2023.07.31', 5, 47, 2, 2, 7000),
(60, '2023.08.07', 10, 9, 1, 1, 3900),
(61, '2023.08.07', 3, 50, 2, 2, 7400),
(62, '2023.08.08', 4, 29, 1, 0, 3500),
(63, '2023.08.10', 7, 14, 3, 1, 9000),
(64, '2023.08.13', 1, 34, 1, 1, 3700),
(65, '2023.08.17', 10, 12, 1, 0, 3900),
(66, '2023.08.19', 6, 34, 3, 0, 10800),
(67, '2023.08.19', 9, 16, 4, 2, 16800),
(68, '2023.08.19', 3, 41, 2, 0, 7400),
(69, '2023.08.22', 1, 10, 1, 0, 3700),
(70, '2023.08.25', 3, 24, 2, 1, 7400),
(71, '2023.08.30', 7, 42, 3, 0, 9000),
(72, '2023.08.31', 3, 1, 2, 1, 7400),
(73, '2023.08.31', 1, 30, 1, 0, 3700),
(74, '2023.09.01', 9, 35, 4, 2, 16800),
(75, '2023.09.02', 9, 37, 4, 4, 16800),
(76, '2023.09.03', 11, 3, 2, 2, 7600),
(77, '2023.09.04', 11, 52, 2, 2, 7600),
(78, '2023.09.05', 6, 17, 3, 0, 10800),
(79, '2023.09.06', 10, 1, 1, 0, 3900),
(80, '2023.09.07', 1, 5, 1, 1, 3700),
(81, '2023.09.07', 6, 37, 3, 0, 10800),
(82, '2023.09.08', 4, 36, 1, 1, 3500),
(83, '2023.09.12', 10, 21, 1, 1, 3900),
(84, '2023.09.12', 10, 29, 1, 1, 3900),
(85, '2023.09.12', 4, 26, 1, 1, 3500),
(86, '2023.09.13', 10, 30, 1, 1, 3900),
(87, '2023.09.16', 4, 5, 1, 1, 3500),
(88, '2023.09.18', 11, 42, 2, 1, 7600),
(89, '2023.09.18', 3, 43, 2, 2, 7400),
(90, '2023.09.19', 5, 3, 2, 0, 7000),
(91, '2023.09.20', 1, 43, 1, 0, 3700),
(92, '2023.09.21', 11, 11, 2, 1, 7600),
(93, '2023.09.21', 4, 25, 1, 0, 3500),
(94, '2023.09.23', 11, 27, 2, 2, 7600),
(95, '2023.09.23', 6, 13, 3, 2, 10800),
(96, '2023.09.23', 10, 29, 1, 1, 3900),
(97, '2023.09.27', 11, 52, 2, 2, 7600),
(98, '2023.09.29', 3, 25, 2, 0, 7400);


CREATE TABLE IF NOT EXISTS `kolcsonzo` (
  `azonosito` int(2) NOT NULL AUTO_INCREMENT,
  `nev` varchar(17) DEFAULT NULL,
  `telefon` varchar(11) DEFAULT NULL,
  `szuletesi_ev` int(4) DEFAULT NULL,
  `uszni_tud` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`azonosito`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



INSERT IGNORE INTO `kolcsonzo` (`azonosito`, `nev`, `telefon`, `szuletesi_ev`, `uszni_tud`) VALUES
(1, 'Kiss Dezső', '36204961665', 1964, 'IGAZ'),
(2, 'Kocsis Irma', '36208173509', 1982, 'IGAZ'),
(3, 'Tóth Pál', '36207957787', 1981, 'IGAZ'),
(4, 'Rozsdás Tibor', '36201200302', 2002, 'IGAZ'),
(5, 'Kamarás Lajos', '36304560055', 1993, 'HAMIS'),
(6, 'Tarkó Béla', '36209456214', 2002, 'IGAZ'),
(7, 'Kiss Ede', '36201705849', 1998, 'IGAZ'),
(8, 'Nagy Lajos', '36305160666', 1992, 'HAMIS'),
(9, 'Varga Károly', '36306480079', 1970, 'IGAZ'),
(10, 'Ferenczy Emese', '36203187904', 1967, 'HAMIS'),
(11, 'Beregi Tamás', '36209783942', 1980, 'IGAZ'),
(12, 'Albert Gyula', '36202629022', 1970, 'HAMIS'),
(13, 'Szucs Gyorgy Geza', '36205479464', 2006, 'IGAZ'),
(14, 'Ban Bela', '36407593433', 1998, 'HAMIS'),
(15, 'Birkas Lajos', '36307833120', 1973, 'HAMIS'),
(16, 'Csango Pal', '36308718945', 1975, 'HAMIS'),
(17, 'Csontos Karoly', '36209094780', 1980, 'IGAZ'),
(18, 'Denes Laszlo', '36206868151', 1999, 'IGAZ'),
(19, 'Dobo Erno', '36208327670', 2003, 'HAMIS'),
(20, 'Toth Dora Aliz', '36202911272', 2006, 'IGAZ'),
(21, 'Faradi Aniko', '36203508595', 1996, 'HAMIS'),
(22, 'Gal Adam', '36405131363', 1996, 'HAMIS'),
(23, 'Hegedus Zoltan', '36307189961', 1984, 'HAMIS'),
(24, 'Illes Miklos', '36302929218', 1963, 'HAMIS'),
(25, 'Jakab Agnes', '36207922109', 1968, 'IGAZ'),
(26, 'Kali Lajos', '36205056935', 2006, 'IGAZ'),
(27, 'Kocsis Judit', '36205986467', 1986, 'HAMIS'),
(28, 'Kosa Gyula Gabor', '36306855114', 1967, 'IGAZ'),
(29, 'Kovacs Rita', '36201763523', 1978, 'HAMIS'),
(30, 'Kozma Kalman', '36307688479', 1980, 'HAMIS'),
(31, 'Nagy Reka Anna', '36205823839', 1999, 'IGAZ'),
(32, 'Lazar Tamas', '36201652913', 1963, 'IGAZ'),
(33, 'Lengyel Mihaly', '36205845725', 1992, 'HAMIS'),
(34, 'Madarasz Emil', '36303621365', 1995, 'IGAZ'),
(35, 'Mate Margit', '36302445225', 1990, 'HAMIS'),
(36, 'Mecses Zsofia', '36301211779', 1987, 'HAMIS'),
(37, 'Molnar Dorottya', '36202984427', 1981, 'IGAZ'),
(38, 'Nagy Zsuzsa', '36203317688', 1968, 'IGAZ'),
(39, 'Pal Beata', '36309175841', 1974, 'IGAZ'),
(40, 'Pasztor Mihaly', '36308041579', 1995, 'IGAZ'),
(41, 'Pataky Jozsef', '36306613632', 1980, 'IGAZ'),
(42, 'Racz Dora Aliz', '36206730483', 1984, 'HAMIS'),
(43, 'Rozsa Robert', '36206359234', 1995, 'HAMIS'),
(44, 'Sas Ignacz', '36303166422', 1973, 'HAMIS'),
(45, 'Simon Simon', '36202089632', 1993, 'IGAZ'),
(46, 'Sos Miklos', '36305731441', 1972, 'IGAZ'),
(47, 'Szabo Anna', '36302831224', 1983, 'HAMIS'),
(48, 'Hegedus Gabriella', '36203278440', 1972, 'HAMIS'),
(49, 'Tatai Mark', '36304327140', 2001, 'IGAZ'),
(50, 'Tobias Krisztina', '36305615945', 1977, 'IGAZ'),
(51, 'Toth Janos', '36402711632', 1986, 'HAMIS'),
(52, 'Varga Istvan', '36201043812', 1994, 'HAMIS'),
(53, 'Vigh Eva', '36305924891', 1972, 'IGAZ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;