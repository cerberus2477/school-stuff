﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

namespace forgalom
{
    
    internal class SQLhandler
    {
        static MySqlConnection conn;
        static string query;

        public static bool tryConnect(string dbname)
        {
            string connstr = $"database='{dbname}';server='localhost';port=3306;user='root';password=''";
            try
            {
                conn = new MySqlConnection(connstr);
                conn.Open();
                conn.Close();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }


        public static void FillData(string query, DataGridView dgv)
        {
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgv.DataSource = dt;
                conn.Close();
            }
            catch (MySqlException e)
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();   
                }
                MessageBox.Show(e.Message, "MySqlHiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
        }
    }

}


