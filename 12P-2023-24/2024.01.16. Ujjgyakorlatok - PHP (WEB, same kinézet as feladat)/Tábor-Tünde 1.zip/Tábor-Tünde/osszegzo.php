<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1) Összegző</title>

    <style>
    table {
        color: #5116B0;
        margin: 0 auto 0 auto;
        border-radius: 4px;
        border-spacing: 0px;
        box-shadow: 10px 6px 8px #505090;
        padding: 2px;
        border: 2px solid #9D9DD5;
    }

    td,
    th {
        border: 2px solid white;
        background: #EEEEFF;
        padding: .6rem 2.4rem;
        text-align: center;
    }

    th {
        background: #CCCCFF;
    }
    </style>
</head>

<body>
    <h2>1) Összegző</h2>

    <?php
        echo "<table><tr><th>n</th><th>Σn</th></tr>";
        $sum = 0;
        for ($i=1; $i <= 100; $i++) { 
            $sum += $i;
            echo "<tr><td>$i</td><td>$sum</td></tr>";
        }
        echo "</table>"
    ?>

</body>

</html>