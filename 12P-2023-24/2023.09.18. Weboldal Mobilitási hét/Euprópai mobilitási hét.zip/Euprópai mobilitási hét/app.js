const openLink = function() {
 
    document.getElementsByName("choose_link").forEach(radio => {
        if (radio.checked) {
            window.open(radio.dataset.link, "_blank");
        }
    });
}