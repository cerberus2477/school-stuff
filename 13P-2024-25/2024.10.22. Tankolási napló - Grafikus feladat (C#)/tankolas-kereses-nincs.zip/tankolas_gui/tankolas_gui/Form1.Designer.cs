﻿namespace tankolas_gui
{
    partial class frm_tankolas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_new = new System.Windows.Forms.Panel();
            this.input_litres = new System.Windows.Forms.NumericUpDown();
            this.input_km = new System.Windows.Forms.NumericUpDown();
            this.input_date = new System.Windows.Forms.DateTimePicker();
            this.btn_new = new System.Windows.Forms.Button();
            this.lbl_litres = new System.Windows.Forms.Label();
            this.lbl_km = new System.Windows.Forms.Label();
            this.tb_licensePlate = new System.Windows.Forms.TextBox();
            this.lbl_licensePlate = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_new = new System.Windows.Forms.Label();
            this.pnl_search = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.col_search_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_search_licensePlate = new System.Windows.Forms.TextBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.lbl_search = new System.Windows.Forms.Label();
            this.pnl_exit = new System.Windows.Forms.Panel();
            this.btn_exit = new System.Windows.Forms.Button();
            this.pnl_display = new System.Windows.Forms.Panel();
            this.lbl_importedFile = new System.Windows.Forms.Label();
            this.dgv_display = new System.Windows.Forms.DataGridView();
            this.col_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_licensePlate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_km = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_litres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_avgFuelConsumption = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_export = new System.Windows.Forms.Button();
            this.btn_import = new System.Windows.Forms.Button();
            this.pnl_left = new System.Windows.Forms.Panel();
            this.fileDialog_open = new System.Windows.Forms.OpenFileDialog();
            this.fileDialog_save = new System.Windows.Forms.SaveFileDialog();
            this.pnl_new.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.input_litres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.input_km)).BeginInit();
            this.pnl_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.pnl_exit.SuspendLayout();
            this.pnl_display.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_display)).BeginInit();
            this.pnl_left.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_new
            // 
            this.pnl_new.Controls.Add(this.input_litres);
            this.pnl_new.Controls.Add(this.input_km);
            this.pnl_new.Controls.Add(this.input_date);
            this.pnl_new.Controls.Add(this.btn_new);
            this.pnl_new.Controls.Add(this.lbl_litres);
            this.pnl_new.Controls.Add(this.lbl_km);
            this.pnl_new.Controls.Add(this.tb_licensePlate);
            this.pnl_new.Controls.Add(this.lbl_licensePlate);
            this.pnl_new.Controls.Add(this.lbl_date);
            this.pnl_new.Controls.Add(this.lbl_new);
            this.pnl_new.Location = new System.Drawing.Point(3, 3);
            this.pnl_new.Name = "pnl_new";
            this.pnl_new.Size = new System.Drawing.Size(218, 313);
            this.pnl_new.TabIndex = 0;
            // 
            // input_litres
            // 
            this.input_litres.DecimalPlaces = 1;
            this.input_litres.Location = new System.Drawing.Point(15, 241);
            this.input_litres.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.input_litres.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.input_litres.Name = "input_litres";
            this.input_litres.Size = new System.Drawing.Size(200, 20);
            this.input_litres.TabIndex = 12;
            this.input_litres.ThousandsSeparator = true;
            this.input_litres.Value = new decimal(new int[] {
            447,
            0,
            0,
            65536});
            // 
            // input_km
            // 
            this.input_km.Location = new System.Drawing.Point(15, 187);
            this.input_km.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.input_km.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.input_km.Name = "input_km";
            this.input_km.Size = new System.Drawing.Size(200, 20);
            this.input_km.TabIndex = 11;
            this.input_km.ThousandsSeparator = true;
            this.input_km.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // input_date
            // 
            this.input_date.Location = new System.Drawing.Point(15, 84);
            this.input_date.Name = "input_date";
            this.input_date.Size = new System.Drawing.Size(200, 20);
            this.input_date.TabIndex = 10;
            // 
            // btn_new
            // 
            this.btn_new.Location = new System.Drawing.Point(68, 276);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(75, 23);
            this.btn_new.TabIndex = 9;
            this.btn_new.Text = "Hozzáadás";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // lbl_litres
            // 
            this.lbl_litres.AutoSize = true;
            this.lbl_litres.Location = new System.Drawing.Point(12, 225);
            this.lbl_litres.Name = "lbl_litres";
            this.lbl_litres.Size = new System.Drawing.Size(62, 13);
            this.lbl_litres.TabIndex = 7;
            this.lbl_litres.Text = "Tankolt liter";
            // 
            // lbl_km
            // 
            this.lbl_km.AutoSize = true;
            this.lbl_km.Location = new System.Drawing.Point(12, 171);
            this.lbl_km.Name = "lbl_km";
            this.lbl_km.Size = new System.Drawing.Size(62, 13);
            this.lbl_km.TabIndex = 5;
            this.lbl_km.Text = "Megtett KM";
            // 
            // tb_licensePlate
            // 
            this.tb_licensePlate.Location = new System.Drawing.Point(15, 135);
            this.tb_licensePlate.Name = "tb_licensePlate";
            this.tb_licensePlate.Size = new System.Drawing.Size(200, 20);
            this.tb_licensePlate.TabIndex = 4;
            this.tb_licensePlate.Text = "ABC-123";
            // 
            // lbl_licensePlate
            // 
            this.lbl_licensePlate.AutoSize = true;
            this.lbl_licensePlate.Location = new System.Drawing.Point(12, 119);
            this.lbl_licensePlate.Name = "lbl_licensePlate";
            this.lbl_licensePlate.Size = new System.Drawing.Size(57, 13);
            this.lbl_licensePlate.TabIndex = 3;
            this.lbl_licensePlate.Text = "Rendszám";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(12, 68);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(38, 13);
            this.lbl_date.TabIndex = 1;
            this.lbl_date.Text = "Dátum";
            // 
            // lbl_new
            // 
            this.lbl_new.AutoSize = true;
            this.lbl_new.Location = new System.Drawing.Point(76, 32);
            this.lbl_new.Name = "lbl_new";
            this.lbl_new.Size = new System.Drawing.Size(60, 13);
            this.lbl_new.TabIndex = 0;
            this.lbl_new.Text = "Új tankolás";
            // 
            // pnl_search
            // 
            this.pnl_search.Controls.Add(this.dataGridView1);
            this.pnl_search.Controls.Add(this.tb_search_licensePlate);
            this.pnl_search.Controls.Add(this.btn_search);
            this.pnl_search.Controls.Add(this.lbl_search);
            this.pnl_search.Location = new System.Drawing.Point(3, 322);
            this.pnl_search.Name = "pnl_search";
            this.pnl_search.Size = new System.Drawing.Size(215, 163);
            this.pnl_search.TabIndex = 10;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_search_date});
            this.dataGridView1.Location = new System.Drawing.Point(3, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(200, 57);
            this.dataGridView1.TabIndex = 14;
            // 
            // col_search_date
            // 
            this.col_search_date.HeaderText = "Dátum";
            this.col_search_date.Name = "col_search_date";
            this.col_search_date.ReadOnly = true;
            // 
            // tb_search_licensePlate
            // 
            this.tb_search_licensePlate.Location = new System.Drawing.Point(3, 50);
            this.tb_search_licensePlate.Name = "tb_search_licensePlate";
            this.tb_search_licensePlate.Size = new System.Drawing.Size(200, 20);
            this.tb_search_licensePlate.TabIndex = 13;
            this.tb_search_licensePlate.Text = "ABC-123";
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(68, 137);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 23);
            this.btn_search.TabIndex = 10;
            this.btn_search.Text = "Keresés";
            this.btn_search.UseVisualStyleBackColor = true;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Location = new System.Drawing.Point(13, 9);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(130, 13);
            this.lbl_search.TabIndex = 11;
            this.lbl_search.Text = "Keresés rendszám alapján";
            // 
            // pnl_exit
            // 
            this.pnl_exit.Controls.Add(this.btn_exit);
            this.pnl_exit.Location = new System.Drawing.Point(5, 507);
            this.pnl_exit.Name = "pnl_exit";
            this.pnl_exit.Size = new System.Drawing.Size(782, 54);
            this.pnl_exit.TabIndex = 13;
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(299, 18);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(201, 23);
            this.btn_exit.TabIndex = 12;
            this.btn_exit.Text = "Kilépés a programból";
            this.btn_exit.UseVisualStyleBackColor = true;
            // 
            // pnl_display
            // 
            this.pnl_display.Controls.Add(this.lbl_importedFile);
            this.pnl_display.Controls.Add(this.dgv_display);
            this.pnl_display.Controls.Add(this.btn_export);
            this.pnl_display.Controls.Add(this.btn_import);
            this.pnl_display.Location = new System.Drawing.Point(240, 6);
            this.pnl_display.Name = "pnl_display";
            this.pnl_display.Size = new System.Drawing.Size(547, 495);
            this.pnl_display.TabIndex = 11;
            // 
            // lbl_importedFile
            // 
            this.lbl_importedFile.AutoSize = true;
            this.lbl_importedFile.Location = new System.Drawing.Point(3, 469);
            this.lbl_importedFile.Name = "lbl_importedFile";
            this.lbl_importedFile.Size = new System.Drawing.Size(0, 13);
            this.lbl_importedFile.TabIndex = 14;
            // 
            // dgv_display
            // 
            this.dgv_display.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_display.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_display.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_date,
            this.col_licensePlate,
            this.col_km,
            this.col_litres,
            this.col_avgFuelConsumption});
            this.dgv_display.Location = new System.Drawing.Point(0, 0);
            this.dgv_display.Name = "dgv_display";
            this.dgv_display.Size = new System.Drawing.Size(547, 449);
            this.dgv_display.TabIndex = 13;
            // 
            // col_date
            // 
            this.col_date.HeaderText = "Dátum";
            this.col_date.Name = "col_date";
            this.col_date.ReadOnly = true;
            // 
            // col_licensePlate
            // 
            this.col_licensePlate.HeaderText = "Rendszám";
            this.col_licensePlate.Name = "col_licensePlate";
            this.col_licensePlate.ReadOnly = true;
            // 
            // col_km
            // 
            this.col_km.HeaderText = "Megtett KM";
            this.col_km.Name = "col_km";
            this.col_km.ReadOnly = true;
            // 
            // col_litres
            // 
            this.col_litres.HeaderText = "Tankolt liter";
            this.col_litres.Name = "col_litres";
            this.col_litres.ReadOnly = true;
            // 
            // col_avgFuelConsumption
            // 
            this.col_avgFuelConsumption.HeaderText = "Átlagfogyasztás";
            this.col_avgFuelConsumption.Name = "col_avgFuelConsumption";
            this.col_avgFuelConsumption.ReadOnly = true;
            // 
            // btn_export
            // 
            this.btn_export.Location = new System.Drawing.Point(457, 459);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(75, 23);
            this.btn_export.TabIndex = 12;
            this.btn_export.Text = "Exportálás";
            this.btn_export.UseVisualStyleBackColor = true;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // btn_import
            // 
            this.btn_import.Location = new System.Drawing.Point(363, 459);
            this.btn_import.Name = "btn_import";
            this.btn_import.Size = new System.Drawing.Size(75, 23);
            this.btn_import.TabIndex = 11;
            this.btn_import.Text = "Betöltés";
            this.btn_import.UseVisualStyleBackColor = true;
            this.btn_import.Click += new System.EventHandler(this.btn_import_Click);
            // 
            // pnl_left
            // 
            this.pnl_left.Controls.Add(this.pnl_new);
            this.pnl_left.Controls.Add(this.pnl_search);
            this.pnl_left.Location = new System.Drawing.Point(2, 3);
            this.pnl_left.Name = "pnl_left";
            this.pnl_left.Size = new System.Drawing.Size(223, 498);
            this.pnl_left.TabIndex = 13;
            // 
            // frm_tankolas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.pnl_left);
            this.Controls.Add(this.pnl_exit);
            this.Controls.Add(this.pnl_display);
            this.Name = "frm_tankolas";
            this.Text = "Tankolási napló";
            this.pnl_new.ResumeLayout(false);
            this.pnl_new.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.input_litres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.input_km)).EndInit();
            this.pnl_search.ResumeLayout(false);
            this.pnl_search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.pnl_exit.ResumeLayout(false);
            this.pnl_display.ResumeLayout(false);
            this.pnl_display.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_display)).EndInit();
            this.pnl_left.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_new;
        private System.Windows.Forms.Label lbl_new;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Label lbl_litres;
        private System.Windows.Forms.Label lbl_km;
        private System.Windows.Forms.TextBox tb_licensePlate;
        private System.Windows.Forms.Label lbl_licensePlate;
        private System.Windows.Forms.Panel pnl_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Panel pnl_display;
        private System.Windows.Forms.Panel pnl_exit;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.Button btn_import;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.DataGridView dgv_display;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_licensePlate;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_km;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_litres;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_avgFuelConsumption;
        private System.Windows.Forms.Panel pnl_left;
        private System.Windows.Forms.NumericUpDown input_km;
        private System.Windows.Forms.DateTimePicker input_date;
        private System.Windows.Forms.NumericUpDown input_litres;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_search_date;
        private System.Windows.Forms.TextBox tb_search_licensePlate;
        private System.Windows.Forms.OpenFileDialog fileDialog_open;
        private System.Windows.Forms.SaveFileDialog fileDialog_save;
        private System.Windows.Forms.Label lbl_importedFile;
    }
}

