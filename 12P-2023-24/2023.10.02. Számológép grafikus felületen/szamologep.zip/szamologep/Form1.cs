﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace szamologep {
	public partial class szamologep : Form {

		string input = "";
		public szamologep() {
			InitializeComponent();
		}

		private void szamologep_Load(object sender, EventArgs e) {
			
		}

		private void btn1_Click(object sender, EventArgs e) {
			display.Text += "1";
		}

		private void btn2_Click(object sender, EventArgs e) {
			display.Text += "2";
		}

		private void btn3_Click(object sender, EventArgs e) {
			display.Text += "3";
		}

		private void btn4_Click(object sender, EventArgs e) {
			display.Text += "4";
		}

		private void btn5_Click(object sender, EventArgs e) {
			display.Text += btn5.Text;
		}

		private void btn6_Click(object sender, EventArgs e) {
			display.Text += btn6.Text;
		}

		private void btn7_Click(object sender, EventArgs e) {
			display.Text += btn7.Text;
		}

		private void btn8_Click(object sender, EventArgs e) {
			display.Text += btn8.Text;
		}

		private void btn9_Click(object sender, EventArgs e) {
			display.Text += btn9.Text;
		}

		private void btn0_Click(object sender, EventArgs e) {
			display.Text += btn0.Text;
		}

		private void btnPlus_Click(object sender, EventArgs e) {

		}

		/*pl:
		 2-2*3^(2+1) => 2-2*3^3 => 2-2*3 => 2-8 => -6 */
		public string Calculate(string task) { 
			if() { //ha nincs már benne műveleti jel
				return task;
			}
			task = ""; //megoldja a következő műveletet és újra meghívja magát

			return Calculate(task);
		}

		private void btnEquals_Click(object sender, EventArgs e) {
			display.Text = Calculate(display.Text);
		}
	}
}
