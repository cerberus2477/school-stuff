﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _09._26_kullancs
{
    internal class Program
    {


        static Kullancsok adatok = new Kullancsok("data.txt");
        static void Main(string[] args)
        {

            /*
             * Egy laboratóriumban kullancsok fertőzöttségét ellenőrzik.
             * 
             *Teszteléshez készítsen fájlolvasó részt is (fájl is amit előre feltölt adatokkal)
             * A Főprogram segítségével töltse fel 10 kullancs adataival a rendszert
             * 
             * 
             * Irassa ki a legtöbb fertőzést hordozó kullancsot(-okat)
             * Keresse meg a felhasználó által megadott kullancs által terjesztett fertőzéseket (irassa is ki:)
             * Keresse meg a felhasználó által megadott fertőzést terjesztő kullancsokat
             * Listázza ki, hogy milyen fertőzéseket terjesztenek a kullancsok (egyesével? összesen?)
             * 
             * */

            Console.WriteLine($"1) A legtöbb fetőzést hordozó kullancs(ok):\n{adatok.KiirMaxFerto()}\n");
            Console.WriteLine($"2) Adja meg egy kullancs sorszámát!");
            Console.WriteLine($"A keresett kullancs által terjesztett fertőzések:\n{String.Join("\n", MaxFertozes().ToArray())}\n\n");
            );


        }



        static List<string> MaxFertozes()
        {
            List<string> r = new List<string>();

            return r;
        }
    }
}
