<?php 

// DB SETUP
$adb =  mysqli_connect("localhost", "root", "", "");
$sql = file_get_contents("./database_files/csonakkolcsonzo.sql");
$sqlCommands = explode(';', $sql);
foreach ($sqlCommands as $command) {
    if (trim($command) !== '') {
        try {
            mysqli_query($adb, $command);
        } catch (Exception $e) {
            echo $e;
            echo "<br>".trim($command);
        }
    }
}
mysqli_close($adb);



$conn = new mysqli("localhost", "root", "", "csonakkolcsonzo");

if ($conn->connect_error) {
    die("Az adatbázishoz való csatlakozás közben hiba lépett fel. " . $conn->connect_error);
}

$img_root = "./hajo_kepek/";
$hajok_sql = "SELECT * FROM hajok WHERE 1=1";
$kolcsonzok_sql = "SELECT * FROM kolcsonzo WHERE 1=1";

// KERESŐ
if (isset($_GET['hajok-search-nev']) && isset($_GET['hajok-search-fo'])) {
    // Hajó neve
    if (!empty($_GET['hajok-search-nev'])) {
        $hajok_sql .= " AND nev LIKE '%" . $_GET['hajok-search-nev'] . "%'";
    }
    // Minimum fő
    if (!empty($_GET['hajok-search-fo'])) {
        $hajok_sql .= " AND fo >= " . $_GET['hajok-search-fo'];
    }
}
if (isset($_GET['kolcsonzo-search-fogl']) && isset($_GET['kolcsonzo-search-nev'])) {
    // Hajó neve
    if (!empty($_GET['kolcsonzo-search-nev'])) {
        $kolcsonzok_sql .= " AND nev LIKE '%" . $_GET['kolcsonzo-search-nev'] . "%'";
    }
    // Minimum fő
    if (!empty($_GET['kolcsonzo-search-fogl'])) {
        $kolcsonzok_sql .= " AND fo >= " . $_GET['kolcsonzo-search-fogl'];
    }
}
?>

<script>
     function submitForm(form) {
        document.getElementById(form).scrollIntoView();
        document.getElementById(form).submit();
        
    }
</script>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FolyóFantom</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav>
        <span class="brand">FOLYÓFANTOM</span>
        <div class="navlinks">
            <a href="#hajok">Hajók</a>
            <a href="#kolcsonzok">Kölcsönzők</a>
            <a href="uj.php">Új rekord</a>
        </div>
    </nav>

    <header class="header">
        <h1>FolyóFantom csónakkölcsönző</h1>
        <p>Kölcsönözz csónakot még ma!</p>
        <a href="#hajok" class="btn">Hajók</a>
    </header>

    <section id="hajok">
    <h2>Hajók</h2>
    <p>Kattintson az új kölcsönzés hozzáadása gombra!</p>
    <form id="hajok-kereso" method="GET" action="">
        <div class="form-group">
            <label for="hajok-search-nev">Hajó neve:</label> 
            <input oninput="submitForm('hajok-kereso')" type="text" id="hajok-search-nev" name="hajok-search-nev" value="<?=isset($_GET['hajok-search-nev']) ? $_GET['hajok-search-nev'] : ''; ?>" placeholder="Kezdjen el gépelni...">
        </div>
        <div class="form-group">
            <label for="hajok-search-fo">Minimum fő:</label> 
            <input oninput="submitForm('hajok-kereso')" type="number" id="hajok-search-fo" name="hajok-search-fo" value="<?=isset($_GET['hajok-search-fo']) ? $_GET['hajok-search-fo'] : '1'; ?>" min="1">
        </div>
    </form>

    <?php $result = $conn->query($hajok_sql); ?>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($hajo = $result->fetch_assoc()): ?>
            <div class="hajo">
                <h3><?=$hajo["nev"]?></h3>
                <hr>
                <p>Típus: <?=$hajo["tipus"]?></p>
                <p>Maximum fő: <?=$hajo["fo"]?></p>
                <p>Egységár: <?=$hajo["kölcsönzesi_ar"]?> Ft/nap</p>
                <hr>
                <p>Leírás: <?=$hajo["leiras"]?></p>
                <img src="<?=$img_root.$hajo['kep']?>" alt='<?=$hajo["nev"]?> képe'>
                <a class="btn" href="kosar.php/<?=$uj['azonosito']?>" >Új kölcsönzés hozzáadása</a>
            </div>
        <?php endwhile?>
    <?php else: ?>
        <p>Nincs eredmény a hajok táblából. Probálja módosítani a keresés feltételeit.</p>
    <?php endif?>
</section>



<!-- KÖLCSÖNZŐK -->
<section id="kolcsonzok">
    <h2 id="kolcsonzo">Kölcsönzők</h2>
    <p>Kattintson a módosítás gombra</p>
    <form id="kolcsonzo-kereso" method="GET" action="">
        <div class="form-group">
            <label for="kolcsonzo-search-nev">Kölcsönző neve:</label> 
            <input oninput="submitForm('kolcsonzo-kereso')" type="text" id="kolcsonzo-search-nev" name="kolcsonzo-search-nev" value="<?=isset($_GET['kolcsonzo-search-nev']) ? $_GET['kolcsonzo-search-nev'] : ''; ?>" placeholder="Kezdjen el gépelni...">
        </div>
        <div class="form-group">
            <label for="kolcsonzo-search-fogl">Minimum foglalás:</label> 
            <input oninput="submitForm('kolcsonzo-kereso')" type="number" id="kolcsonzo-search-fogl" name="kolcsonzo-search-fogl" value="<?=isset($_GET['kolcsonzo-search-fogl']) ? $_GET['kolcsonzo-search-fogl'] : '0'; ?>" min="0">
        </div>
    </form>

    <?php $result = $conn->query($kolcsonzok_sql); ?>
    <table>
        <tr>
            <th>Név</th>
            <th>Telefon</th>
            <th>Születési dátum</th>
            <th>Úszni tud</th>
            <th>Foglalások száma</th>
            <th>Rekord módosítása</th>
        </tr>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($kolcs= $result->fetch_assoc()): ?>
            <tr>
                <td><?=$kolcs["nev"]?></td>
                <td><?=$kolcs["telefon"]?></td>
                <td><?=$kolcs["szuletesi_ev"]?></td>
                <td><?=$kolcs["uszni_tud"]?></td>
                <td>db</td>
                <td><a class="btn" href="kolcs_mod.php/<?=$kolcs['azonosito']?>" >Módosítás</a></td>
            </tr>
        <?php endwhile?>
    <?php else: ?>
        <tr>
            <td colspan="6">Nincs eredmény a kölcsönző táblából. Probálja módosítani a keresés feltételeit.</td>
        </tr>
    <?php endif?>
    </table>
</body>
</html>
