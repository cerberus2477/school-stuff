﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09._20_szek {
	class Program {
        static Terem db = new Terem();

		static void Main(string[] args) {
            menu();
		}

        static void menu() {
            int userInput = -1;
            do {
                Console.Clear();
                Console.WriteLine("SZÍNHÁZI NYILVÁNTARTÁS\nA továbblépéshez gépeljen be egyet az alábbi számok közül\n");
                Console.WriteLine("[1] Székek létrehozása");
                Console.WriteLine("[2] Összes szék foglaltsága");
                Console.WriteLine("[3] Adott szék dátum szerinti foglaltsága");
                Console.WriteLine("[4] Székfoglalás");
                Console.WriteLine("[5] Székinformáció");
                Console.WriteLine("[6] Kilépés\n");
                userInput = int.Parse(Console.ReadLine());
                switch(userInput) {
                    case 1:
                        //ujSzekek();
                        break;
                    case 2:
                        Teremfoglaltsag();
                        break;
                    case 3:
                        //Szekfoglaltsag();
                        break;
                    case 4:
                        //Szekfoglalas();
                        break;
                    case 5:
                        //Szekinfo();
                        break;
                }
                Console.WriteLine("\n\nNyomjon le egy billentyűt a továbblépéshez...");
                Console.ReadKey();

            } while(userInput != 6);

            Environment.Exit(0);
        }

        /*static void ujSzekek() {

		}*/

        static void Teremfoglaltsag() {
            Console.Clear();
			Console.Write("Dátum: ");
			string datum = Console.ReadLine(); 
			Console.WriteLine($"{datum} napon a székek foglaltsága így alakul: (\"o\" - üres, \"x\" - foglalt, \"_\" - nincs szék)\n");
			Console.WriteLine(db.Teremfoglaltsag(datum));
		}

        static void Szekfoglaltsag() {
            Console.Clear();
            
            Console.Write("Sor");
            int sor = int.Parse(Console.ReadLine());
            Console.Write("Oszlop: ");
            int oszlop = int.Parse(Console.ReadLine());
			if(!db.isUres(sor, oszlop)) {
                Console.Write("Dátum: ");
                string datum = Console.ReadLine();
                Console.WriteLine($"{datum} ez a szék ...");
            } else {
				Console.WriteLine("Ezen a helyen nincs szék.");
			}
            
            
           
        }

        /*static void Szekfoglalas() {

        }

        static void Szekinfo() {

		}*/
    }

    
}
