﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace munkavallalo
{
	class Program
	{
		class Munkavallalo : IComparable<Munkavallalo>
		{
			private string nev { get; set; }
			private DateTime belepIdo { get; }
			private int fizKat { get; set; }
			public int evesSzab { get; set; }
			public int hatralevoSzab { get; set; }
			public string munkakor { get; set; }

			public Munkavallalo(string nev, int evesSzab, DateTime belepIdo, int fizKat, string munkakor)
			{
				this.nev = nev;
				this.evesSzab = evesSzab;
				hatralevoSzab = evesSzab;
				this.belepIdo = belepIdo;
				this.fizKat = fizKat;
				this.munkakor = munkakor;
			}

			public Munkavallalo()
			{
				fizKat = 1;
				belepIdo = DateTime.Today;
				evesSzab = 20;
				hatralevoSzab = 20;
			}


			public int CompareTo(Munkavallalo valaki)
			{
				if (nev.CompareTo(valaki.nev) == -1)
				{
					return -1;
				}
				else if (nev.CompareTo(valaki.nev) == 1)
				{
					return 1;
				}
				else
				{
					if (fizKat < valaki.fizKat)
					{
						return 1;
					}
					else if (fizKat > valaki.fizKat)
					{
						return -1;
					}
					else
					{
						return 0;
					}
				}
			}

			public override string ToString()
			{
				return $"{nev}, {evesSzab}, {hatralevoSzab}, {belepIdo}, {fizKat}, {munkakor}";
			}
		}

		static bool validNev(string nev)
		{
			return nev.Split(' ').Length >= 2;
				//&& teljNev.All(n => n.Length >= 1);
		}

		static bool validMunkakor(string munkakor)
		{
			return munkakor.Length >= 2;
		}


		static bool validDatum(DateTime datum)
		{
			return (new DateTime(1950, 1, 1) <= datum && datum <= DateTime.Today);
		}

		static bool validEvesSzab(string fizKat)
		{
			try
			{
				return (20 <= int.Parse(fizKat) && int.Parse(fizKat) <= 100);
			}
			catch (Exception)
			{
				return false;
				throw;
			}
		}

		static bool validFizKat(string fizKat)
		{
			try
			{
				return (1 <= int.Parse(fizKat) && int.Parse(fizKat) <= 10);
			}
			catch (Exception)
			{
				return false;
				throw;
			}
		}


		static void Main(string[] args)
		{
		}
	}
}
