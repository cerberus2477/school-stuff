﻿
namespace kutyak
{
    partial class frmKutyak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msFomenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mentés10FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kilépésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.megoldásokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kutyákSzáma5FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.átlagéletkor6FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.legidősebb7FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fajtánként8FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.legterheltebb9FeladatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbMegoldasok = new System.Windows.Forms.TextBox();
            this.msFomenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // msFomenu
            // 
            this.msFomenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.megoldásokToolStripMenuItem});
            this.msFomenu.Location = new System.Drawing.Point(0, 0);
            this.msFomenu.Name = "msFomenu";
            this.msFomenu.Size = new System.Drawing.Size(800, 24);
            this.msFomenu.TabIndex = 1;
            this.msFomenu.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mentés10FeladatToolStripMenuItem,
            this.kilépésToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mentés10FeladatToolStripMenuItem
            // 
            this.mentés10FeladatToolStripMenuItem.Name = "mentés10FeladatToolStripMenuItem";
            this.mentés10FeladatToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mentés10FeladatToolStripMenuItem.Text = "Mentés (10. feladat)";
            this.mentés10FeladatToolStripMenuItem.Click += new System.EventHandler(this.mentés10FeladatToolStripMenuItem_Click);
            // 
            // kilépésToolStripMenuItem
            // 
            this.kilépésToolStripMenuItem.Name = "kilépésToolStripMenuItem";
            this.kilépésToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.kilépésToolStripMenuItem.Text = "Kilépés";
            // 
            // megoldásokToolStripMenuItem
            // 
            this.megoldásokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kutyákSzáma5FeladatToolStripMenuItem,
            this.átlagéletkor6FeladatToolStripMenuItem,
            this.legidősebb7FeladatToolStripMenuItem,
            this.fajtánként8FeladatToolStripMenuItem,
            this.legterheltebb9FeladatToolStripMenuItem});
            this.megoldásokToolStripMenuItem.Name = "megoldásokToolStripMenuItem";
            this.megoldásokToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.megoldásokToolStripMenuItem.Text = "Megoldások";
            // 
            // kutyákSzáma5FeladatToolStripMenuItem
            // 
            this.kutyákSzáma5FeladatToolStripMenuItem.Name = "kutyákSzáma5FeladatToolStripMenuItem";
            this.kutyákSzáma5FeladatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.kutyákSzáma5FeladatToolStripMenuItem.Text = "Kutyák száma (5. feladat)";
            this.kutyákSzáma5FeladatToolStripMenuItem.Click += new System.EventHandler(this.kutyákSzáma5FeladatToolStripMenuItem_Click);
            // 
            // átlagéletkor6FeladatToolStripMenuItem
            // 
            this.átlagéletkor6FeladatToolStripMenuItem.Name = "átlagéletkor6FeladatToolStripMenuItem";
            this.átlagéletkor6FeladatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.átlagéletkor6FeladatToolStripMenuItem.Text = "Átlagéletkor (6. feladat)";
            this.átlagéletkor6FeladatToolStripMenuItem.Click += new System.EventHandler(this.átlagéletkor6FeladatToolStripMenuItem_Click);
            // 
            // legidősebb7FeladatToolStripMenuItem
            // 
            this.legidősebb7FeladatToolStripMenuItem.Name = "legidősebb7FeladatToolStripMenuItem";
            this.legidősebb7FeladatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.legidősebb7FeladatToolStripMenuItem.Text = "Legidősebb (7. feladat)";
            this.legidősebb7FeladatToolStripMenuItem.Click += new System.EventHandler(this.legidősebb7FeladatToolStripMenuItem_Click);
            // 
            // fajtánként8FeladatToolStripMenuItem
            // 
            this.fajtánként8FeladatToolStripMenuItem.Name = "fajtánként8FeladatToolStripMenuItem";
            this.fajtánként8FeladatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.fajtánként8FeladatToolStripMenuItem.Text = "Fajtánként (8. feladat)";
            this.fajtánként8FeladatToolStripMenuItem.Click += new System.EventHandler(this.fajtánként8FeladatToolStripMenuItem_Click);
            // 
            // legterheltebb9FeladatToolStripMenuItem
            // 
            this.legterheltebb9FeladatToolStripMenuItem.Name = "legterheltebb9FeladatToolStripMenuItem";
            this.legterheltebb9FeladatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.legterheltebb9FeladatToolStripMenuItem.Text = "Legterheltebb (9. feladat)";
            this.legterheltebb9FeladatToolStripMenuItem.Click += new System.EventHandler(this.legterheltebb9FeladatToolStripMenuItem_Click);
            // 
            // tbMegoldasok
            // 
            this.tbMegoldasok.Location = new System.Drawing.Point(39, 51);
            this.tbMegoldasok.Multiline = true;
            this.tbMegoldasok.Name = "tbMegoldasok";
            this.tbMegoldasok.ReadOnly = true;
            this.tbMegoldasok.Size = new System.Drawing.Size(514, 339);
            this.tbMegoldasok.TabIndex = 2;
            // 
            // frmKutyak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbMegoldasok);
            this.Controls.Add(this.msFomenu);
            this.Name = "frmKutyak";
            this.Text = "Kutyák";
            this.Load += new System.EventHandler(this.frmKutyak_Load);
            this.msFomenu.ResumeLayout(false);
            this.msFomenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msFomenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mentés10FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kilépésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem megoldásokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kutyákSzáma5FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem átlagéletkor6FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem legidősebb7FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fajtánként8FeladatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem legterheltebb9FeladatToolStripMenuItem;
        private System.Windows.Forms.TextBox tbMegoldasok;
    }
}

