﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programozasi_tetelek
{
    internal class Tetel
    {
        public string Title { get; set; }
        public string Leiras { get; set; }
        public string[] Kod { get; set; }
        public string Feladat { get; set; }
        public string[] Megoldas { get; set; }
        public string[] AdatBe_blueprint { get; set; }
    }
}