﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace korok_uj
{
    internal class kor
    {
        private int _id;
        private char _color;
        private int _radius;
        private int _x;
        private int _y;

        public kor(int id, char color, int radius, int x, int y)
        {
            this._id = id;
            this._x = x;
            this._y = y;
            this._color = color;
            this._radius = radius;
        }

        public bool isPointInKor(int pointx, int pointy)
        {
            // Pythagoras-tétel alapján kiszámolja a távolságot a ponttól a kör középpontjáig, ha nagyobb mint a sugár akkor nincs benne. 
            double distance = Math.Sqrt(Math.Pow(pointx - _x, 2) + Math.Pow(pointy - _y, 2));
            return distance <= _radius;
        }

        public char getColor()
        {
            return _color;
        }

        public int getId()
        {
            return _id;
        }
    }
}
