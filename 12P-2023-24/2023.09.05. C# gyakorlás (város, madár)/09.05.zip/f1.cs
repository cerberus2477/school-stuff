﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace feladat01_09_05
{

    internal class Program
    {
        static void Main(string[] args)
        {
            //1 kérjen be egy term számot, s adja meg hogy a binárisan felírt alakban hány egyes van
            Console.WriteLine("Adjon meg egy természetes számot!");
            int n = int.Parse(Console.ReadLine());

            string binary = Convert.ToString(n, 2);

            Console.WriteLine($"A szám bináris alakjában {binary.Count(x => x=='1')} egyes szerepel. (bináris alak: {binary})");
        }
    }
}
