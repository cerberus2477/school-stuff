﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Adja meg egy szöveges állomány nevét kiterjesztéssel együtt (a Debug mappából): ");
            string[] lines = File.ReadAllLines(Console.ReadLine());

            Console.Write("Adja meg a keresett szöveget: ");
            string search = Console.ReadLine();

            File.WriteAllLines("masolt_sorok.txt", lines.Where(l => l.Contains(search)));
            Console.WriteLine("A keresett kifejezést tartalmazó sorok másolása megtörtént.");
        }
    }
}
