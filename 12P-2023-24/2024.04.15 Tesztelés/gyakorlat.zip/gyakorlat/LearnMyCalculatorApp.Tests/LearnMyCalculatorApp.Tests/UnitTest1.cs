
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LearnMyCalculatorApp;

namespace LearnMyCalculatorApp.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CalculatorNullTest()
        {
            var calculator = new Calculator();
            Assert.IsNotNull(calculator);

            //Assert.IsTrue(false); //�gy nem lesz j� a teszt
        }

        [TestMethod]
        public void AddTest()
        {
            // Arrange
            var calculator = new Calculator();

            // Act
            var actual = calculator.Add(1, 1);

            // Assert
            Assert.AreEqual(2, actual);
        }

        [TestMethod]
        public void SubstractTest()
        {
            var calc = new Calculator();
            var actual = calc.Subtract(12, 3);
            Assert.AreEqual(9, actual);
        }

        [TestMethod]
        public void MultiplyTest()
        {
            var calc = new Calculator();
            var actual = calc.Multiply(3, 11);
            Assert.AreEqual(33, actual);
        }

        [TestMethod]
        public void DivideTest()
        {
            var calc = new Calculator();
            var actual = calc.Divide(6, 2);
            Assert.AreEqual(3, actual);
        }

        [TestMethod]
        public void ZeroDivideTest()
        {
            var calc = new Calculator();
            var actual = calc.Divide(999999, 0);
            //Assert.IsNull(actual);
            Assert.AreEqual(999999, actual);
        }
    }
}
