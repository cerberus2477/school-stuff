﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pontracsos
{
	public enum PointState
	{
		Red,
		Blue,
		Neutral,
		Highlighted //lehetséges lépések
	}

	public static class State
	{
		public static Color ToColor(PointState state)
		{
			switch(state)
			{
				case PointState.Red:
					return Color.Red;
				case PointState.Blue:
					return Color.Blue;
				case PointState.Neutral:
					return Color.DarkGray;
				case PointState.Highlighted:
					return Color.YellowGreen;
				default:
					return default;
			}
		}
	}
}
