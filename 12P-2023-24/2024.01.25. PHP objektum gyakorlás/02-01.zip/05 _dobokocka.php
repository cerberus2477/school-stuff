<!-- Dobj „kockával” 100-at (hatos kocka), írd ki, listázd ki a dobott számokat, és hogy melyik számból hányat dobtál! Használj kocka osztályt!  -->

<?php
    class Kocka{
        protected $oldalak_szama;

        function __construct($oldalak_szama){
            $this->oldalak_szama = $oldalak_szama;
        }

        function dobas(){
           return random_int(1, $this->oldalak_szama);
        }
    }




    if($_SERVER['REQUEST_METHOD'] !== 'POST'){
        $uzenet = "Dobjon!";
    }else{
        $dobasok = [];
        $oldalak_szama = 6;
        $k = new Kocka($oldalak_szama);
        $uzenet = "";
        for ($i=0; $i < 100; $i++) { 
            array_push($dobasok, $k->dobas());
        }
        for ($i=1; $i <= $oldalak_szama; $i++) { 
            $uzenet = $uzenet . $i.": ".count(array_keys($dobasok, $i))."db<br>";
        }

                                            
        
    }

    ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5) Dobókocka</title>
</head>
<body>
<div>
        <h2>5) Dobókocka</h2>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
            <p>
                <input type="submit" value="Dobás">
            </p>
        </form>
        <h1><?php echo $uzenet ?></h1>
    </div>  

</body>
</html>