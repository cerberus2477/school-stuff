﻿using System;

namespace Eletjatek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EletjatekSzimulator eletszim = new EletjatekSzimulator(10, 10);
            bool run = true;
            //space lenyomására legyen run = !run;
            while (run)
            {
                eletszim.Run();
            }
        }
    }
}
