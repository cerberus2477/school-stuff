﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace kiralynok
{
    internal class Program
    {
        static int[] x = new int[100];

        static void Main(string[] args)
        {
            //7 esetén 8*8as lesz a sakktábla (0. index miatt)
            int db = 7;
            HelyKeres(db);
            Console.ReadKey();
        }

        static void HelyKeres(int n)
        {
            int i = 1;
            x[i] = 0;
            while (i >= 1 && i <=n) {
                if (VanJoEset(i, n))
                {
                    i++;
                    if (i<= n)
                    {
                        x[i] = 0;
                    }
                }
                else
                {
                    i--;
                }
            }
            bool ok = i > n;
            Kiir(ok, n);
        }

        static bool VanJoEset(int i, int n)
        {
            do
            {
                x[i]++;
            } while (RosszEset(i) && x[i] <= n);
            return x[i] <= n;
        }

        static bool RosszEset(int i)
        {
            int j = 1;
            while (j <i && x[i] != x[j] && Math.Abs(x[i] - x[j]) != i - j)
            {
                j++;
            }
            return j<i;
        }

        static void Kiir(bool ok, int n)
        {
            if (ok)
            {
                /*for (int i = 1; i < n; i++)
                {
                    Console.Write(x[i]+" | ");
                }*/
                Console.WriteLine("Egy megoldás:");
                Console.WriteLine(String.Join(" | ", x.Take(n+1)));

                //ábra
                Console.WriteLine("\n\nÁbra (x = királynő, _ = üres mező)");
                for (int i = 0; i <= n; i++)
                {
                    for (int j = 0; j <= n; j++)
                    {
                        if (x[i] == j)
                        {
                            Console.Write("x");
                        }
                        else
                        {
                            Console.Write("_");
                        }
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Nincs megoldás");
            }
        }
       
    }
}
