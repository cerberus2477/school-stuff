// npm install jsdom node-fetch
//hibák:
//ahol holtverseny van, ott nem írja az ország nevét. (eggyel arrébb olvas)
//az összesen sort is beolvassa
//valószynűleg nem írja felül az ugyanolyan nevű táblázatot

const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const { JSDOM } = require('jsdom');

const WIKI_URL = year => `https://hu.wikipedia.org/wiki/A_${year}._évi_nyári_olimpiai_játékok_éremtáblázata`;
const WIKI_URLbefore = year => `https://hu.wikipedia.org/wiki/Az_${year}._évi_nyári_olimpiai_játékok_éremtáblázata`;

// Ha még nincs létrehozva az 'ermek' mappa, akkor létrehozza
const folderPath = path.join(__dirname, 'ermek');
if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath);
}

//2000 előőt a link úgy kezdődik hogy "az" és nem "a"
const getWikiUrl = year => (year >= 2000 ? WIKI_URL(year) : WIKI_URLbefore(year));

// Az adott év adatainak lekérése és feldolgozása
const scrapeWiki = async (year) => {
    try {
        const response = await fetch(getWikiUrl(year), {
            method: 'GET',
            headers: new Headers({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
            })
        });

        if (!response.ok) {
            console.error(`HTTP hiba ${response.status} az ${WIKI_URL(year)} URL-en`);
            return [];
        }
        const html = await response.text();
        const dom = new JSDOM(html);
        const doc = dom.window.document;

        const table = doc.querySelector('table.wikitable');


        const rows = [];
        if (table) {
            const trs = table.querySelectorAll('tr');
            trs.forEach((tr, index) => {
                if (index >= 2) { //első két sos (fejlécek)
                    const cells = tr.querySelectorAll('th, td');
                    if (cells.length >= 4) {
                        const country = cells[1] ? cells[1].textContent.trim() : '';
                        const gold = cells[2] ? cells[2].textContent.trim() : '';
                        const silver = cells[3] ? cells[3].textContent.trim() : '';
                        const bronze = cells[4] ? cells[4].textContent.trim() : '';
                        rows.push([country, gold, silver, bronze, year]);
                    }
                }
            });
        }
        console.log(`${year} ✓`);
        return rows;

    } catch (error) {
        console.warn(`ERROR ${year} év: ${error.message}`);
        return [];
    }
};

(async () => {
    const olympicYears = [
        1896, 1900, 1904, 1908, 1912, 1920, 1924, 1928, 1932, 1936,
        1948, 1952, 1956, 1960, 1964, 1968, 1972, 1976, 1980, 1984,
        1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016, 2020, 2024
    ];

    const allRows = [];
    allRows.push(['orszag_neve', 'arany', 'ezust', 'bronz', 'ev']);

    for (const year of olympicYears) {
        const yearRows = await scrapeWiki(year);
        allRows.push(...yearRows);
    }

    const csvContent = allRows.map(row => row.join(';')).join('\n');
    const fileName = path.join(folderPath, 'olimpia-osszes.csv');
    fs.writeFileSync(fileName, csvContent);
    console.log(`${fileName} létrehozva`);
})();