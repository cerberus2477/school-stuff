<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP menü minta</title>
    <link rel="stylesheet" href="pelda1.css">
</head>
<body>
    <div class="keret">
        <div class="belso felso">Menüvezérelt fájlkiírás könyvtárból</div>
        <div class="belso bal">
            <?php
                $menuItems = [];
                $dir_name = "pages";

                if ($dir_o = opendir($dir_name)) {
                    while ($file = readdir($dir_o)) {
                        // .-tal kezdődő fileok kivételével
                        if (!is_dir($file) && !in_array($file, ['.'])) {
                            $menuItems[] = $file;
                        }
                    }
                    closedir($dir_o);

                    foreach ($menuItems as $x) {
                        $extension = strtolower(pathinfo($x, PATHINFO_EXTENSION));
                        if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                            echo "<a href='?p=$x'><img src='pages/$x' alt='$x'></a>";
                        } else {
                            echo "<a href='?p=$x'>$x</a>";
                        }
                    }
                }
                else{
                    echo "Nem tudtuk megnyitni a könyvtárat.";
                }
            ?>
        </div>
        <div class="belso jobb">
            <?php
            if (isset($_GET["p"])) {
                $selected = $_GET["p"];
                $file_name = "$dir_name/$selected";

                $extension = strtolower(pathinfo($x, PATHINFO_EXTENSION));
                if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                    echo "<img src='$file_name' alt='$file_name'>";
                }
                else{
                    include($display);
                }

            }
            ?>
        </div>
    </div>
</body>
</html>
