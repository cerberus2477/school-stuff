﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tilitoli {
	public partial class Tilitoli : Form {
		public Tilitoli() {
			InitializeComponent();
		}

		static int maxSor = 3, maxOszlop = 3;
		//static int magassag = 300, szelesseg = 300;
		static Button[,] gombok = new Button[maxOszlop, maxSor];
		static Random rnd = new Random();
		static int lyukx, lyuky;
		static int csere = 0;
		static int mp = 0;


		private void Form1_Load(object sender, EventArgs e) {
			
			//this.Width = szelesseg;
			//this.Height = magassag;

			generateBtns();
			Kever();
		}

		private void generateBtns() {

			gombok = new Button[maxOszlop, maxSor];
			int btnHeight = this.pnlGombok.Height / maxOszlop;
			int btnWidth = this.pnlGombok.Width / maxSor;
			Byte sorszam = 0;
			for(int i = 0; i < maxOszlop; i++) {
				for(int j = 0; j < maxSor; j++) {
					sorszam++;
					gombok[i, j] = new Button();
					gombok[i, j].Name = sorszam.ToString();
					gombok[i, j].Size = new System.Drawing.Size(btnWidth, btnHeight);
					gombok[i, j].Location = new System.Drawing.Point(i * btnWidth, j * btnHeight);
					gombok[i, j].FlatStyle = FlatStyle.Flat;
					gombok[i, j].ForeColor = Color.Black;
					gombok[i, j].Font = new Font(gombok[i, j].Font.Name, 30, FontStyle.Bold);
					gombok[i, j].Visible = false;
					pnlGombok.Controls.Add(gombok[i, j]);
					gombok[i, j].Click += new EventHandler(this.Kattint);
				}
			}
		}

		private void Kever() {
			Byte szam;
			int k;
			List<Byte> elhasznaltSzamok = new List<Byte>();
			for(int i = 0; i < maxOszlop; i++) {
				for(int j = 0; j < maxSor; j++) {
					do {
						szam = Convert.ToByte(rnd.Next(maxOszlop * maxSor));
						k = elhasznaltSzamok.IndexOf(szam);
					} while(k != -1);
					elhasznaltSzamok.Add(szam);
					gombok[i, j].Text = Convert.ToString(szam);
					if(szam == 0) {
						gombok[i, j].Visible = false;
						lyukx = i;
						lyuky = j;
					} else gombok[i, j].Visible = true;
				}
			}
		}

		private bool Lyukszomszed(Button gomb) {
			Button lyuk = gombok[lyukx, lyuky];
			//return ((gomb.Left == lyuk.Left) && (Math.Abs(gomb.Bottom - lyuk.Bottom) == gomb.Height)) || ((gomb.Top == lyuk.Top) && (Math.Abs(gomb.Left - lyuk.Left) == gomb.Width));
			  return ((gomb.Left == lyuk.Left) && (Math.Abs(gomb.Bottom - lyuk.Bottom) == gomb.Height)) || ((gomb.Top == lyuk.Top) && (Math.Abs(gomb.Left - lyuk.Left) == gomb.Width));
		}

		private void btnUj_Click(object sender, EventArgs e) {
			generateBtns();
		}

		private void Kattint(object sender, EventArgs e) {
			int seged;
			Button gomb = (sender as Button);
			if(Lyukszomszed(gomb)) {
				seged = (sender as Button).Left;
				gomb.Left = gombok[lyukx, lyuky].Left;
				gombok[lyukx, lyuky].Left = seged;
				seged = gomb.Top;
				gomb.Top = gombok[lyukx, lyuky].Top;
				gombok[lyukx, lyuky].Top = seged;

				csere++;
				lblCsere.Text = $"Csere: {csere}";
				if(Nyerte()) {
					MessageBox.Show($"Gratulálok, nyertél!\nA kirakás {mp} másodperc és {csere} csere alatt sikerült.");
					for(int i = 0; i < maxSor; i++) {
						for(int j = 0; j < maxOszlop; j++) {

						}
					}
				}
			}
		}

		private bool Nyerte() {
			return true;
		}
	}
}
