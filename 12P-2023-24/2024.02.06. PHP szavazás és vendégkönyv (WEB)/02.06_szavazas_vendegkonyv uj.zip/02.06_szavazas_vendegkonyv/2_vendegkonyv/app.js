const toggleForm = () => {
    document.getElementById("formContainer").classList.toggle("hide");
    document.getElementById("callToAction").classList.toggle("hide");
} 