﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace feladat06
{
    internal class Program
    {

        static void Main(string[] args)
        {
       
            using (StreamReader sr = new StreamReader("Város_madár.txt"))
            {
                //a
                int[] ij = Array.ConvertAll(sr.ReadLine().Split(), int.Parse);
                int[,] M = new int[ij[0], ij[1]];
                string txt = sr.ReadToEnd();

                for (int i = 0; i < ij[0]; i++)
                {
                    for (int i = 0; i < length; i++)
                    {

                    }
                }

                //b
            }

        }

    }

}