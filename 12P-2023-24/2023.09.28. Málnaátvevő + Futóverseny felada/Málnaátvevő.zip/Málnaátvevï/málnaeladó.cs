﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Málnaátvevő
{
    class málnaeladó
    {
        private string név;
        private int sorszám;
        private double mennyiség = 0;

        public málnaeladó(string mnév, int msorszám, double mmennyiség)
        {
            név = mnév;
            sorszám = msorszám;
            mennyiség = mmennyiség;
        }

        public málnaeladó(string mnév, int msorszám)
        {
            név = mnév;
            sorszám = msorszám;
        }

        public int Névhasonlít(string mnév)
        {
            return név.CompareTo(mnév);
        }

        public bool Számhasonlít(int szám)
        {
            return sorszám == szám;
        }

        public void Málnabe(double menny)
        {
            mennyiség += menny;
        }

        public int CompareTo(málnaeladó valaki)
        {
            int vissza;
            if (mennyiség > valaki.Mennyiség()) vissza = 1;
            else if (mennyiség < valaki.Mennyiség()) vissza = -1;
            else if (név.CompareTo(valaki.név) == 1) vissza = 1;
            else if (név.CompareTo(valaki.név) == -1) vissza = -1;
            else vissza = 0;

            /*if (mennyiség > valaki.Mennyiség()) vissza = 1;
            else if (mennyiség < valaki.Mennyiség()) vissza = -1;
            else vissza = név.CompareTo(valaki.név);*/

            return vissza;
        }

        public double Mennyiség()
        {
            return mennyiség;
        }

        public override string ToString()
        {
            return név + " " + Convert.ToString(sorszám) + " " + Convert.ToString(mennyiség);
        }
    }
}
