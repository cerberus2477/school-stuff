﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09._20_szek {
	class Terem {
		private Szek[,] szekek = new Szek[10, 10];
		
		public Terem() {
			for(int i = 0; i < 10; i++) {
				for(int j = 0; j < 10; j++) {
					szekek[i, j] = new Szek("ures");
				}
			}
		}

		public bool isFoglalt(int sor, int oszlop, string datum) {
			return szekek[sor, oszlop].isFoglalt(datum);
		}

		public bool tryLefoglal(int sor, int oszlop, string datum) {
			return szekek[sor, oszlop].tryLefoglal(datum);
		}

		public void ujSzek(int sor, int oszlop, bool parnazott, bool karfas, bool elotteHely) {
			szekek[sor, oszlop] = new Szek(parnazott, karfas, elotteHely);
		}

		public bool Parnazott(int sor, int oszlop) => szekek[sor, oszlop].getParnazott();
		public bool ElotteHely(int sor, int oszlop) => szekek[sor, oszlop].getElotteHely();
		public bool Karfas(int sor, int oszlop) => szekek[sor, oszlop].getKarfas();

		public string Teremfoglaltsag(string datum) {
			string r = "";
			for(int i = 0; i < 10; i++) {
				for(int j = 0; j < 10; j++) {
					if(szekek[i,j].isUres()) {
						r += "_";
					} else {
						if(szekek[i, j].isFoglalt(datum)) {
							r += "x";
						} else {
							r += "o";
						}
					}
					r += "\t";
				}
				r += "\n";
			}

			return r;
		}

		public bool isUres(int sor, int oszlop) => szekek[sor, oszlop].isUres();
	}
}
