<?php
 class Comment {
            public $name;
            public $text;
            public $time;
        
            public function __construct($name, $text, $time) {
                $this->name = $name;
                $this->text = $text;
                $this->time = $time;
            }
        
            public function displayText() {
                $html = '<article>\n';
                $html .= '\t<h3">' . $this->name . 'mondja:</h3>\n';
                $html .= '\t<blockquote>' . $this->text . '</blockquote>\n';
                $html .= '\t<p class="date"> ' . $this->time . '</p>\n';
                $html .= '\t</article>\n';
                return $html;
            }

            //fájlba mentéshez, sorszámot nem mentjük
            public function __toString(){
                return join(';', [$this->name, $this->text, $this->time]);
            }
        }
?>