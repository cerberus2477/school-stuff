var nrow = 8;
var ncell = 8;
var tt = new Array(nrow);
var newrow;
let playerX;


function init() {
    for (var i = 0; i < nrow; i++) {
        newrow = document.getElementById("palya").insertRow(i);
        tt[i] = new Array(ncell);
        for (var j = 0; j < ncell; j++) {
            tt[i][j] = newrow.insertCell(j);
        }
    }
    reset();
}

function reset() {
    playerX = true;

    for (var i = 0; i < nrow; i++) {
        for (var j = 0; j < ncell; j++) {
            tt[i][j].id = i * ncell + j;
            tt[i][j].className = "cell";  
            tt[i][j].innerHTML = " ";
            tt[i][j].onclick = function ()
                { 
                    cell_click(this); 
                }
        }
    }

    tt[nrow / 2 - 1][ncell / 2 - 1].innerHTML = "X";
    tt[nrow / 2][ncell / 2].innerHTML = "X";
    tt[nrow / 2 - 1][ncell / 2].innerHTML = "O";
    tt[nrow / 2][ncell / 2 - 1].innerHTML = "O";

    whose_turn();
}



//kijelőli a lehetséges mezőket, eldönti ki jön vagy vége van-e
function whose_turn(){
    Array.from(document.querySelectorAll('.valid')).forEach(
        (cell) => cell.classList.remove('valid')
      );

    let valid_count = 0;

    //következő játékossal ellenőrzés
    symbol = playerX ? "X" : "O";
    for (let x = 0; x < nrow; x++) {
        for (let y = 0; y < ncell; y++) {
            if (check_step(x, y, symbol)) {
                valid_count++;
            }
        }
    }

    //ha nem talált megoldást, megnézi hogy az előző játékos tud e lépni (ilyenkor kimaradna a soron levő)
    if (valid_count == 0) {
        playerX = !playerX;
        symbol = playerX ? "X" : "O";

        for (let x = 0; x < nrow; x++) {
            for (let y = 0; y < ncell; y++) {
                if (check_step(x, y, symbol)) {
                    valid_count++;
                }
            }
        }
    }

    //ha egyik játékos sem tud lépni, vége a játéknak
    if (valid_count == 0) {
        let res = window.confirm("A játék véget ért");
        if (res) {
            reset();
        }
    }

    document.getElementById("next-turn").innerHTML = `${playerX ? "X" : "O"} jön`;
    
}

function cell_click(obj) {
    console.log("aaa");
    console.log(obj);

    if(obj.classList.contains("valid")){
        symbol = playerX ? "X" : "O";
        let row = parseInt(obj.id / ncell);
        let column = obj.id % nrow;
        check_step(row, column, symbol, true);

        
        playerX = !playerX;
        obj.innerHTML = symbol;
    }

    //playerX = !playerX;

    whose_turn();
}





//leellenőrzi hogy lehetséges-e a lépés, ha do_flip akkor lép is
function check_step(row, column, symbol, do_flip=false) {
    let i, j, k, steps; 
    let othersymbol = symbol == "O" ? "X" : "O";

    
    // ellenőrzés felfelé
    i = row - 1;
    while (i >= 0 && tt[i][column].innerHTML == othersymbol) i--;
    if (i >= 0 && tt[i][column].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (j = i + 1; j < row; j++)
        tt[j][column].innerHTML = symbol;
    }
    // ellenőrzés lefelé
    i = row + 1;
    while (i < nrow && tt[i][column].innerHTML == othersymbol) i++;
    if (i < nrow && tt[i][column].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (j = row; j < i; j++)
            tt[j][column].innerHTML = symbol;
    }

    // ellenőrzés balra
    j = column - 1;
    while (j >= 0 && tt[row][j].innerHTML == othersymbol) j--;
    if (j >= 0 && tt[row][j].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (k = j + 1; k < column; k++)
            tt[row][k].innerHTML = symbol;
    }
    // ellenőrzés jobbra
    j = column + 1;
    while (j < ncell && tt[row][j].innerHTML == othersymbol) j++;
    if (j < ncell && tt[row][j].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}

        for (k = column; k < j; k++)
            tt[row][k].innerHTML = symbol;
    }



    // ellenőrzés balra fel
    steps = 1;
    while (row-steps >= 0 && column-steps>=0 && tt[row-steps][column-steps].innerHTML == othersymbol) steps++;
    if (row-steps >= 0 && column-steps >= 0 && tt[row-steps][column-steps].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            tt[row-a][column-a].innerHTML = symbol;  
    }

    // ellenőrzés balra le
    steps = 1;
    while (row+steps < nrow && column-steps>=0 && tt[row+steps][column-steps].innerHTML == othersymbol) steps++;
    if (row+steps < nrow && column-steps >= 0 && tt[row+steps][column-steps].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            tt[row+a][column-a].innerHTML = symbol;  
    }

    // ellenőrzés jobbra fel
    steps = 1;
    while (row-steps >= nrow && column-steps>=0 && tt[row+steps][column-steps].innerHTML == othersymbol) steps++;
    if (row+steps < nrow && column-steps >= 0 && tt[row+steps][column-steps].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            tt[row+a][column-a].innerHTML = symbol;  
    }

    // ellenőrzés jobbra le
    steps = 1;
    while (row+steps < nrow && column+steps < ncell && tt[row+steps][column+steps].innerHTML == othersymbol) steps++;
    if (row+steps < nrow && column+steps < ncell && tt[row+steps][column+steps].innerHTML == symbol) {
        if (!do_flip) {tt[row][column].classList.add("valid"); return true;}
        
        for (let a = 0; a < steps; a++) 
            tt[row+a][column+a].innerHTML = symbol;  
    }


    //a nyolc irányból egyik sem jó tehát nem valid lépés ez a cella
    if (!do_flip) return false;
}