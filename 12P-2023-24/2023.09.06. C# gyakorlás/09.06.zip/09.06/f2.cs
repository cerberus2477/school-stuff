﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladat02 
{
	class Program
	{

		static void Main(string[] args) 
		{
			int inputNum = 0;
			List<int> numbers = new List<int>();

			Console.WriteLine("Adjon meg maximum 5 jegyű pozitív számokat! 0 íásával fejezheti be az adatok bekérését.");
			do {
				inputNum = int.Parse(Console.ReadLine());
				if(inputNum != 0) {
					numbers.Add(inputNum);
				}
			} while(inputNum != 0);

			Console.WriteLine($"{numbers.Count(num => num.ToString().Length == 1)} db 1 jegyű szám van.");
			Console.WriteLine($"{numbers.Count(num => num.ToString().Length == 2)} db 2 jegyű szám van.");
			Console.WriteLine($"{numbers.Count(num => num.ToString().Length == 3)} db 3 jegyű szám van.");
			Console.WriteLine($"{numbers.Count(num => num.ToString().Length == 4)} db 4 jegyű szám van.");
			Console.WriteLine($"{numbers.Count(num => num.ToString().Length == 5)} db 5 jegyű szám van.");

			int x;
			if(numbers.Count(num => num.ToString().EndsWith("0")) == numbers.Count(num => num.ToString().EndsWith("9"))) {
				Console.WriteLine("Ugyanannyi 9-re végződő szám volt mint 1-re végződő.");
			} else {
				x = numbers.Count(num => num.ToString().EndsWith("0")) > numbers.Count(num => num.ToString().EndsWith("9")) ? 0 : 9;
				Console.WriteLine($"\n{x}-ra/re végződött több szám.");
			}
		}
	}
}
