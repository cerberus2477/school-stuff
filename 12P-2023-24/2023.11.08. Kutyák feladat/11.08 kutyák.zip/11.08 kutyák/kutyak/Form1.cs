﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kutyak
{
    public partial class frmKutyak : Form
    {
        static Statisztika stat = new Statisztika();

        public frmKutyak()
        {
            InitializeComponent();
        }

        private void frmKutyak_Load(object sender, EventArgs e)
        {

        }

        private void kutyákSzáma5FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.countKutyanev();
        }

        private void átlagéletkor6FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.avgEletkor();
        }

        private void legidősebb7FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.legidosebb();
        }

        private void fajtánként8FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.jan10();
        }

        private void legterheltebb9FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.legterheltebbNap();
        }

        private void mentés10FeladatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMegoldasok.Text = stat.mentes();
        }
    }
}
