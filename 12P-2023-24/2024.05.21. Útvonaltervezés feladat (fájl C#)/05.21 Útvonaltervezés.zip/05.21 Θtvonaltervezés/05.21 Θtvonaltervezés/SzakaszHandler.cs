﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace _05._21_Útvonaltervezés
{
	internal class SzakaszHandler
	{
		public List<Szakasz> szakaszok;
		public static int p1;
		public static int p2;
		public int uzemanyagar;
		public double auto_fogy; 

		public SzakaszHandler(string filePath, int uzemanyagar, double auto_fogy, int _p1, int _p2)
		{
			szakaszok = ReadFile(filePath);
			p1 = _p1;
			p2 = _p2;
		}


		public static List<Szakasz> ReadFile(string filePath)
		{
			List<Szakasz> szakaszok = new List<Szakasz>();

			string[] lines = System.IO.File.ReadAllLines(filePath);

			for(int i = 1; i < lines.Length; i++)
			{
				string line = lines[i];
				string[] parts = line.Trim().Split('\t');
				szakaszok.Add(new Szakasz(
				int.Parse(parts[0]), int.Parse(parts[1]), int.Parse(parts[2]),int.Parse(parts[3]), double.Parse(parts[4]), p1, p2 ));
			}

			return szakaszok;
		}

	

		public void Dijkstra(int suly) //1=legkevesebb, 2=legrövidebb (tav), 3=legolcsobb (uzemananyagar + utdij)
		{
			Dictionary<int, int> ar = new Dictionary<int, int>();
			Dictionary<int, int> elozo = new Dictionary<int, int>();
			List<int> pontok = Enumerable.Range(1, 1000).ToList();


			ar[p1] = 0;

			//amit már bejártunk azt kiszedjük pontokból
			while(pontok.Count != 0)
			{
				var legkisebb = pontok[0];
				pontok.Remove(legkisebb);

				//
				if(legkisebb == p2)
				{
					var ut = new List<int>();
					while(elozo.ContainsKey(legkisebb))
					{
						ut.Add(legkisebb);
						legkisebb = elozo[legkisebb];
					}
					ut.Add(p1);
					ut.Reverse();
					/*Console.WriteLine($"Az út: {string.Join(", ", ut)}");
					Console.WriteLine($"\tÖssztávolság: {tav}");
					Console.WriteLine($"\Útdíj: {utdij}");
					Console.WriteLine($"\tElfogyasztott üzemagnyag: {hasznalt_uzemanyag}");
                    Console.WriteLine("------------------------------");
					Console.WriteLine($"\tÖsszköltség: {osszkoltseg}"); //utdij + hasznalt_uzemanyag * uzemanyagar / 100*/
				}

				if(ar[legkisebb] == int.MaxValue)
				{
					break;
				}

				foreach(var szakasz in szakaszok)
				{
					int szomszed = -1;
					if(szakasz.pontok[0] == legkisebb)
					{
						szomszed = szakasz.pontok[1];
					}
					else if(szakasz.pontok[1] == legkisebb)
					{
						szomszed = szakasz.pontok[0];
					}

					if(szomszed != -1)
					{
						int seged = ar[legkisebb] + szakasz.tav;
						if(seged < ar[szomszed])
						{
							ar[szomszed] = seged;
							elozo[szomszed] = legkisebb;
						}
					}
				}
			}
			Console.WriteLine("Nincs ilyen út.");
		}



		public void Dijkstra(int suly)
		{
			Dictionary<int, int> ar = new Dictionary<int, int>();
			Dictionary<int, int> elozo = new Dictionary<int, int>();
			List<int> pontok = Enumerable.Range(1, 1000).ToList();

			foreach(var p in pontok)
			{
				ar[p] = int.MaxValue;
			}
			ar[p1] = 0;

			while(pontok.Count != 0)
			{
				pontok.Sort((x, y) => ar[x] - ar[y]);
				var legkisebb = pontok[0];
				pontok.Remove(legkisebb);

				if(legkisebb == p2)
				{
					var ut = new List<int>();
					while(elozo.ContainsKey(legkisebb))
					{
						ut.Add(legkisebb);
						legkisebb = elozo[legkisebb];
					}
					ut.Add(p1);
					ut.Reverse();
					PrintRoute(ut, suly);
					return;
				}

				if(ar[legkisebb] == int.MaxValue)
				{
					break;
				}

				foreach(var szakasz in szakaszok)
				{
					int szomszed = -1;
					if(szakasz.pontok[0] == legkisebb)
					{
						szomszed = szakasz.pontok[1];
					}
					else if(szakasz.pontok[1] == legkisebb)
					{
						szomszed = szakasz.pontok[0];
					}

					if(szomszed != -1)
					{
						int sulyertek = 0;
						switch(suly)
						{
							case 1:
								sulyertek = 1;
								break;
							case 2:
								sulyertek = szakasz.tav;
								break;
							case 3:
								sulyertek = (int)(szakasz.fogyasztas * uzemanyagar / 100) + szakasz.utdij;
								break;
						}

						int seged = ar[legkisebb] + sulyertek;
						if(seged < ar[szomszed])
						{
							ar[szomszed] = seged;
							elozo[szomszed] = legkisebb;
						}
					}
				}
			}
			Console.WriteLine("Nincs elérhető útvonal.");
		}

		private void PrintRoute(List<int> ut, int suly)
		{
			Console.WriteLine($"Az út: {string.Join(" -> ", ut)}");

			int tav = 0;
			int utdij = 0;
			double hasznalt_uzemanyag = 0;

			for(int i = 0; i < ut.Count - 1; i++)
			{
				var szakasz = szakaszok.FirstOrDefault(s => (s.pontok[0] == ut[i] && s.pontok[1] == ut[i + 1]) || (s.pontok[1] == ut[i] && s.pontok[0] == ut[i + 1]));
				if(szakasz != null)
				{
					tav += szakasz.tav;
					utdij += szakasz.utdij;
					hasznalt_uzemanyag += szakasz.fogyasztas;
				}
			}

			double uzemanyagkoltseg = hasznalt_uzemanyag * uzemanyagar / 100;
			double osszkoltseg = uzemanyagkoltseg + utdij;

			Console.WriteLine($"\tÖssztávolság: {tav}");
			Console.WriteLine($"\tÚtdíj: {utdij}");
			Console.WriteLine($"\tElfogyasztott üzemanyag: {hasznalt_uzemanyag}");
			Console.WriteLine($"\tÜzemanyagköltség: {uzemanyagkoltseg}");
			Console.WriteLine($"\tÖsszköltség: {osszkoltseg}");
		}
	}




}
