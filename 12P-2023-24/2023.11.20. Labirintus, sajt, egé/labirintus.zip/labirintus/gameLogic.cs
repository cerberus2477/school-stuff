﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace labirintus
{
    internal class gameLogic
    {
        Field[,] fields;
        public void createFields(string filename, Panel pnl)
        {
            pnl.Controls.Clear();
            pnl.Refresh();

            StreamReader reader = new StreamReader(filename);
            
            int[] dimensions = Array.ConvertAll(reader.ReadLine().Split(','), int.Parse);

            int fwidth = 40;
            int fheight = 40;

            fields = new Field[dimensions[0], dimensions[1]];
            List<string> values = reader.ReadToEnd().Split(new char[] {'\n', ',', '\r'}).ToList();
            values.RemoveAll(v => v == "");

            for (int j = 0; j < dimensions[1]; j++)
            {
                for (int i = 0; i < dimensions[1]; i++)
                {
                    fields[i, j] = new Field();
                    fields[i, j].Size = new Size(fwidth, fheight);
                    fields[i, j].Location = new Point(i * fwidth, j * fheight);
                    fields[i, j].isWall = values.First() == "0";
                    values.RemoveAt(0);

                    //fields[i, j].X = i;s
                    //fields[i, j].Y = j;

                    pnl.Controls.Add(fields[i, j]);
                }
            }
        }


        /*private void newGame()
        {
            // Clear the values in each cells
            foreach (var cell in fields)
            {
                cell.currentValue = 0;
            }

            // This method will be called recursively 
            // until it finds suitable values for each cells
            findNextValue(0, -1);
        }


        //BACKTRACK ÉS REKURZÍV
        //próbálkoztam c:
        private bool findNextValue(int i, int j)
        {
            // i, növelése a sorban a következő cellára, majd a következő sor első cellájára
            if (++j > 8)
            {
                j = 0;

                //kilépés ha vége a sornak
                if (++i > 8)
                    return true;
            }

            int rndNum = 0;
            List<int> possibleNums = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //addig keres random számot amíg jó nem lesz és a következőre cellára lép majd arra is keres megoldást
            do
            {
                //ha már nincs más lehetőség (nincs több a possibleNums listában) visszalép 
                if (possibleNums.Count == 0)
                {
                    fields[i, j].currentValue = 0;
                    return false;
                }

                //random számot választ a maradék értékek (possibleNums) közül
                rndNum = possibleNums[rnd.Next(0, possibleNums.Count)];
                fields[i, j].Solution = rndNum;

                // törlés
                possibleNums.Remove(rndNum);
            }
            while (!isValidCell(rndNum, i, j) || !findNextValue(i, j));

            //cells[i, j].Value = value;

            return true;
        }


        private bool isValidCell(int value, int x, int y)
        {
            for (int i = 0; i < 9; i++)
            {
                // függőleges
                if (i != y && fields[x, i].Value == value)
                    return false;

                // vizszintes
                if (i != x && fields[i, y].Value == value)
                    return false;
            }

            // kockaban
            for (int i = x - (x % 3); i < x - (x % 3) + 3; i++)
            {
                for (int j = y - (y % 3); j < y - (y % 3) + 3; j++)
                {
                    if (i != x && j != y && fields[i, j].Value == value)
                        return false;
                }
            }

            return true;
        }*/


    }
}
