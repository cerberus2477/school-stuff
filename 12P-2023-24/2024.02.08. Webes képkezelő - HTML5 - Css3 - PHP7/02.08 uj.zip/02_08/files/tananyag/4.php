<h2>Referenciák</h2>

Ha valamilyen szolgáltatást (pl. weblapkészítést) el akarunk adni, akkor jó, 
ha be tudjuk mutatni korábbi munkáinkat. Ezek az úgynevezett referenciák, és
erre szolgál az ezzel azonos nevű menüpont.<br><br>

Fentiek fényében ez a jelenlegi, "Komoly weboldal" tehát nyilván nem lenne jó
referencia, hiszen meglehetősen egyszerű és ódivatú dizájnnal rendelkezik. :P<br><br>

A PHP-val készülő menük bemutatásához azonban valószínűleg megfelel ;)