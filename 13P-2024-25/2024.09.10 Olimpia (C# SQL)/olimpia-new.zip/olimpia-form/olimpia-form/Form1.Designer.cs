﻿namespace olimpia_form
{
    partial class frmOlimpia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOlimpia));
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.btn1 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn6 = new System.Windows.Forms.Button();
			this.btn7 = new System.Windows.Forms.Button();
			this.tbQuery = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.btnRun = new System.Windows.Forms.Button();
			this.dgvResult = new System.Windows.Forms.DataGridView();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.btnConnect = new System.Windows.Forms.Button();
			this.lblConnState = new System.Windows.Forms.Label();
			this.lblDBname = new System.Windows.Forms.Label();
			this.tbDBname = new System.Windows.Forms.TextBox();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnCountries = new System.Windows.Forms.Button();
			this.btnMedals = new System.Windows.Forms.Button();
			this.btnMedals_won = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.flowLayoutPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
			this.panel1.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(12, 12);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(658, 97);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = resources.GetString("textBox1.Text");
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this.btn1);
			this.flowLayoutPanel1.Controls.Add(this.btn2);
			this.flowLayoutPanel1.Controls.Add(this.btn3);
			this.flowLayoutPanel1.Controls.Add(this.btn4);
			this.flowLayoutPanel1.Controls.Add(this.btn5);
			this.flowLayoutPanel1.Controls.Add(this.btn6);
			this.flowLayoutPanel1.Controls.Add(this.btn7);
			this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 161);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(572, 36);
			this.flowLayoutPanel1.TabIndex = 1;
			// 
			// btn1
			// 
			this.btn1.Location = new System.Drawing.Point(3, 3);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(75, 23);
			this.btn1.TabIndex = 0;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = true;
			//this.btn1.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn2
			// 
			this.btn2.Location = new System.Drawing.Point(84, 3);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(75, 23);
			this.btn2.TabIndex = 1;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = true;
			// 
			// btn3
			// 
			this.btn3.Location = new System.Drawing.Point(165, 3);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(75, 23);
			this.btn3.TabIndex = 2;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = true;
			// 
			// btn4
			// 
			this.btn4.Location = new System.Drawing.Point(246, 3);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(75, 23);
			this.btn4.TabIndex = 3;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = true;
			// 
			// btn5
			// 
			this.btn5.Location = new System.Drawing.Point(327, 3);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(75, 23);
			this.btn5.TabIndex = 4;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = true;
			// 
			// btn6
			// 
			this.btn6.Location = new System.Drawing.Point(408, 3);
			this.btn6.Name = "btn6";
			this.btn6.Size = new System.Drawing.Size(75, 23);
			this.btn6.TabIndex = 5;
			this.btn6.Text = "6";
			this.btn6.UseVisualStyleBackColor = true;
			// 
			// btn7
			// 
			this.btn7.Location = new System.Drawing.Point(489, 3);
			this.btn7.Name = "btn7";
			this.btn7.Size = new System.Drawing.Size(75, 23);
			this.btn7.TabIndex = 6;
			this.btn7.Text = "7";
			this.btn7.UseVisualStyleBackColor = true;
			// 
			// tbQuery
			// 
			this.tbQuery.Location = new System.Drawing.Point(15, 226);
			this.tbQuery.Multiline = true;
			this.tbQuery.Name = "tbQuery";
			this.tbQuery.Size = new System.Drawing.Size(658, 175);
			this.tbQuery.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 210);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(92, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Lekérdezés (SQL)";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 431);
			this.label2.Name = "label2";
			this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.label2.Size = new System.Drawing.Size(54, 13);
			this.label2.TabIndex = 5;
			this.label2.Text = "Eredmény";
			// 
			// btnRun
			// 
			this.btnRun.Location = new System.Drawing.Point(537, 407);
			this.btnRun.Name = "btnRun";
			this.btnRun.Size = new System.Drawing.Size(133, 23);
			this.btnRun.TabIndex = 6;
			this.btnRun.Text = "Futtatás";
			this.btnRun.UseVisualStyleBackColor = true;
			this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
			// 
			// dgvResult
			// 
			this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvResult.Location = new System.Drawing.Point(15, 447);
			this.dgvResult.Name = "dgvResult";
			this.dgvResult.Size = new System.Drawing.Size(655, 188);
			this.dgvResult.TabIndex = 7;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.btnConnect);
			this.panel1.Controls.Add(this.lblConnState);
			this.panel1.Controls.Add(this.lblDBname);
			this.panel1.Controls.Add(this.tbDBname);
			this.panel1.Location = new System.Drawing.Point(707, 28);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(235, 137);
			this.panel1.TabIndex = 8;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(3, 104);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(229, 13);
			this.label3.TabIndex = 13;
			this.label3.Text = "Az olympics adatbázis Tokodi Mihály készítette";
			// 
			// btnConnect
			// 
			this.btnConnect.Location = new System.Drawing.Point(56, 74);
			this.btnConnect.Name = "btnConnect";
			this.btnConnect.Size = new System.Drawing.Size(106, 23);
			this.btnConnect.TabIndex = 12;
			this.btnConnect.Text = "Újracsatlakozás";
			this.btnConnect.UseVisualStyleBackColor = true;
			this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
			// 
			// lblConnState
			// 
			this.lblConnState.AutoSize = true;
			this.lblConnState.Location = new System.Drawing.Point(22, 43);
			this.lblConnState.Name = "lblConnState";
			this.lblConnState.Size = new System.Drawing.Size(0, 13);
			this.lblConnState.TabIndex = 11;
			// 
			// lblDBname
			// 
			this.lblDBname.AutoSize = true;
			this.lblDBname.Location = new System.Drawing.Point(11, 17);
			this.lblDBname.Name = "lblDBname";
			this.lblDBname.Size = new System.Drawing.Size(80, 13);
			this.lblDBname.TabIndex = 10;
			this.lblDBname.Text = "Adatbázis neve";
			// 
			// tbDBname
			// 
			this.tbDBname.Location = new System.Drawing.Point(97, 14);
			this.tbDBname.Name = "tbDBname";
			this.tbDBname.Size = new System.Drawing.Size(100, 20);
			this.tbDBname.TabIndex = 9;
			this.tbDBname.Text = "olympics";
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this.textBox2);
			this.flowLayoutPanel2.Controls.Add(this.btnCountries);
			this.flowLayoutPanel2.Controls.Add(this.btnMedals);
			this.flowLayoutPanel2.Controls.Add(this.btnMedals_won);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(12, 122);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(572, 36);
			this.flowLayoutPanel2.TabIndex = 7;
			// 
			// btnCountries
			// 
			this.btnCountries.Location = new System.Drawing.Point(133, 3);
			this.btnCountries.Name = "btnCountries";
			this.btnCountries.Size = new System.Drawing.Size(89, 23);
			this.btnCountries.TabIndex = 0;
			this.btnCountries.Text = "countries tábla";
			this.btnCountries.UseVisualStyleBackColor = true;
			this.btnCountries.Click += new System.EventHandler(this.btnCountries_Click);
			// 
			// btnMedals
			// 
			this.btnMedals.Location = new System.Drawing.Point(228, 3);
			this.btnMedals.Name = "btnMedals";
			this.btnMedals.Size = new System.Drawing.Size(95, 23);
			this.btnMedals.TabIndex = 1;
			this.btnMedals.Text = "medals tábla";
			this.btnMedals.UseVisualStyleBackColor = true;
			this.btnMedals.Click += new System.EventHandler(this.btnMedals_Click);
			// 
			// btnMedals_won
			// 
			this.btnMedals_won.Location = new System.Drawing.Point(329, 3);
			this.btnMedals_won.Name = "btnMedals_won";
			this.btnMedals_won.Size = new System.Drawing.Size(113, 23);
			this.btnMedals_won.TabIndex = 2;
			this.btnMedals_won.Text = "medals_won tábla";
			this.btnMedals_won.UseVisualStyleBackColor = true;
			this.btnMedals_won.Click += new System.EventHandler(this.btnMedals_won_Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(3, 3);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(124, 20);
			this.textBox2.TabIndex = 3;
			this.textBox2.Text = "Az adatbázis szerkezete";
			// 
			// frmOlimpia
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(985, 647);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.dgvResult);
			this.Controls.Add(this.btnRun);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbQuery);
			this.Controls.Add(this.flowLayoutPanel1);
			this.Controls.Add(this.flowLayoutPanel2);
			this.Controls.Add(this.textBox1);
			this.Name = "frmOlimpia";
			this.Text = "Olimpia";
			this.flowLayoutPanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox tbQuery;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btnRun;
		private System.Windows.Forms.DataGridView dgvResult;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnConnect;
		private System.Windows.Forms.Label lblConnState;
		private System.Windows.Forms.Label lblDBname;
		private System.Windows.Forms.TextBox tbDBname;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private System.Windows.Forms.Button btnCountries;
		private System.Windows.Forms.Button btnMedals;
		private System.Windows.Forms.Button btnMedals_won;
		private System.Windows.Forms.TextBox textBox2;
	}
}

