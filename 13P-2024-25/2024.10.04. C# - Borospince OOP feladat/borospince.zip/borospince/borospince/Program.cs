﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace borospince
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //TESZTELÉSI PÉLDÁK A DOKSIBÓL

            try
            {
                Bor bor1 = new Bor("Tokaji aszu", 2017, 13.5);
                Bor bor2 = new Bor("Gyanus kinezetu kannasbor", 2010);
                Bor bor3 = new Bor("ToKaJi AsZu", 2015, 13.8);
                Bor bor4 = new Bor("Chardonnay", 2019, 13.0);

                bor2.Fajta = "Egri bikaver";
                bor2.Evjarat = 2013;
                bor2.Alkoholtartalom = 12.0;

                Console.WriteLine($"{bor2.Fajta}, {bor2.Evjarat}, {bor2.Alkoholtartalom}"); //Egri bikaver, 2013, 12.0
                Console.WriteLine(bor1.ToString()); // 'Tokaji aszu (evjarat: 2017), melynek alkoholtartalma: 13.5%
                Console.WriteLine(bor1 == new Bor("TOKAJI ASZU", 2017, 13.5)); //True
                Console.WriteLine(bor1 == bor2); //False
               // Console.WriteLine(bor1.Equals("Hibas tipusu parameter!")); //False

                Szekreny szekreny1 = new Szekreny();
                Szekreny szekreny2 = new Szekreny();
                szekreny1.AddBor(bor1);
                szekreny1.AddBor(bor2);
                szekreny1.AddBor(bor3);
                szekreny2.AddBor(bor4);

                Szekreny szekreny3 = szekreny1 + szekreny2;


                Console.WriteLine();
                Console.WriteLine(szekreny3.GetBor(0).ToString()); // 'Tokaji aszu (evjarat: 2017), melynek alkoholtartalma: 13.5%
                Console.WriteLine(szekreny3.GetBor(3).ToString()); // 'Chardonnay (evjarat: 2019), melynek alkoholtartalma: 13.0%'
                Console.WriteLine(szekreny3.AtlagAlkoholtartalom()); // 13.075

                szekreny2.Megisszak(bor4);
                Console.WriteLine();
                Console.WriteLine(DictionaryToString(szekreny2.Statisztika())); // []
                Console.WriteLine(DictionaryToString(szekreny3.Statisztika())); // ['tokaji aszu': 2, 'egri bikaver': 1, 'chardonnay': 1]
                Console.WriteLine(szekreny2.ToString()); //Ez egy ures szekreny
                Console.WriteLine(szekreny3.ToString()); //2 tokaji aszu, 1 egri bikaver, 1 chardonnay

                Console.ReadLine();
            }

            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"EXCEPTION\nmessage: {e.Message}");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadLine();
            }
          
        }

        //for debugging
        public static string DictionaryToString(Dictionary<string, int> dict)
        {
             return "[" + string.Join(", ", dict.Select(kvp => $"'{kvp.Key}': {kvp.Value}")) + "]";
        }
    }
}
