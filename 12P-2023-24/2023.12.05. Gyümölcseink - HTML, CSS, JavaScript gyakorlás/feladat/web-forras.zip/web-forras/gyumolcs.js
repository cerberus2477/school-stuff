class gyumi {
    constructor(magyar, url, kep) {
        this.fajMagyar = magyar;
        this.wikiUrl = url;
        this.kepFajl = kep;
    }
}

const gyum = [];
gyum['alma'] = new gyumi("Alma", "https://hu.wikipedia.org/wiki/Alma_(n%C3%B6v%C3%A9nynemzets%C3%A9g)", "alma.jpg");
gyum['korte'] = new gyumi("Körte", "https://hu.wikipedia.org/wiki/K%C3%B6rte", "korte.jpg");
gyum['naspolya'] = new gyumi("Naspolya", "https://hu.wikipedia.org/wiki/Naspolya", "naspolya.jpg");
gyum['birsalma'] = new gyumi("Birsalma", "https://hu.wikipedia.org/wiki/Birs", "birsalma.jpg");
gyum['oszibarack'] = new gyumi("Őszibarack", "https://hu.wikipedia.org/wiki/%C5%90szibarack#Nektarin,_vagy_kopasz_barack", "oszibarack.jpg");
gyum['sargabarack'] = new gyumi("Sárgabarack", "https://hu.wikipedia.org/wiki/Kajszibarack", "sargabarack.jpg");
gyum['nektarin'] = new gyumi("Nektarin", "https://hu.wikipedia.org/wiki/%C5%90szibarack#Nektarin,_vagy_kopasz_barack", "nektarin.jpg");
gyum['szilva'] = new gyumi("Szilva", "https://hu.wikipedia.org/wiki/Nemes_szilva", "szilva.jpg");
gyum['cseresznye'] = new gyumi("Cseresznye", "https://hu.wikipedia.org/wiki/Cseresznye", "cseresznye.jpg");
gyum['meggy'] = new gyumi("Meggy", "https://hu.wikipedia.org/wiki/Meggy", "meggy.jpg");
gyum['szolo'] = new gyumi("Szőlő", "https://hu.wikipedia.org/wiki/Sz%C5%91l%C5%91", "szolo.jpg")

function gyummet(gy) {
    document.getElementById('sugo').style.display = 'none';
    document.getElementById('gyURL').href = gyum[gy].wikiUrl;
    document.getElementById('gyURL').alt = gyum[gy].fajMagyar + " képe";
    document.getElementById('gyURL').title = gyum[gy].fajMagyar + " Wikipédia oldala";
    document.getElementById('gyKep').src = gyum[gy].kepFajl;
    document.getElementById('gyNevek').innerHTML = "<b>" + gyum[gy].fajMagyar + "</b>";
    if (gyum[gy].egyebNevek == null) {
        document.getElementById('gyNevek').innerHTML += "<br>Egyéb elnevezés(ek):<br>" + gyum[hal].gyNevek;
    }
}