const tovabb = () => {
    let t = document.getElementById("tovabbi");
    t.classList.toggle("visible");

    let b = document.getElementById("tovabb_btn")
    let b_v = b.getAttribute("value");
    if (b_v == "Olvasson tovább...") {
        b.setAttribute("value", "Elrejtés")
    } else {
        b.setAttribute("value", "Olvasson tovább...")
    }
}