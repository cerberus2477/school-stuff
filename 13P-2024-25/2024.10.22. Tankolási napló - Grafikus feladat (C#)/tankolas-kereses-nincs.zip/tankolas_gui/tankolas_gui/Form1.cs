﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tankolas_gui
{
    public partial class frm_tankolas : Form
    {
        public static bool needsSave = false;

        public frm_tankolas()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_licensePlate.Text))
            {
                MessageBox.Show("Kérem töltse ki a rendszám mezőt.", "Hiányos adatok", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else {
                Tankolas tankolas = new Tankolas(input_date.Value, tb_licensePlate.Text, input_km.Value, input_litres.Value);
                tankolas.AddToDgv(dgv_display);
                needsSave = true; //vannak adataink a táblázatban, és még nincsenek exportálva
                tb_licensePlate.Clear();
                input_km.Value = input_km.Minimum;
                input_litres.Value = input_litres.Minimum;
                input_date.Value = DateTime.Now;
            }
        }

        private void btn_import_Click(object sender, EventArgs e)
        {
            //ha van már adat a táblázatban ami nincs exportálva, figyelmeztetjük a felhasználót hogy ha importál fájlból, a meglévő adatokat elveszti.
            if (needsSave) 
            {
                DialogResult result = MessageBox.Show(
                    "A táblázat már tartalmaz adatokat. Ha továbbhalad, az adatok elvesznek. Szeretne exportálni a meglévő adatokat az új adatok importálás előtt?\n\n(Igen = Exportálás majd importálás, Nem = csak importálás)",
                    "Figyelem",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button1);

                if (result == DialogResult.Yes)
                {
                    btn_export_Click(sender, e);
                    PerformImport();
                }
                else if (result == DialogResult.No)
                {
                    PerformImport();
                }
            }
            else
            {
                PerformImport(); 
            }
        }

        
        private void PerformImport()
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                openFileDialog.Title = "Importálás";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    //a továbbiakban látható lesz, hogy adatokat importáltunk az adott fájlból.
                    lbl_importedFile.Text = $"A tábla a {filePath} fájl adataiból került feltöltésre.";

                    string[] lines = System.IO.File.ReadAllLines(filePath);

                    dgv_display.Rows.Clear();
                    bool header = true;
                    foreach (string line in lines)
                    {
                        //fejléc kihagyása
                        if (header)
                        {
                            header = false; 
                            continue;
                        }
                        //sorok olvasása
                        string[] data = line.Split(';');
                        dgv_display.Rows.Add(data[0], data[1], data[2], data[3], data[4]);
                    }
                }
            }
            MessageBox.Show("Sikeres importálás.", "Importálás", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btn_export_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                saveFileDialog.FileName = $"tankolasok_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
                saveFileDialog.Title = "Exportálás";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;

                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(filePath))
                    {
                        //fejléc írása
                        file.WriteLine("Date;License Plate;Km;Litres;AvgFuelConsumption");

                        //sorok írása
                        foreach (DataGridViewRow row in dgv_display.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                string[] data = new string[dgv_display.Columns.Count];
                                for (int i = 0; i < dgv_display.Columns.Count; i++)
                                {
                                    data[i] = row.Cells[i].Value?.ToString();
                                }
                                file.WriteLine(string.Join(";", data));
                            }
                        }
                    }
                    needsSave = false;
                    MessageBox.Show("Sikeres exportálás.", "Exportálás", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


    }
}
