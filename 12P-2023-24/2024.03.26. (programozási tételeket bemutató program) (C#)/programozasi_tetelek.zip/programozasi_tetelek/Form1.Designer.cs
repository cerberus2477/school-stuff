﻿using System.Drawing;

namespace programozasi_tetelek
{
	partial class form_programozasi_tetelek
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.menu_main = new System.Windows.Forms.MenuStrip();
			this.menuitem_elemi = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_sorozat = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_eldontes = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_kivalasztas = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_kereses = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_megszamolas = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_maximum = new System.Windows.Forms.ToolStripMenuItem();
			this.menuitem_osszetett = new System.Windows.Forms.ToolStripMenuItem();
			this.másolásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.kiválogatásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.szétválogatásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.metszetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.egyesítésunioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.összefuttatásrendezettekUniojaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.lbl_title = new System.Windows.Forms.Label();
			this.tb_leiras = new System.Windows.Forms.TextBox();
			this.tb_kod = new System.Windows.Forms.TextBox();
			this.tb_feladat = new System.Windows.Forms.TextBox();
			this.tb_megoldas = new System.Windows.Forms.TextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.btn_adatok_fajlbol = new System.Windows.Forms.Button();
			this.tb_adatbe = new System.Windows.Forms.TextBox();
			this.tb_eredmeny = new System.Windows.Forms.TextBox();
			this.btn_mentes_fajlba = new System.Windows.Forms.Button();
			this.lbl_kod = new System.Windows.Forms.Label();
			this.lbl_feladat = new System.Windows.Forms.Label();
			this.lbl_adatbe = new System.Windows.Forms.Label();
			this.btn_run = new System.Windows.Forms.Button();
			this.lbl_megoldas = new System.Windows.Forms.Label();
			this.lbl_leiras = new System.Windows.Forms.Label();
			this.lbl_eredmeny = new System.Windows.Forms.Label();
			this.divider1 = new System.Windows.Forms.Panel();
			this.divider2 = new System.Windows.Forms.Panel();
			this.menu_main.SuspendLayout();
			this.SuspendLayout();
			// 
			// menu_main
			// 
			this.menu_main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuitem_elemi,
            this.menuitem_osszetett});
			this.menu_main.Location = new System.Drawing.Point(0, 0);
			this.menu_main.Name = "menu_main";
			this.menu_main.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
			this.menu_main.Size = new System.Drawing.Size(1331, 25);
			this.menu_main.TabIndex = 0;
			this.menu_main.Text = "Main menu";
			// 
			// menuitem_elemi
			// 
			this.menuitem_elemi.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuitem_sorozat,
            this.menuitem_eldontes,
            this.menuitem_kivalasztas,
            this.menuitem_kereses,
            this.menuitem_megszamolas,
            this.menuitem_maximum});
			this.menuitem_elemi.Name = "menuitem_elemi";
			this.menuitem_elemi.Size = new System.Drawing.Size(161, 19);
			this.menuitem_elemi.Text = "Elemi programozási tételek";
			// 
			// menuitem_sorozat
			// 
			this.menuitem_sorozat.Name = "menuitem_sorozat";
			this.menuitem_sorozat.Size = new System.Drawing.Size(184, 22);
			this.menuitem_sorozat.Text = "Sorozatszámítás";
			// 
			// menuitem_eldontes
			// 
			this.menuitem_eldontes.Name = "menuitem_eldontes";
			this.menuitem_eldontes.Size = new System.Drawing.Size(184, 22);
			this.menuitem_eldontes.Text = "Eldöntés";
			// 
			// menuitem_kivalasztas
			// 
			this.menuitem_kivalasztas.Name = "menuitem_kivalasztas";
			this.menuitem_kivalasztas.Size = new System.Drawing.Size(184, 22);
			this.menuitem_kivalasztas.Text = "Kiválasztás";
			// 
			// menuitem_kereses
			// 
			this.menuitem_kereses.Name = "menuitem_kereses";
			this.menuitem_kereses.Size = new System.Drawing.Size(184, 22);
			this.menuitem_kereses.Text = "(Lineáris) keresés";
			// 
			// menuitem_megszamolas
			// 
			this.menuitem_megszamolas.Name = "menuitem_megszamolas";
			this.menuitem_megszamolas.Size = new System.Drawing.Size(184, 22);
			this.menuitem_megszamolas.Text = "Megszámolás";
			// 
			// menuitem_maximum
			// 
			this.menuitem_maximum.Name = "menuitem_maximum";
			this.menuitem_maximum.Size = new System.Drawing.Size(184, 22);
			this.menuitem_maximum.Text = "Maximumkiválasztás";
			// 
			// menuitem_osszetett
			// 
			this.menuitem_osszetett.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.másolásToolStripMenuItem,
            this.kiválogatásToolStripMenuItem,
            this.szétválogatásToolStripMenuItem,
            this.metszetToolStripMenuItem,
            this.egyesítésunioToolStripMenuItem,
            this.összefuttatásrendezettekUniojaToolStripMenuItem});
			this.menuitem_osszetett.Name = "menuitem_osszetett";
			this.menuitem_osszetett.Size = new System.Drawing.Size(180, 19);
			this.menuitem_osszetett.Text = "Összetett programozási tételek";
			// 
			// másolásToolStripMenuItem
			// 
			this.másolásToolStripMenuItem.Name = "másolásToolStripMenuItem";
			this.másolásToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.másolásToolStripMenuItem.Text = "Másolás";
			// 
			// kiválogatásToolStripMenuItem
			// 
			this.kiválogatásToolStripMenuItem.Name = "kiválogatásToolStripMenuItem";
			this.kiválogatásToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.kiválogatásToolStripMenuItem.Text = "Kiválogatás";
			// 
			// szétválogatásToolStripMenuItem
			// 
			this.szétválogatásToolStripMenuItem.Name = "szétválogatásToolStripMenuItem";
			this.szétválogatásToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.szétválogatásToolStripMenuItem.Text = "Szétválogatás";
			// 
			// metszetToolStripMenuItem
			// 
			this.metszetToolStripMenuItem.Name = "metszetToolStripMenuItem";
			this.metszetToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.metszetToolStripMenuItem.Text = "Metszet";
			// 
			// egyesítésunioToolStripMenuItem
			// 
			this.egyesítésunioToolStripMenuItem.Name = "egyesítésunioToolStripMenuItem";
			this.egyesítésunioToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.egyesítésunioToolStripMenuItem.Text = "Egyesítés (unio)";
			// 
			// összefuttatásrendezettekUniojaToolStripMenuItem
			// 
			this.összefuttatásrendezettekUniojaToolStripMenuItem.Name = "összefuttatásrendezettekUniojaToolStripMenuItem";
			this.összefuttatásrendezettekUniojaToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
			this.összefuttatásrendezettekUniojaToolStripMenuItem.Text = "Összefuttatás (rendezettek unioja)";
			// 
			// lbl_title
			// 
			this.lbl_title.AutoSize = true;
			this.lbl_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
			this.lbl_title.Location = new System.Drawing.Point(16, 50);
			this.lbl_title.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_title.Name = "lbl_title";
			this.lbl_title.Size = new System.Drawing.Size(141, 31);
			this.lbl_title.TabIndex = 1;
			this.lbl_title.Text = "Tétel neve";
			// 
			// tb_leiras
			// 
			this.tb_leiras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_leiras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_leiras.Cursor = System.Windows.Forms.Cursors.Default;
			this.tb_leiras.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_leiras.Location = new System.Drawing.Point(24, 135);
			this.tb_leiras.Margin = new System.Windows.Forms.Padding(5);
			this.tb_leiras.Multiline = true;
			this.tb_leiras.Name = "tb_leiras";
			this.tb_leiras.ReadOnly = true;
			this.tb_leiras.Size = new System.Drawing.Size(402, 223);
			this.tb_leiras.TabIndex = 2;
			this.tb_leiras.Text = "Tétel leírása";
			// 
			// tb_kod
			// 
			this.tb_kod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_kod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_kod.Cursor = System.Windows.Forms.Cursors.Default;
			this.tb_kod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_kod.Location = new System.Drawing.Point(28, 400);
			this.tb_kod.Margin = new System.Windows.Forms.Padding(5);
			this.tb_kod.Multiline = true;
			this.tb_kod.Name = "tb_kod";
			this.tb_kod.ReadOnly = true;
			this.tb_kod.Size = new System.Drawing.Size(398, 287);
			this.tb_kod.TabIndex = 3;
			this.tb_kod.Text = "Pszeudo kód";
			// 
			// tb_feladat
			// 
			this.tb_feladat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_feladat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_feladat.Cursor = System.Windows.Forms.Cursors.Default;
			this.tb_feladat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_feladat.Location = new System.Drawing.Point(484, 135);
			this.tb_feladat.Margin = new System.Windows.Forms.Padding(5);
			this.tb_feladat.Multiline = true;
			this.tb_feladat.Name = "tb_feladat";
			this.tb_feladat.ReadOnly = true;
			this.tb_feladat.Size = new System.Drawing.Size(377, 180);
			this.tb_feladat.TabIndex = 4;
			this.tb_feladat.Text = "Mintafeladat leírása";
			// 
			// tb_megoldas
			// 
			this.tb_megoldas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_megoldas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_megoldas.Cursor = System.Windows.Forms.Cursors.Default;
			this.tb_megoldas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_megoldas.Location = new System.Drawing.Point(484, 346);
			this.tb_megoldas.Margin = new System.Windows.Forms.Padding(5);
			this.tb_megoldas.Multiline = true;
			this.tb_megoldas.Name = "tb_megoldas";
			this.tb_megoldas.ReadOnly = true;
			this.tb_megoldas.Size = new System.Drawing.Size(377, 341);
			this.tb_megoldas.TabIndex = 5;
			this.tb_megoldas.Text = "Mintafeladat megoldására írt kód";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// btn_adatok_fajlbol
			// 
			this.btn_adatok_fajlbol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.btn_adatok_fajlbol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_adatok_fajlbol.Location = new System.Drawing.Point(914, 374);
			this.btn_adatok_fajlbol.Margin = new System.Windows.Forms.Padding(5);
			this.btn_adatok_fajlbol.Name = "btn_adatok_fajlbol";
			this.btn_adatok_fajlbol.Size = new System.Drawing.Size(185, 37);
			this.btn_adatok_fajlbol.TabIndex = 6;
			this.btn_adatok_fajlbol.Text = "Adatok importálása";
			this.btn_adatok_fajlbol.UseVisualStyleBackColor = false;
			// 
			// tb_adatbe
			// 
			this.tb_adatbe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_adatbe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_adatbe.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.tb_adatbe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_adatbe.Location = new System.Drawing.Point(915, 136);
			this.tb_adatbe.Margin = new System.Windows.Forms.Padding(5);
			this.tb_adatbe.Multiline = true;
			this.tb_adatbe.Name = "tb_adatbe";
			this.tb_adatbe.Size = new System.Drawing.Size(388, 222);
			this.tb_adatbe.TabIndex = 7;
			this.tb_adatbe.Text = "Felhasználó által bevitt adatok";
			this.tb_adatbe.Enter += new System.EventHandler(this.tb_adatbe_GotFocus);
			this.tb_adatbe.Leave += new System.EventHandler(this.tb_adatbe_LostFocus);
			// 
			// tb_eredmeny
			// 
			this.tb_eredmeny.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(27)))), ((int)(((byte)(46)))));
			this.tb_eredmeny.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tb_eredmeny.Cursor = System.Windows.Forms.Cursors.Default;
			this.tb_eredmeny.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
			this.tb_eredmeny.Location = new System.Drawing.Point(915, 446);
			this.tb_eredmeny.Margin = new System.Windows.Forms.Padding(5);
			this.tb_eredmeny.Multiline = true;
			this.tb_eredmeny.Name = "tb_eredmeny";
			this.tb_eredmeny.ReadOnly = true;
			this.tb_eredmeny.Size = new System.Drawing.Size(388, 194);
			this.tb_eredmeny.TabIndex = 9;
			this.tb_eredmeny.Text = "A kód eredménye";
			// 
			// btn_mentes_fajlba
			// 
			this.btn_mentes_fajlba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.btn_mentes_fajlba.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_mentes_fajlba.Location = new System.Drawing.Point(915, 650);
			this.btn_mentes_fajlba.Margin = new System.Windows.Forms.Padding(5);
			this.btn_mentes_fajlba.Name = "btn_mentes_fajlba";
			this.btn_mentes_fajlba.Size = new System.Drawing.Size(388, 37);
			this.btn_mentes_fajlba.TabIndex = 8;
			this.btn_mentes_fajlba.Text = "Eredmény exportálása";
			this.btn_mentes_fajlba.UseVisualStyleBackColor = false;
			this.btn_mentes_fajlba.Click += new System.EventHandler(this.btn_mentes_fajlba_Click);
			// 
			// lbl_kod
			// 
			this.lbl_kod.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
			this.lbl_kod.AutoSize = true;
			this.lbl_kod.Location = new System.Drawing.Point(24, 374);
			this.lbl_kod.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_kod.Name = "lbl_kod";
			this.lbl_kod.Size = new System.Drawing.Size(106, 21);
			this.lbl_kod.TabIndex = 10;
			this.lbl_kod.Text = "Pszeudo kód";
			// 
			// lbl_feladat
			// 
			this.lbl_feladat.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
			this.lbl_feladat.AutoSize = true;
			this.lbl_feladat.Location = new System.Drawing.Point(480, 109);
			this.lbl_feladat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_feladat.Name = "lbl_feladat";
			this.lbl_feladat.Size = new System.Drawing.Size(103, 21);
			this.lbl_feladat.TabIndex = 11;
			this.lbl_feladat.Text = "Mintafeldat";
			// 
			// lbl_adatbe
			// 
			this.lbl_adatbe.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
			this.lbl_adatbe.AutoSize = true;
			this.lbl_adatbe.Location = new System.Drawing.Point(910, 109);
			this.lbl_adatbe.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_adatbe.Name = "lbl_adatbe";
			this.lbl_adatbe.Size = new System.Drawing.Size(379, 21);
			this.lbl_adatbe.TabIndex = 12;
			this.lbl_adatbe.Text = "Adja meg a futáshoz szükséges paramétereket!";
			// 
			// btn_run
			// 
			this.btn_run.BackColor = System.Drawing.Color.Gray;
			this.btn_run.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_run.Location = new System.Drawing.Point(1109, 374);
			this.btn_run.Margin = new System.Windows.Forms.Padding(5);
			this.btn_run.Name = "btn_run";
			this.btn_run.Size = new System.Drawing.Size(194, 37);
			this.btn_run.TabIndex = 13;
			this.btn_run.Text = "Kód futtatása";
			this.btn_run.UseVisualStyleBackColor = false;
			this.btn_run.Click += new System.EventHandler(this.btn_run_Click);
			// 
			// lbl_megoldas
			// 
			this.lbl_megoldas.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
			this.lbl_megoldas.AutoSize = true;
			this.lbl_megoldas.Location = new System.Drawing.Point(480, 320);
			this.lbl_megoldas.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_megoldas.Name = "lbl_megoldas";
			this.lbl_megoldas.Size = new System.Drawing.Size(297, 21);
			this.lbl_megoldas.TabIndex = 15;
			this.lbl_megoldas.Text = "A feladat egy lehetséges megoldása";
			// 
			// lbl_leiras
			// 
			this.lbl_leiras.AutoSize = true;
			this.lbl_leiras.Location = new System.Drawing.Point(24, 109);
			this.lbl_leiras.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_leiras.Name = "lbl_leiras";
			this.lbl_leiras.Size = new System.Drawing.Size(101, 21);
			this.lbl_leiras.TabIndex = 16;
			this.lbl_leiras.Text = "Tétel leírása";
			// 
			// lbl_eredmeny
			// 
			this.lbl_eredmeny.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
			this.lbl_eredmeny.AutoSize = true;
			this.lbl_eredmeny.Location = new System.Drawing.Point(912, 420);
			this.lbl_eredmeny.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lbl_eredmeny.Name = "lbl_eredmeny";
			this.lbl_eredmeny.Size = new System.Drawing.Size(149, 21);
			this.lbl_eredmeny.TabIndex = 17;
			this.lbl_eredmeny.Text = "A kód eredménye";
			// 
			// divider1
			// 
			this.divider1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.divider1.Location = new System.Drawing.Point(453, 109);
			this.divider1.Name = "divider1";
			this.divider1.Size = new System.Drawing.Size(2, 580);
			this.divider1.TabIndex = 18;
			// 
			// divider2
			// 
			this.divider2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.divider2.Location = new System.Drawing.Point(887, 109);
			this.divider2.Name = "divider2";
			this.divider2.Size = new System.Drawing.Size(2, 580);
			this.divider2.TabIndex = 19;
			// 
			// form_programozasi_tetelek
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(10)))), ((int)(((byte)(50)))));
			this.ClientSize = new System.Drawing.Size(1331, 716);
			this.Controls.Add(this.divider2);
			this.Controls.Add(this.divider1);
			this.Controls.Add(this.lbl_eredmeny);
			this.Controls.Add(this.lbl_leiras);
			this.Controls.Add(this.lbl_megoldas);
			this.Controls.Add(this.btn_run);
			this.Controls.Add(this.lbl_adatbe);
			this.Controls.Add(this.lbl_feladat);
			this.Controls.Add(this.lbl_kod);
			this.Controls.Add(this.tb_eredmeny);
			this.Controls.Add(this.btn_mentes_fajlba);
			this.Controls.Add(this.tb_adatbe);
			this.Controls.Add(this.btn_adatok_fajlbol);
			this.Controls.Add(this.tb_megoldas);
			this.Controls.Add(this.tb_feladat);
			this.Controls.Add(this.tb_kod);
			this.Controls.Add(this.tb_leiras);
			this.Controls.Add(this.lbl_title);
			this.Controls.Add(this.menu_main);
			this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.MainMenuStrip = this.menu_main;
			this.Margin = new System.Windows.Forms.Padding(5);
			this.Name = "form_programozasi_tetelek";
			this.Text = "Programozási tételek";
			this.menu_main.ResumeLayout(false);
			this.menu_main.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menu_main;
		private System.Windows.Forms.ToolStripMenuItem menuitem_elemi;
		private System.Windows.Forms.ToolStripMenuItem menuitem_sorozat;
		private System.Windows.Forms.ToolStripMenuItem menuitem_eldontes;
		private System.Windows.Forms.ToolStripMenuItem menuitem_kivalasztas;
		private System.Windows.Forms.ToolStripMenuItem menuitem_kereses;
		private System.Windows.Forms.ToolStripMenuItem menuitem_megszamolas;
		private System.Windows.Forms.ToolStripMenuItem menuitem_maximum;
		private System.Windows.Forms.ToolStripMenuItem menuitem_osszetett;
		private System.Windows.Forms.ToolStripMenuItem másolásToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem kiválogatásToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem szétválogatásToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem metszetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem egyesítésunioToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem összefuttatásrendezettekUniojaToolStripMenuItem;
		private System.Windows.Forms.Label lbl_title;
		private System.Windows.Forms.TextBox tb_leiras;
		private System.Windows.Forms.TextBox tb_kod;
		private System.Windows.Forms.TextBox tb_feladat;
		private System.Windows.Forms.TextBox tb_megoldas;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Button btn_adatok_fajlbol;
		private System.Windows.Forms.TextBox tb_adatbe;
		private System.Windows.Forms.TextBox tb_eredmeny;
		private System.Windows.Forms.Button btn_mentes_fajlba;
		private System.Windows.Forms.Label lbl_kod;
		private System.Windows.Forms.Label lbl_feladat;
		private System.Windows.Forms.Label lbl_adatbe;
		private System.Windows.Forms.Button btn_run;
		private System.Windows.Forms.Label lbl_megoldas;
		private System.Windows.Forms.Label lbl_leiras;
		private System.Windows.Forms.Label lbl_eredmeny;
        private System.Windows.Forms.Panel divider1;
        private System.Windows.Forms.Panel divider2;
    }
}

