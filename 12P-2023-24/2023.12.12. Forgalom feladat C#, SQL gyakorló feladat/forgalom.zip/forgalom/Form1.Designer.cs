﻿namespace forgalom
{
    partial class frmForgalom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbQuery = new System.Windows.Forms.TextBox();
            this.lblQuery = new System.Windows.Forms.Label();
            this.btnUploadQuery = new System.Windows.Forms.Button();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblDb = new System.Windows.Forms.Label();
            this.tbDb = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lblConnState = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btne10 = new System.Windows.Forms.Button();
            this.btne9 = new System.Windows.Forms.Button();
            this.btne6 = new System.Windows.Forms.Button();
            this.btne7 = new System.Windows.Forms.Button();
            this.btne8 = new System.Windows.Forms.Button();
            this.btne5 = new System.Windows.Forms.Button();
            this.btne4 = new System.Windows.Forms.Button();
            this.btne3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbQuery
            // 
            this.tbQuery.Location = new System.Drawing.Point(16, 57);
            this.tbQuery.Multiline = true;
            this.tbQuery.Name = "tbQuery";
            this.tbQuery.Size = new System.Drawing.Size(367, 251);
            this.tbQuery.TabIndex = 0;
            // 
            // lblQuery
            // 
            this.lblQuery.AutoSize = true;
            this.lblQuery.Location = new System.Drawing.Point(12, 21);
            this.lblQuery.Name = "lblQuery";
            this.lblQuery.Size = new System.Drawing.Size(108, 21);
            this.lblQuery.TabIndex = 1;
            this.lblQuery.Text = "Új lekérdezés";
            // 
            // btnUploadQuery
            // 
            this.btnUploadQuery.Location = new System.Drawing.Point(251, 314);
            this.btnUploadQuery.Name = "btnUploadQuery";
            this.btnUploadQuery.Size = new System.Drawing.Size(132, 30);
            this.btnUploadQuery.TabIndex = 2;
            this.btnUploadQuery.Text = "Feltöltés fájlból";
            this.btnUploadQuery.UseVisualStyleBackColor = true;
            this.btnUploadQuery.Click += new System.EventHandler(this.btnUploadQuery_Click);
            // 
            // dgvResult
            // 
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Location = new System.Drawing.Point(408, 57);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.Size = new System.Drawing.Size(592, 677);
            this.dgvResult.TabIndex = 3;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(404, 21);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(88, 21);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "Eredmény";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(16, 314);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(229, 73);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "Indítás";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblDb
            // 
            this.lblDb.AutoSize = true;
            this.lblDb.Location = new System.Drawing.Point(12, 616);
            this.lblDb.Name = "lblDb";
            this.lblDb.Size = new System.Drawing.Size(138, 21);
            this.lblDb.TabIndex = 7;
            this.lblDb.Text = "Adatbázis neve:";
            // 
            // tbDb
            // 
            this.tbDb.Location = new System.Drawing.Point(216, 610);
            this.tbDb.Name = "tbDb";
            this.tbDb.Size = new System.Drawing.Size(156, 27);
            this.tbDb.TabIndex = 8;
            this.tbDb.Text = "forgalom";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(8, 698);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(364, 36);
            this.btnConnect.TabIndex = 9;
            this.btnConnect.Text = "Újrakapcsolódás";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lblConnState
            // 
            this.lblConnState.AutoSize = true;
            this.lblConnState.Location = new System.Drawing.Point(12, 656);
            this.lblConnState.Name = "lblConnState";
            this.lblConnState.Size = new System.Drawing.Size(142, 21);
            this.lblConnState.TabIndex = 10;
            this.lblConnState.Text = "adatbazisszoveg";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btne10);
            this.panel1.Controls.Add(this.btne9);
            this.panel1.Controls.Add(this.btne6);
            this.panel1.Controls.Add(this.btne7);
            this.panel1.Controls.Add(this.btne8);
            this.panel1.Controls.Add(this.btne5);
            this.panel1.Controls.Add(this.btne4);
            this.panel1.Controls.Add(this.btne3);
            this.panel1.Location = new System.Drawing.Point(65, 455);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(270, 100);
            this.panel1.TabIndex = 11;
            // 
            // btne10
            // 
            this.btne10.Location = new System.Drawing.Point(207, 55);
            this.btne10.Name = "btne10";
            this.btne10.Size = new System.Drawing.Size(63, 45);
            this.btne10.TabIndex = 7;
            this.btne10.Text = "10";
            this.btne10.UseVisualStyleBackColor = true;
            // 
            // btne9
            // 
            this.btne9.Location = new System.Drawing.Point(138, 55);
            this.btne9.Name = "btne9";
            this.btne9.Size = new System.Drawing.Size(63, 45);
            this.btne9.TabIndex = 6;
            this.btne9.Text = "9";
            this.btne9.UseVisualStyleBackColor = true;
            // 
            // btne6
            // 
            this.btne6.Location = new System.Drawing.Point(207, 0);
            this.btne6.Name = "btne6";
            this.btne6.Size = new System.Drawing.Size(63, 45);
            this.btne6.TabIndex = 5;
            this.btne6.Text = "6";
            this.btne6.UseVisualStyleBackColor = true;
            // 
            // btne7
            // 
            this.btne7.Location = new System.Drawing.Point(0, 55);
            this.btne7.Name = "btne7";
            this.btne7.Size = new System.Drawing.Size(63, 45);
            this.btne7.TabIndex = 4;
            this.btne7.Text = "7";
            this.btne7.UseVisualStyleBackColor = true;
            // 
            // btne8
            // 
            this.btne8.Location = new System.Drawing.Point(69, 55);
            this.btne8.Name = "btne8";
            this.btne8.Size = new System.Drawing.Size(63, 45);
            this.btne8.TabIndex = 3;
            this.btne8.Text = "8";
            this.btne8.UseVisualStyleBackColor = true;
            // 
            // btne5
            // 
            this.btne5.Location = new System.Drawing.Point(138, 0);
            this.btne5.Name = "btne5";
            this.btne5.Size = new System.Drawing.Size(63, 45);
            this.btne5.TabIndex = 2;
            this.btne5.Text = "5";
            this.btne5.UseVisualStyleBackColor = true;
            // 
            // btne4
            // 
            this.btne4.Location = new System.Drawing.Point(69, 0);
            this.btne4.Name = "btne4";
            this.btne4.Size = new System.Drawing.Size(63, 45);
            this.btne4.TabIndex = 1;
            this.btne4.Text = "4";
            this.btne4.UseVisualStyleBackColor = true;
            // 
            // btne3
            // 
            this.btne3.Location = new System.Drawing.Point(0, 0);
            this.btne3.Name = "btne3";
            this.btne3.Size = new System.Drawing.Size(63, 45);
            this.btne3.TabIndex = 0;
            this.btne3.Text = "3";
            this.btne3.UseVisualStyleBackColor = true;
            this.btne3.Click += new System.EventHandler(this.btne3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 21);
            this.label2.TabIndex = 8;
            this.label2.Text = "Példa lekérdezések";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(251, 350);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(132, 37);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Mentés fájlba";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmForgalom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 764);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblConnState);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.tbDb);
            this.Controls.Add(this.lblDb);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.dgvResult);
            this.Controls.Add(this.btnUploadQuery);
            this.Controls.Add(this.lblQuery);
            this.Controls.Add(this.tbQuery);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmForgalom";
            this.Text = "Forgalom";
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbQuery;
        private System.Windows.Forms.Label lblQuery;
        private System.Windows.Forms.Button btnUploadQuery;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblDb;
        private System.Windows.Forms.TextBox tbDb;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lblConnState;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btne4;
        private System.Windows.Forms.Button btne3;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Button btne9;
        private System.Windows.Forms.Button btne6;
        private System.Windows.Forms.Button btne7;
        private System.Windows.Forms.Button btne8;
        private System.Windows.Forms.Button btne5;
        private System.Windows.Forms.Button btne10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSave;
    }
}

