﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace korok_uj
{
    internal class korok
    {
        private List<kor> korokList= new List<kor>();
        private int count = 0;

        public void addKor(char color, int radius, int x, int y)
        {
            korokList.Add(new kor(++count, color, radius, x, y));
        }

        public void checkPointInKorok(int pointx, int pointy)
        {
            Console.WriteLine();
            bool found = false;
            foreach (var kor in korokList)
            {
                if (kor.isPointInKor(pointx, pointy))
                {
                    Console.WriteLine($"A pont benne van ebben a körben: ID = {kor.getId()}, Szín = {kor.getColor()}");
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Nincs egyik körben sem.");
            }
        }
    }
}

