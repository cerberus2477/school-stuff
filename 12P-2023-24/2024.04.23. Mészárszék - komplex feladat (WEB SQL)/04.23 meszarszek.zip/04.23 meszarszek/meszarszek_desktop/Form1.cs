﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Google.Protobuf.Compiler;
using MySql.Data.MySqlClient;

namespace meszarszek_desktop
{
	public partial class form_meszarszek : Form
	{
		public static string connectionString = "Server=localhost;Uid=root;Pwd=;";
		public static string sql_vagas = "INSERT INTO vagas VALUES (@marhaid, @nyak, @szegy, @elsocomb, @tarja, @hatszin, @oldalas, @hatsocomb, @labszar, @datum, @ido)";
		public static string sql_marha = "INSERT INTO marha VALUES (@id, @elosuly, @fajta, @datum, @ido)";

		public form_meszarszek()
		{
			InitializeComponent();
			pnl_marha.Visible = true;
			pnl_vagas.Visible = false;

			this.date_marha.Format = DateTimePickerFormat.Custom;
			this.date_marha.CustomFormat = "yyyy/MM/dd";
			this.time_marha.Format = DateTimePickerFormat.Custom;
			this.time_marha.CustomFormat = "HH:mm";
			this.time_marha.ShowUpDown = true;
			this.date_vagas.Format = DateTimePickerFormat.Custom;
			this.date_vagas.CustomFormat = "yyyy/MM/dd";
			this.time_vagas.Format = DateTimePickerFormat.Custom;
			this.time_vagas.CustomFormat = "HH:mm";
			this.time_vagas.ShowUpDown = true;

			createDB();
		}

		//EVENTS
		private void marhaAdatinakFelviteleToolStripMenuItem_Click(object sender, EventArgs e)
		{
			pnl_marha.Visible = true;
			pnl_vagas.Visible = false;
			pnl_marha.BringToFront();
		}

		private void vágásAdatiainakFelviteleToolStripMenuItem_Click(object sender, EventArgs e)
		{
			pnl_marha.Visible = false;
			pnl_vagas.Visible = true;
			pnl_vagas.BringToFront();
		}
		private void btn_feltoltes_Click(object sender, EventArgs e)
		{
			if(pnl_marha.Visible) insert_marha(); else insert_vagas();
		}





		//adatbázis létrehozása sql fájl futtatásával
		public void createDB()
		{
			using(MySqlConnection connection = new MySqlConnection(connectionString))
			{
				try
				{
					connection.Open();
					new MySqlCommand(new StreamReader("meszarszek.sql").ReadToEnd(), connection).ExecuteNonQuery();
					connectionString += "Database=meszarszek;";
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.Message, "Hiba történt az adatbázis létrohozása közben.");
				}
			}
		}

		private void insert_marha()
		{
			using(MySqlConnection connection = new MySqlConnection(connectionString))
			{
				MySqlCommand cmd1 = new MySqlCommand("USE meszarszek", connection);
				MySqlCommand cmd = new MySqlCommand(sql_vagas, connection);
				cmd.Parameters.AddWithValue("@marhaid", num_marhaid.Value);
				cmd.Parameters.AddWithValue("@nyak", num_nyak.Value);
				cmd.Parameters.AddWithValue("@szegy", num_szegy.Value);
				cmd.Parameters.AddWithValue("@elsocomb", num_elsocomb.Value);
				cmd.Parameters.AddWithValue("@tarja", num_tarja.Value);
				cmd.Parameters.AddWithValue("@hatszin", num_hatszin.Value);
				cmd.Parameters.AddWithValue("@oldalas", num_oldalas.Value);
				cmd.Parameters.AddWithValue("@hatsocomb", num_hatsocomb.Value);
				cmd.Parameters.AddWithValue("@labszar", num_labszar.Value);
				cmd.Parameters.AddWithValue("@datum", date_vagas.Value.ToString("yyyy-MM-dd"));
				cmd.Parameters.AddWithValue("@ido", time_vagas.Value.ToString("HH:mm"));

				try
				{
					connection.Open();
					cmd1.ExecuteNonQuery();
					cmd.ExecuteNonQuery();
					MessageBox.Show("Rekord sikeresen létrehozva!");
				}
				catch(Exception ex)
				{
					MessageBox.Show($"{ex.Message}\n\n{ex.ToString()}", "Hiba történt a rekord létrehozása közben.");
				}
			}
		}

		private void insert_vagas()
		{
			using(MySqlConnection connection = new MySqlConnection(connectionString))
			{
				MySqlCommand checkCmd = new MySqlCommand($"SELECT COUNT(*) FROM marha WHERE id = {num_id.Value}", connection);
				bool marhaExists = Convert.ToInt32(checkCmd.ExecuteScalar()) > 0;
				if(!marhaExists)
				{
					MessageBox.Show($"Nem hozható létre a vágás rekord mert nincs ilyen kóddal rendelkező marha. Ha helyes a kód, előbb töltse fel a marhát a marha táblába.", "Hiba történt a rekord létrehozása közben.");
				}
				else
				{
					MySqlCommand cmd = new MySqlCommand(sql_marha, connection);
					cmd.Parameters.AddWithValue("@id", num_id.Value);
					cmd.Parameters.AddWithValue("@elosuly", num_elosuly.Value);
					cmd.Parameters.AddWithValue("@fajta", tb_fajta.Text);
					cmd.Parameters.AddWithValue("@datum", date_marha.Value.ToString("yyyy-MM-dd"));
					cmd.Parameters.AddWithValue("@ido", time_marha.Value.ToString("HH:mm:ss"));

					try
					{
						connection.Open();
						cmd.ExecuteNonQuery();
						MessageBox.Show("Rekord sikeresen létrehozva!");
					}
					catch(Exception ex)
					{
						MessageBox.Show($"{ex.Message}\n\n{ex}", "Hiba történt a rekord létrehozása közben.");
					}
				}
			}
		}



	}
}
