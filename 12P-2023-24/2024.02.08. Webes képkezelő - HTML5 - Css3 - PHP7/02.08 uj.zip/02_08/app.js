function toggleAll(source) {
    // var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkboxes = document.getElementsByName('itemsToDelete[]');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
}

function confirmDelete() {
    return confirm("Biztosan törölni szeretné a kiválasztott elemeket?");
}

function toggleVisibility() {
    var checkboxes = document.getElementsByName('itemsToDelete[]');
    checkboxes.forEach(checkbox => checkbox.classList.toggle('hidden'));

    var deleteBtn = document.getElementById('deleteBtn');
    var checkboxBtn = document.getElementById('checkboxBtn');
    var toggleAllBtn = document.getElementById('toggleAllBtn');
    deleteBtn.classList.toggle('hiddend');
    checkboxBtn.classList.toggle('hiddend');
    toggleAllBtn.classList.toggle('hiddend');
}