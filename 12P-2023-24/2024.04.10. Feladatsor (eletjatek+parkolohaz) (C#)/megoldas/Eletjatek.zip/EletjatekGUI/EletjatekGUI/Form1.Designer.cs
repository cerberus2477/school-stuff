﻿namespace EletjatekGUI
{
    partial class frm_eletjatekGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_title = new System.Windows.Forms.Label();
            this.btn_createMatrix = new System.Windows.Forms.Button();
            this.btn_export = new System.Windows.Forms.Button();
            this.cb_sorokSzama = new System.Windows.Forms.ComboBox();
            this.cb_oszlopokSzama = new System.Windows.Forms.ComboBox();
            this.pnl_matrix = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Location = new System.Drawing.Point(12, 9);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(137, 13);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "Mátrix mérete [sor x oszlop]:";
            // 
            // btn_createMatrix
            // 
            this.btn_createMatrix.Location = new System.Drawing.Point(15, 38);
            this.btn_createMatrix.Name = "btn_createMatrix";
            this.btn_createMatrix.Size = new System.Drawing.Size(131, 23);
            this.btn_createMatrix.TabIndex = 1;
            this.btn_createMatrix.Text = "Üres mátrix létrehozása";
            this.btn_createMatrix.UseVisualStyleBackColor = true;
            this.btn_createMatrix.Click += new System.EventHandler(this.btn_createMatrix_Click);
            // 
            // btn_export
            // 
            this.btn_export.Location = new System.Drawing.Point(161, 38);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(130, 23);
            this.btn_export.TabIndex = 2;
            this.btn_export.Text = "Állás mentése";
            this.btn_export.UseVisualStyleBackColor = true;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // cb_sorokSzama
            // 
            this.cb_sorokSzama.FormattingEnabled = true;
            this.cb_sorokSzama.Location = new System.Drawing.Point(168, 9);
            this.cb_sorokSzama.Name = "cb_sorokSzama";
            this.cb_sorokSzama.Size = new System.Drawing.Size(51, 21);
            this.cb_sorokSzama.TabIndex = 3;
            this.cb_sorokSzama.Text = "20";
            // 
            // cb_oszlopokSzama
            // 
            this.cb_oszlopokSzama.FormattingEnabled = true;
            this.cb_oszlopokSzama.Location = new System.Drawing.Point(225, 9);
            this.cb_oszlopokSzama.Name = "cb_oszlopokSzama";
            this.cb_oszlopokSzama.Size = new System.Drawing.Size(51, 21);
            this.cb_oszlopokSzama.TabIndex = 4;
            this.cb_oszlopokSzama.Text = "20";
            // 
            // pnl_matrix
            // 
            this.pnl_matrix.Location = new System.Drawing.Point(15, 76);
            this.pnl_matrix.Name = "pnl_matrix";
            this.pnl_matrix.Size = new System.Drawing.Size(350, 350);
            this.pnl_matrix.TabIndex = 5;
            // 
            // frm_eletjatekGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 450);
            this.Controls.Add(this.pnl_matrix);
            this.Controls.Add(this.cb_oszlopokSzama);
            this.Controls.Add(this.cb_sorokSzama);
            this.Controls.Add(this.btn_export);
            this.Controls.Add(this.btn_createMatrix);
            this.Controls.Add(this.lbl_title);
            this.Name = "frm_eletjatekGUI";
            this.Text = "Életjáték álláskészítő";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Button btn_createMatrix;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.ComboBox cb_sorokSzama;
        private System.Windows.Forms.ComboBox cb_oszlopokSzama;
        private System.Windows.Forms.Panel pnl_matrix;
    }
}

