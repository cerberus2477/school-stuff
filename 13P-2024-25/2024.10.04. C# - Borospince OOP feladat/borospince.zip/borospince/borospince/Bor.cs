﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace borospince
{
    internal class Bor
    {
        private string fajta;
        private int evjarat;
        private double _alkoholtartalom;

        //Inicializáld a fajta, evjarat és _alkoholtartalom adattagokat a paraméterek alapján! (3 pont) ??
        public Bor(string fajta, int evjarat, double alkoholtartalom = 12.5)
        {
            this.fajta = fajta;
            this.evjarat = evjarat;
            //this._alkoholtartalom = alkoholtartalom;
            Alkoholtartalom = alkoholtartalom;
        }

        //getter és setter, így is lehet
        public string Fajta
        {
            get => fajta;
            set { fajta = value; }
        }

        public int Evjarat
        {
            get => evjarat;
            set { evjarat = value; }
        }

        //nice dolgok
        public double Alkoholtartalom
        {
            get => _alkoholtartalom;
            set
            {
                if (value < 0 || value > 100) throw new BorospinceException("Nem megfelelő alkoholtartalom!");
                _alkoholtartalom = value;
            }
        }

        public override string ToString() => $"{fajta} (evjarat: {evjarat}), melynek alkoholtartalma: {_alkoholtartalom}%";

        public static bool operator == (Bor bor1, object obj)
        {
            if (!(obj is Bor bor2)) return false;
            if (bor1 is null || bor2 is null) return false;
            return bor1.fajta.ToLower() == bor2.fajta.ToLower() && bor1.evjarat == bor2.evjarat && bor1._alkoholtartalom == bor2._alkoholtartalom;
        }


        //illik az equalst is felülírni a ==-nek megfelelően, hogy konzisztens maradjon az eredmény
        public override bool Equals(object obj)
        {
            if (obj is Bor bor2) return this == bor2;
            return false;
        }


        //ha a ==-t felülírjük ezt is felül kell írni
        public static bool operator !=(Bor bor1, object obj) => !(bor1 == obj);


        //ha a ==-t felülírjük a gethashcode-ot is felül kell írni. ezt találtam a neten:
        public override int GetHashCode()
        {
            // Using a hash code generator to combine the hash codes of the properties
            // We use a simple hash algorithm here, which could be refined further if needed.
            int hashFajta = fajta?.ToLower().GetHashCode() ?? 0; // Handle null fajta
            int hashEvjarat = evjarat.GetHashCode();
            int hashAlkoholtartalom = _alkoholtartalom.GetHashCode();

            return hashFajta ^ hashEvjarat ^ hashAlkoholtartalom; // XOR to combine hash codes
        }
    }

}
