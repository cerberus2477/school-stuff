﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace bingo
{
	public class BingoJatekos
	{
		static string nev;
		static int[,] matrix;

		public BingoJatekos(string fnev)
		{
			nev = fnev.Substring(0, fnev.Length-4); //levágja a .txt -t
			matrix = KartyaBeolvas(fnev);
		}

		public static int[,] KartyaBeolvas(string fnev)
		{
			int[,] result = new int[5, 5];
			for(int i = 0; i < 5; i++)
			{
				var values = File.ReadAllLines(fnev)[i].Split(';').Select(s => s == "X" ? "0" : s).Select(s => int.Parse(s)).ToArray();
				for(int j = 0; j < values.Length; j++)
				{
					result[i, j] = values[j];
				}
			}
			return result;
		}

		public static void SorsoltSzamotJelol(int szam)
		{

		}

	}
}
