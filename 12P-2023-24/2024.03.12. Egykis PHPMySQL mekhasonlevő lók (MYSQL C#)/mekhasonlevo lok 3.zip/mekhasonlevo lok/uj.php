<?php 
$conn = new mysqli("localhost", "root", "", "csonakkolcsonzo");

if ($conn->connect_error) {
    die("Az adatbázishoz való csatlakozás közben hiba lépett fel. " . $conn->connect_error);
}

$img_root = "./hajo_kepek/";
$hajok_sql = "SELECT * FROM hajok WHERE 1=1";

// KERESŐ
if (isset($_GET['search-nev']) && isset($_GET['search-fo'])) {
    // Hajó neve
    if (!empty($_GET['search-nev'])) {
        $hajok_sql .= " AND nev LIKE '%" . $_GET['search-nev'] . "%'";
    }
    // Minimum fő
    if (!empty($_GET['search-fo'])) {
        $hajok_sql .= " AND fo >= " . $_GET['search-fo'];
    }
}
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FolyóFantom</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav>
        <span class="brand">FOLYÓFANTOM</span>
        <div class="navlinks">
            <a href="#statisztika">Statisztika</a>
            <a href="uj.php">Új</a>
            <!-- <a class="btn" href="kosar.php">Kosár</a> -->
        </div>
    </nav>

    <header class="header">
        <h1>FolyóFantom</h1>
        <p>Kölcsönözz csónakot még ma!</p>
        <a href="#hajok" class="btn">Hajók</a>
    </header>


<!-- //HAJO - uj -->
    <section id="uj-hajo">
    <h2>Hajó adatai</h2>
    <form action="#">
        <div class="form-group">
            <label for="">Hajó neve:</label>
            <input type="text" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Típus:</label>
            <input type="text" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="hajo-leiras">Leírás:</label>
            <textarea id="hajo-leiras" name="hajo-leiras" rows="4" required></textarea>
        </div>
        <div class="form-group">
            <label for="">Egységár:</label>
            <input type="number" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Fő:</label>
            <input type="number" id="" name="" required>
        </div>

    </form>
    </section>

<!-- KOLCSONZO - uj es modositas (tel, nev)-->
<section id="uj-kolcsonzo">
    <h2>Kölcsönző adatai</h2>
    <form action="#">
        <div class="form-group">
            <label for="">Név:</label>
            <input type="text" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Telefon:</label>
            <input type="phone" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="hajo-leiras">Születési dátum</label>
            <input type="date" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Tud úszni</label>
            <input type="checkbox" id="" name="" required>
        </div>
  
    </section>

    <!-- KOLCSONZES - UJ -->
    <section id="uj-kolcsonzes">
    <h2>Kölcsönzés adatai</h2>
    <form action="#">
        <div class="form-group">
            <label for="">Dátum</label>
            <input type="date" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Lapátok száma:</label>
            <input type="number" id="" name="" required>
        </div>
        <div class="form-group">
            <label for="">Mentőmellények száma:</label>
            <input type="number" id="" name="" required>
        </div>
    </form>
    </section>

    <button id="submit-btn" class="btn">Mentés</button>

    <script src="script.js"></script>

    </body>
</html>