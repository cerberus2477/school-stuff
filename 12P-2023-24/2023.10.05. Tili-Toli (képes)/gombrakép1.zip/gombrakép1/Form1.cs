﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gombrakép1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.button1.Image = Image.FromFile("1.png");
            this.button1.Text = "";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.button13.Image = Image.FromFile("2.png");
            this.button13.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.button12.Image = Image.FromFile("3.png");
            this.button12.Text = "";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.button11.Image = Image.FromFile("4.png");
            this.button11.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.button6.Image = Image.FromFile("5.png");
            this.button6.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.button2.Image = Image.FromFile("6.png");
            this.button2.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.button10.Image = Image.FromFile("7.png");
            this.button10.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.button5.Image = Image.FromFile("8.png");
            this.button5.Text = "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.button9.Image = Image.FromFile("9.png");
            this.button9.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.button7.Image = Image.FromFile("10.png");
            this.button7.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.button4.Image = Image.FromFile("11.png");
            this.button4.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.button3.Image = Image.FromFile("12.png");
            this.button3.Text = "";
        }
    }
}
