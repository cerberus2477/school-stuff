﻿namespace amoba
{
    partial class frmAmoba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAmoba));
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlGameArea = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.játékToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statisztikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlSide = new System.Windows.Forms.Panel();
            this.tbPlayer2 = new System.Windows.Forms.TextBox();
            this.lblPlayer2 = new System.Windows.Forms.Label();
            this.tbPlayer2Icon = new System.Windows.Forms.TextBox();
            this.lblPlayer2Icon = new System.Windows.Forms.Label();
            this.tbPlayer1Icon = new System.Windows.Forms.TextBox();
            this.lblPlayer1Icon = new System.Windows.Forms.Label();
            this.lblNextTurn = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.tbPlayer1 = new System.Windows.Forms.TextBox();
            this.lblPlayer1 = new System.Windows.Forms.Label();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.pnlSide.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.ForeColor = System.Drawing.Color.Aqua;
            this.lblTitle.Location = new System.Drawing.Point(57, 81);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(202, 57);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Amőba";
            // 
            // pnlGameArea
            // 
            this.pnlGameArea.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlGameArea.AutoSize = true;
            this.pnlGameArea.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlGameArea.BackColor = System.Drawing.Color.MidnightBlue;
            this.pnlGameArea.Location = new System.Drawing.Point(13, 9);
            this.pnlGameArea.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlGameArea.Name = "pnlGameArea";
            this.pnlGameArea.Size = new System.Drawing.Size(0, 0);
            this.pnlGameArea.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.játékToolStripMenuItem,
            this.statisztikaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1299, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // játékToolStripMenuItem
            // 
            this.játékToolStripMenuItem.ForeColor = System.Drawing.Color.SpringGreen;
            this.játékToolStripMenuItem.Name = "játékToolStripMenuItem";
            this.játékToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.játékToolStripMenuItem.Text = "Játék";
            // 
            // statisztikaToolStripMenuItem
            // 
            this.statisztikaToolStripMenuItem.ForeColor = System.Drawing.Color.SpringGreen;
            this.statisztikaToolStripMenuItem.Name = "statisztikaToolStripMenuItem";
            this.statisztikaToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.statisztikaToolStripMenuItem.Text = "Statisztika";
            // 
            // pnlSide
            // 
            this.pnlSide.BackColor = System.Drawing.Color.Transparent;
            this.pnlSide.Controls.Add(this.tbPlayer2);
            this.pnlSide.Controls.Add(this.lblPlayer2);
            this.pnlSide.Controls.Add(this.tbPlayer2Icon);
            this.pnlSide.Controls.Add(this.lblPlayer2Icon);
            this.pnlSide.Controls.Add(this.tbPlayer1Icon);
            this.pnlSide.Controls.Add(this.lblPlayer1Icon);
            this.pnlSide.Controls.Add(this.lblTitle);
            this.pnlSide.Controls.Add(this.lblNextTurn);
            this.pnlSide.Controls.Add(this.btnStart);
            this.pnlSide.Controls.Add(this.tbPlayer1);
            this.pnlSide.Controls.Add(this.lblPlayer1);
            this.pnlSide.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSide.Location = new System.Drawing.Point(969, 24);
            this.pnlSide.MaximumSize = new System.Drawing.Size(330, 0);
            this.pnlSide.Name = "pnlSide";
            this.pnlSide.Size = new System.Drawing.Size(330, 923);
            this.pnlSide.TabIndex = 2;
            // 
            // tbPlayer2
            // 
            this.tbPlayer2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbPlayer2.BackColor = System.Drawing.Color.MidnightBlue;
            this.tbPlayer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPlayer2.ForeColor = System.Drawing.Color.LightCyan;
            this.tbPlayer2.Location = new System.Drawing.Point(46, 270);
            this.tbPlayer2.Name = "tbPlayer2";
            this.tbPlayer2.Size = new System.Drawing.Size(166, 26);
            this.tbPlayer2.TabIndex = 11;
            this.tbPlayer2.Text = "Levente";
            // 
            // lblPlayer2
            // 
            this.lblPlayer2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPlayer2.AutoSize = true;
            this.lblPlayer2.ForeColor = System.Drawing.Color.LightCyan;
            this.lblPlayer2.Location = new System.Drawing.Point(42, 247);
            this.lblPlayer2.Name = "lblPlayer2";
            this.lblPlayer2.Size = new System.Drawing.Size(170, 20);
            this.lblPlayer2.TabIndex = 10;
            this.lblPlayer2.Text = "Második játékos neve";
            // 
            // tbPlayer2Icon
            // 
            this.tbPlayer2Icon.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbPlayer2Icon.BackColor = System.Drawing.Color.MidnightBlue;
            this.tbPlayer2Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPlayer2Icon.ForeColor = System.Drawing.Color.LightCyan;
            this.tbPlayer2Icon.Location = new System.Drawing.Point(222, 270);
            this.tbPlayer2Icon.Name = "tbPlayer2Icon";
            this.tbPlayer2Icon.Size = new System.Drawing.Size(50, 26);
            this.tbPlayer2Icon.TabIndex = 9;
            this.tbPlayer2Icon.Text = "O";
            // 
            // lblPlayer2Icon
            // 
            this.lblPlayer2Icon.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPlayer2Icon.AutoSize = true;
            this.lblPlayer2Icon.ForeColor = System.Drawing.Color.LightCyan;
            this.lblPlayer2Icon.Location = new System.Drawing.Point(218, 247);
            this.lblPlayer2Icon.Name = "lblPlayer2Icon";
            this.lblPlayer2Icon.Size = new System.Drawing.Size(54, 20);
            this.lblPlayer2Icon.TabIndex = 8;
            this.lblPlayer2Icon.Text = "Ikonja";
            // 
            // tbPlayer1Icon
            // 
            this.tbPlayer1Icon.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbPlayer1Icon.BackColor = System.Drawing.Color.MidnightBlue;
            this.tbPlayer1Icon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPlayer1Icon.ForeColor = System.Drawing.Color.LightCyan;
            this.tbPlayer1Icon.Location = new System.Drawing.Point(222, 191);
            this.tbPlayer1Icon.Name = "tbPlayer1Icon";
            this.tbPlayer1Icon.Size = new System.Drawing.Size(50, 26);
            this.tbPlayer1Icon.TabIndex = 7;
            this.tbPlayer1Icon.Text = "X";
            // 
            // lblPlayer1Icon
            // 
            this.lblPlayer1Icon.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPlayer1Icon.AutoSize = true;
            this.lblPlayer1Icon.ForeColor = System.Drawing.Color.LightCyan;
            this.lblPlayer1Icon.Location = new System.Drawing.Point(218, 168);
            this.lblPlayer1Icon.Name = "lblPlayer1Icon";
            this.lblPlayer1Icon.Size = new System.Drawing.Size(54, 20);
            this.lblPlayer1Icon.TabIndex = 6;
            this.lblPlayer1Icon.Text = "Ikonja";
            // 
            // lblNextTurn
            // 
            this.lblNextTurn.AutoSize = true;
            this.lblNextTurn.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNextTurn.ForeColor = System.Drawing.Color.LightCyan;
            this.lblNextTurn.Location = new System.Drawing.Point(67, 489);
            this.lblNextTurn.Name = "lblNextTurn";
            this.lblNextTurn.Size = new System.Drawing.Size(0, 24);
            this.lblNextTurn.TabIndex = 5;
            // 
            // btnStart
            // 
            this.btnStart.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnStart.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnStart.ForeColor = System.Drawing.Color.SpringGreen;
            this.btnStart.Location = new System.Drawing.Point(102, 568);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(139, 68);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // tbPlayer1
            // 
            this.tbPlayer1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbPlayer1.BackColor = System.Drawing.Color.MidnightBlue;
            this.tbPlayer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPlayer1.ForeColor = System.Drawing.Color.LightCyan;
            this.tbPlayer1.Location = new System.Drawing.Point(46, 191);
            this.tbPlayer1.Name = "tbPlayer1";
            this.tbPlayer1.Size = new System.Drawing.Size(166, 26);
            this.tbPlayer1.TabIndex = 1;
            this.tbPlayer1.Text = "Nacsa";
            // 
            // lblPlayer1
            // 
            this.lblPlayer1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPlayer1.AutoSize = true;
            this.lblPlayer1.ForeColor = System.Drawing.Color.LightCyan;
            this.lblPlayer1.Location = new System.Drawing.Point(42, 168);
            this.lblPlayer1.Name = "lblPlayer1";
            this.lblPlayer1.Size = new System.Drawing.Size(135, 20);
            this.lblPlayer1.TabIndex = 0;
            this.lblPlayer1.Text = "Első játékos neve";
            // 
            // pnlContainer
            // 
            this.pnlContainer.BackColor = System.Drawing.Color.Transparent;
            this.pnlContainer.Controls.Add(this.pnlGameArea);
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(0, 24);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(969, 923);
            this.pnlContainer.TabIndex = 3;
            // 
            // frmAmoba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1299, 947);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.pnlSide);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmAmoba";
            this.Text = "Amőba játék";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlSide.ResumeLayout(false);
            this.pnlSide.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlContainer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnlGameArea;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem játékToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statisztikaToolStripMenuItem;
        private System.Windows.Forms.Panel pnlSide;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox tbPlayer1;
        private System.Windows.Forms.Label lblPlayer1;
        public System.Windows.Forms.Label lblNextTurn;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.TextBox tbPlayer1Icon;
        private System.Windows.Forms.Label lblPlayer1Icon;
        private System.Windows.Forms.TextBox tbPlayer2Icon;
        private System.Windows.Forms.Label lblPlayer2Icon;
        private System.Windows.Forms.TextBox tbPlayer2;
        private System.Windows.Forms.Label lblPlayer2;
    }
}

