﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sudokuGame
{
    class SudokuCell : Button
    {
        public int Value { get; set; }
        public bool isLocked { get; set; } //felhasználó átírhatja-e
        public bool isWrong { get; set; } //ha szabálytalan akkor igaz
        public int X { get; set; }
        public int Y { get; set; }


        public SudokuCell()
        {
            this.Click += nextValue;
            this.KeyPress += changeCell;

            isLocked = false;
            isWrong = false;
            Value = 0;
        }

        public void Clear()
        {
            this.Text = string.Empty;
            //this.isLocked = false;
        }

        public void nextValue(object sender, EventArgs e)
        {
            var cell = sender as SudokuCell;

            if (!isLocked)
            {
                cell.Value = Value == 9 ? 1 : Value + 1;
                cell.Text = cell.Value.ToString();
            }
        }


        private void changeCell(object sender, KeyPressEventArgs e)
        {
            var cell = sender as SudokuCell;

            if (!isLocked)
            {
                int value;

                // ha 0 a bemenet üres lesz a mező, 1-9ig beíruk a számot
                if (int.TryParse(e.KeyChar.ToString(), out value))
                {
                    if (value >= 0 && value <= 9)
                    {
                        if (value == 0)
                            cell.Clear();
                        else
                            cell.Text = value.ToString();
                    }
                   
                }
            }
        }





    }
}
